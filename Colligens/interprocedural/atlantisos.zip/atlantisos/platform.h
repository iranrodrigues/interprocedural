typedef struct {} uint32;
typedef struct {} uintn;
typedef struct {} uint16;
typedef struct {} uint64;
typedef struct {} Elf32_Half;
typedef struct {} Elf32_Word;
typedef struct {} Elf32_Entry_Point;
typedef struct {} Elf32_Off;
typedef struct {} Elf32_Addr;
typedef struct {} uint8;
typedef struct {} mutex_t;
typedef struct {} tid_t;
typedef struct {} pid_t;
typedef struct {} pm_entry;
typedef struct {} pf_handler;
typedef struct {} ih_handler;
typedef struct {} xh_handler;
typedef struct {} process_status_t;
typedef struct {} thread_state_t;
typedef struct {} va_list;
typedef struct {} obj_t;
typedef struct {} tramp_func;
typedef struct {} iosa_handle_t;
typedef struct {} dma_handle_t;
typedef struct {} command;
typedef struct {} iosa_reach_t;
typedef struct {} bool;
#define A
#define __KERNEL_BOOT_HEADER
#define PAGING_H
#define DEFINES_H
#define true 1
#define false 0
#define NULL (void *)0
#define AL_FL_WRITABLE 0x0002
#define AL_FL_USERACC  0x0004
#define AL_FL_GLOBAL   0x0001
#define AL_FL_NOEXEC   0x0008
#define CINIT_H
#define PAGING_START_H
#define LOADER_H
#define DEBUG_H
#define ELF_H
#define FLOPPY_H
#define invlpg(x) __asm__ __volatile__ ("invlpg (%0)"::"m"(*(char *)x))
#define __KERNEL_ASM_MACROS
#define __KERNEL_I386_ASM_MACROS
#define outb(x,y) asm("\toutb %%dx, %%al"::"d"(x),"a"(y))
#define outw(x,y) asm("\toutw %%dx, %%ax"::"d"(x),"a"(y))
#define outd(x,y) asm("\toutl %%dx, %%eax"::"d"(x),"a"(y))
#define __KERNEL_CONFIG_IA32
#define WORD_LENGTH 32
#define RUNCALL
#define __KERNEL_CORE_FP_FP_LOCAL
#define __KERNEL_DEFINES
#define __KERNEL_TYPES
#define PAGE_FRAME_MAJOR 0xC
#define PAGE_FRAME_MINOR 0x3
#define PAGE_FRAME_KERNEL 0x8
#define PAGE_FRAME_USER 0x4
#define PAGE_FRAME_ISKERNEL(x) (((x).state & PAGE_FRAME_MAJOR) == PAGE_FRAME_KERNEL)
#define PAGE_FRAME_ISFREE(x) (((x).state == PAGE_FREE) || ((x).state == PAGE_ZEROED))
#define PAGE_FRAME_ISUSER(x) (((x).state & PAGE_FRAME_MAJOR) == PAGE_FRAME_USER)
#define __KERNEL_CORE_FP_FP
#define __KERNEL_CORE_MUTEX_MUTEX
#define __KERNEL_SCHED_H
#define __KERNEL_CORE_PM_PM
#define __KERNEL_CORE_PAGER_PAGER
#define AL_FL_WRITABLE 0x01
#define AL_FL_USERACC 0x02
#define AL_FL_NOEXEC 0x04
#define AL_FL_GLOBAL 0x08
#define AL_FL_PAT 0x10
#define AL_FL_PCD 0x20
#define AL_FL_PWT 0x40
#define PML1BASE (struct pte *)0xFFC00000
#define PML2BASE (struct pte *)0xFFFFF000
#define PAGE_SHIFT 10
#define PAGE_MASK 0xFFFFF
#define invlpg(x) __asm__ __volatile__ ("invlpg (%0)"::"r"(x))
#define __KERNEL_DRIVERS_FP_FP
#define __KERNEL_CORE_HWINT_HWINT
#define __KERNEL_CORE_IH
#define IDT_BASE 0xFF100000
#define TIMER_H
#define __KERNEL_CORE_TEXT_KPRINTF
#define INTERNAL_H
#define __KERNEL_CORE_KMM_KMM
#define __KERNEL_CORE_KPF_KPF
#define HASH_H
#define PML1BASE (struct pte *)0xFFFFFF8000000000
#define PML2BASE (struct pte *)0xFFFFFFFFC0000000
#define PML3BASE (struct pte *)0xFFFFFFFFFFE00000
#define PML4BASE (struct pte *)0xFFFFFFFFFFFFF000
#define PAGE_SHIFT 9
#define PAGE_MASK 0xFFFFFFFFF
#define PML1BASE (struct pte *)0xFF800000
#define PML2BASE (struct pte *)0xFFFFC000
#define PML3BASE (struct pte *)0xFFFFFFE0
#define __KERNEL_CORE_XH_XH
#define __KERNEL_CORE_PM_PM_LOCAL
#define MAX_PID 4095
#define MAX_TID 16383
#define __KERNEL_CORE_PM_PROCESS
#define __KERNEL_CORE_PM_PROCDATA
#define __KERNEL_CORE_PM_GSBASE
#define __KERNEL_CORE_PM_THREAD
#define __KERNEL_CORE_PM_TERMINATOR
#define MAX_PID 16383
#define MAX_TID 65535
#define __KERNEL_CORE_TEXT_TEXT
#define KERNEL_CONSOLE 0
#define va_args(before_first) ((va_list)(before_first)-4)
#define va_arg(type, list, num) (*(type *)(list - num))
#define __KERNEL_CORE_TRAMP_TRAMP
#define __KERNEL_CORE_TRAMP_TRAMP_LOCAL
#define __KERNEL_CORE_XH_XH_ABORT
#define __KERNEL_CORE_XH_XH_KILL
#define __KERNEL_CORE_XH_XH_NORMAL
#define __KERNEL_DRIVERS_FDC
#define __DRIVERS_DRIVER_H
#define __DRIVERS_INT_H
#define __KERNEL_DRIVERS_HWINT
#define outb(x,y) asm("\toutb %%al, %%dx"::"d"(x),"a"(y))
#define outw(x,y) asm("\toutw %%ax, %%dx"::"d"(x),"a"(y))
#define outd(x,y) asm("\toutl %%eax, %%dx"::"d"(x),"a"(y))
#define __KERNEL_DRIVERS_XH
#define __DRIVERS_PAGER_H
#define __KERNEL_DRIVERS_PAGER
#define __DRIVERS_PTC_H
#define __KERNEL_DRIVERS_PM
#define __KERNEL_DRIVERS_SCHED
#define __KERNEL_DRIVERS_KMM
#define kmalloc(x) kmm_malloc(x)
#define kfree(x) kmm_free(x)
#define __KERNEL_DRIVERS_KPRINTF
#define __KERNEL_DRIVERS_MUTEX
#define __KERNEL_DRIVERS_TIMER
#define __DRIVERS_MISC_H
#define __KERNEL_KERNEL_START
