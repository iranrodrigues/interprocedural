/* AtlantisOS source file - /src/boot/elf.c
 *
 * This file loads the elf file from a given constant point in memory to
 * a newly allocated set of pages at the destination as indicated in the
 * elf file.
 *
 * as some parts of the floppy driver code haven't been realised, this code
 * is slightly simpler than it should be. It assumes the elf file is loaded
 * at 0x20000, and does not allocate new pages for it (and thus, doesn't copy
 * it there either)
 *
 * Todo list:
 *   xx-xx-xxxx xx:xx xxxxx - start allocating & copying to new pages which
 *                            also makes loading nmagic & omagic possible
 *   xx-xx-xxxx xx:xx xxxxx - actually take the load address of the kernel 
 *                            as argument, instead of assuming 0x20000
 *
 * Revision history:
 *   31-10-2003 10:45 candy - Separating ELF code from floppy code
 *   31-10-2003 08:35 candy - Creation of this file and the revision history
 */

//#include "paging.h"
//#include "debug.h"
//#include "elf.h"
//#include "boot.h"

void elf_load(struct elf_program_table *entry) {
	struct kernel_boot_header *boot = (struct kernel_boot_header *)0;
	unsigned int i;
	unsigned char *p;

	if (((unsigned int)entry->p_vaddr & 0xFFF) != 0) {
		setup_die("Program segment not aligned to a page.");
	}

	// load the file in real memory
	// assume the file is preloaded at 0x20000
	// so, map in the pages it uses
	for (i=0; i<(((entry->p_memsz - 1) >> 12) + 1); i++) {
		map_page_to_stub(((unsigned int)entry->p_vaddr >> 12) + i,
				 0x20 + (((unsigned int)entry->p_offset) >> 12) + i,
				 AL_FL_WRITABLE | AL_FL_GLOBAL | AL_FL_USERACC);
		if ((((unsigned int)(entry->p_offset) >> 12) + i + 0x20) > boot->TOP1) {
			boot->TOP1 = (((unsigned int)(entry->p_offset) >> 12) + i + 0x20) + 1;
		}
	}
	for (p=entry->p_memsz + entry->p_vaddr; (unsigned int)p<(((unsigned int)(entry->p_memsz + entry->p_vaddr - 1) >> 12) + 1); p++) {
		*p = 0;
	}
}

void elf_check(struct elf_header *head) {
	if (head->e_ident[0] != '\x7F' || head->e_ident[1] != 'E' ||
	    head->e_ident[2] != 'L' || head->e_ident[3] != 'F') {
		setup_die("File is not ELF.");
	}
	if (head->e_ident[4] != 1) {
		setup_die("File is not 32-bit.");
	}
	if (head->e_ident[5] != 1) {
		setup_die("File is not little-endian.");
	}
	if (head->e_ident[6] != 1) {
		setup_die("File is not ELF version 1.");
	}
	if (head->e_type != 2) {
		setup_die("File is not executable.");
	}
	if (head->e_machine != 3) {
		setup_die("File is not for 386+ systems.");
	}
	if (head->e_version != 1) {
		setup_die("File is not ELF version 1.");
	}
	if ((unsigned int)head->e_entry < (unsigned int)0xF0000000) {
		setup_die("Entry point outside of kernel.");
	}
	if (head->e_phoff > 0x80000) {
		setup_die("Program header outside of kernel image.");
	}
	if (head->e_phnum < 1) {
		setup_die("No program headers.");
	}
	if (head->e_phentsize < 0x20) {
		setup_die("Program headers noncompliant with ELF");
	}
}

