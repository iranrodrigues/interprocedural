/* AtlantisOS source file - /src/boot/paging-start.c
 *
 * This file starts up the paging system
 *
 * Todo list:
 *   xx-xx-xxxx xx:xx xxxxx - clean up code
 *
 * Revision history:
 *   31-10-2003 12:57 candy - separate into paging.c and paging_start.c
 *   31-10-2003 08:35 candy - Creation of this file and the revision history
 */

//#include "paging-start.h"
//#include "paging.h"
//#include "debug.h"
//#include "cinit.h"
//#include "boot.h"

#define invlpg(x) __asm__ __volatile__ ("invlpg (%0)"::"m"(*(char *)x))

#ifdef PAE
void cpu_setopts(void) {
	__asm__ (
"	wbinvd			# make sure all shit is written before continuing\n"
"\n"
"	movl %cr4, %eax\n"
"	orl $0xB0, %eax		# enable Global paging, PAE paging, PSE paging and\n"
"	movl %eax, %cr4		# disable the RDTSC instruction from user space\n"
"\n"
#error FIXME find out what this address below should be
"	movl $0x00FE0, %eax	# load the page directory pointer table (and the\n"
"	movl %eax, %cr3		# ones below it) in the cpu\n"
"\n"
"	movl %cr0, %eax\n"
"	orl $0x80000000,%eax	# enable Paging itself\n"
"	movl %eax, %cr0\n"
#error dito
"	movl $0x00FE0, %eax	# load the page directory pointer table (and t\n"
"	movl %eax, %cr3		# ones below it) in the cpu\n"
"\n"
"	invd");
}
#else /* PAE */
void cpu_setopts(void) {
        __asm__ (
"	wbinvd			# make sure all shit is written before continuing\n"
"\n"
"	movl $0x2000, %eax	# load the page directory table (and the\n"
"	movl %eax, %cr3		# ones below it) in the cpu\n"
"\n"
"	movl %cr0, %eax\n"
"	orl $0x80000000, %eax	# enable Paging itself\n"
"	movl %eax, %cr0\n"
"	movl $0x2000, %eax	# load the page directory pointer table (and t\n"
"	movl %eax, %cr3		# ones below it) in the cpu\n"
"\n"
"	invd");
}
#endif /* PAE */

void setup_paging(void) {
	// sets up paging tables
	struct kernel_boot_header *boot= (struct kernel_boot_header *)0;

	struct pte *cp = (struct pte *)0x2000;
	unsigned int i;

	cp = (struct pte *)0x2000;

#ifdef PAE
	// in pae
	// note that in 32-bit PAE the 32-byte top level table is NOT here
	// its in the 32-bit process image

	// as such, it can only be set as soon as the process management is up
	// since this is NOT to rely on the process management, it sets up
	// a temporary table in the bootup block
	// this table will be copied in the next bit of code, and thus the 
	// chicken&egg problem is gone

	// identity-map of 0xFFFFF000
	cp[0x1FF].p = 1;
	cp[0x1FF].pwt = 1;
	cp[0x1FF].pcd = 1;
	cp[0x1FF].addr = 0x2;

	// map of 0xF4000000
	cp[0x1A0].p = 1;
	cp[0x1A0].pwt = 1;
	cp[0x1A0].pcd = 1;
	cp[0x1A0].addr = 0x4;

	// map of 0xF0000000
	cp[0x180].p = 1;
	cp[0x180].pwt = 1;
	cp[0x180].pcd = 1;
	cp[0x180].addr = 0x3;

	// map of 0xD4000000
        cp[0x0A0].p = 1;
        cp[0x0A0].pwt = 1;
        cp[0x0A0].pcd = 1;
        cp[0x0A0].addr = 0x8;

	// map of 0xD0000000
        cp[0x080].p = 1;
        cp[0x080].pwt = 1;
        cp[0x080].pcd = 1;
        cp[0x080].addr = 0x7;

	// map of 0xC0000000
        cp[0x000].p = 1;
        cp[0x000].pwt = 1;
        cp[0x000].pcd = 1;
        cp[0x000].addr = 0x9;

	boot->TOP4 = 0xC;

	cp = (struct pte *)0xA000;
#else
	// identity-map of 0xFFFFF000
	cp[0x3FF].p = 1;
	cp[0x3FF].pwt = 1;
	cp[0x3FF].pcd = 1;
	cp[0x3FF].addr = 0x2;

	// mapping of 0xF4000000
	cp[0x3D0].p = 1;
	cp[0x3D0].pwt = 1;
	cp[0x3D0].pcd = 1;
	cp[0x3D0].addr = 0x4;

	// mapping of 0xF0000000
	cp[0x3C0].p = 1;
	cp[0x3C0].pwt = 1;
	cp[0x3C0].pcd = 1;
	cp[0x3C0].addr = 0x3;

	// mapping of 0xD0000000
	cp[0x340].p = 1;
	cp[0x340].pwt = 1;
	cp[0x340].pcd = 1;
	cp[0x340].addr = 0x7;

	// mapping of 0xD4000000
	cp[0x350].p = 1;
	cp[0x350].pwt = 1;
	cp[0x350].pcd = 1;
	cp[0x350].addr = 0x8;

	// mapping of 0xC0000000
	cp[0x300].p = 1;
	cp[0x300].pwt = 1;
	cp[0x300].pcd = 1;
	cp[0x300].addr = 0x9;
	boot->TOP4 = 0xA;

#endif

	cp[0].p = 1;
	cp[0].pwt = 1;
	cp[0].pcd = 1;
	cp[0].addr = 0x6;

	cp = (struct pte *)0x6000;
	for (i=0; i<(0x1000 / sizeof(struct pte)); i++) {
		cp[i].p = 1;
		cp[i].us = 1;
		cp[i].rw = 1;
		cp[i].pwt = 1;
		cp[i].pcd = 1;
		cp[i].addr = i;
	}

	cp = (struct pte *)0x9000;
	// init a page to point to the page table
	// this is atm statically page 0x1F
	cp[0].p = 1;
	cp[0].rw = 1;
	cp[0].us = 1;
	cp[0].pwt = 1;
	cp[0].pcd = 1;
	cp[0].addr = 0x1F;
	cp[1].p = 1;
	cp[1].rw = 1;
	cp[1].us = 1;
	cp[1].pwt = 1;
	cp[1].pcd = 1;
	cp[1].addr = 0x1E;
	boot->TOP1 = 0;
	boot->TOP3 = 0x102;		// may NOT be 0
	boot->TOP2 = 0x101; // will only be put to use as soon as the .init sections are in use

	cpu_setopts();
}
