/* AtlantisOS source file - /src/boot/cinit.c
 *
 * This file takes care of doing the initial initialisation of the processor.
 * The processor is put into 32-bit protected mode in the setup.asm code, and
 * this code determines the memory size, adds paging and loads and pages the 
 * actual kernel. 
 *
 * Todo list:
 *   xx-xx-xxxx xx:xx xxxxx - rewriting to make use of e820 memory map
 *   xx-xx-xxxx xx:xx xxxxx - adding code to distinguish between 32 and 64 
 *                            bit processors, and loading the appropriate 
 *                            kernel
 *
 * Revision history:
 *   31-10-2003 08:35 candy - Creation of this file and the revision history
 */

//#include "cinit.h"
//#include "paging-start.h"
//#include "loader.h"

void _start() {
	/* this is a sort of C entry point in the setup routines.
	 * PM is active for about 10 cycles, do all things that
	 * cannot be done in the kernel with paging activated. These
	 * include determining the amount of memory, setting up paging and
	 * loading the kernel
	 */
// 	determine_memory(); // disabled until E820 support is here
	setup_paging();
	load_kernel();
}

// this function sucks. The optimizer optimizes the entire function away, so
// it needs a proper rewrite. 
uint64 determine_memory() {
	/* this function determines how much memory is installed,
	 * so as to use it to the fullest extent.
	 * assumes: at least 8 MB of memory is present
	 * assumes: the first MB has the default logic
	 * assumes: memory is present in full MBs (the last half
	 * assumes:   or so might miss without detection)
	 * assumes: there is less than 4GB memory
	 */
	// test patterns that contain alternating ones and zeroes
	char y=0x55, z=0xAA;

	// the first target for the memory test
	char *target = (char *)0x8FFFFC;

	while (true) {
		// write a value
		*target = y;
		// clear the data lines to the inverse
		*(target-1) = z;
		// if the value read back is not what you wrote, break
		if (y != (*target)) break;

		// same for the other pattern
		*target = z;
		// clearing the data lines
		*(target-1) = y;
		// and testing whether the read value is what we wrote
		if (z != (*target)) break;

		// if it gets to this point the target physical address 
		// space has shown a memory function (if you write
		// something it can be read back)
		// so, we assume it's memory and move to the next MB
		target += 0x100000;
	}
	target = (char *)((int)target & 0xFFF00000);
	// target contains the exact number of bytes of memory
	return (int)target;
}
