/* AtlantisOS source file - /src/boot/cinit.h
 *
 * This file contains the function prototypes of the initial functions. 
 *
 * Todo list:
 *   xx-xx-xxxx xx:xx xxxxx - adding code to distinguish between 32 and 64
 *                            bit processors, and loading the appropriate
 *                            kernel
 *
 * Revision history:
 *   31-10-2003 08:35 candy - Creation of this file and the revision history
 */

#ifndef CINIT_H
#define CINIT_H

//#include "defines.h"

void _start(void);
uint64 determine_memory(void);

#endif

