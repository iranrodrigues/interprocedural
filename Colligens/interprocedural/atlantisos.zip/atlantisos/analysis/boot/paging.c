/* AtlantisOS source file - /src/boot/paging.c
 *
 * This file starts up the paging system
 *
 * Todo list:
 *   xx-xx-xxxx xx:xx xxxxx - clean up code
 *   xx-xx-xxxx xx:xx xxxxx - separate into paging.c and paging_start.c
 *
 * Revision history:
 *   31-10-2003 08:35 candy - Creation of this file and the revision history
 */

//#include "paging.h"
//#include "cinit.h"
//#include "debug.h"
//#include "boot.h"

#define invlpg(x) __asm__ __volatile__ ("invlpg (%0)"::"m"(*(char *)x))

int gfp_cur = 0x100;

uint32 get_free_page_stub(void) {
	struct kernel_boot_header *boot = (struct kernel_boot_header *)0;

	gfp_cur++;

	boot->TOP3 = gfp_cur;

	return gfp_cur-1;
}

void map_page_to_stub(uintn todovirt, uintn todophys, uint16 flags) {
	int t;
	struct pte *entries;
	int nphys;

#ifdef PAE
	entries = (struct pte *)0xFFFFFFE0;
	t = ((unsigned int)todovirt >> 18) & 0x3;

	if (entries[t].p == 0) {
		map_page_to_stub(((todovirt >> 18) & 0x3) | 0xFFFFC, get_free_page_stub(), AL_FL_WRITABLE | AL_FL_USERACC);
	}

	entries = (struct pte *)0xFFFFC000;
	t = (todovirt >> 9) & 0x7FF;

	if (entries[t].p == 0) {
		map_page_to_stub(((todovirt >> 9) & 0x7FF) | 0xFF800, get_free_page_stub(), AL_FL_WRITABLE | AL_FL_USERACC);
	}

	entries = (struct pte *)0xFF800000;
#else
	entries = (struct pte *)0xFFFFF000;
	t = (todovirt >> 10) & 0x3FF;

	if (entries[t].p == 0) {
		nphys = get_free_page_stub();
		map_page_to_stub(((todovirt >> 10) & 0x3FF) | 0xFFC00, nphys, AL_FL_WRITABLE | AL_FL_USERACC);
		entries[t].p = 1;
		entries[t].rw = 1;
		entries[t].us = 1;
		entries[t].pwt = 1;
		entries[t].pcd = 1;
		entries[t].addr = nphys;
	}

	entries = (struct pte *)0xFFC00000;
#endif

	t = todovirt;

	entries[t].addr = todophys;
	entries[t].p = 1;
	if (flags & AL_FL_WRITABLE) entries[t].rw = 1; else entries[t].rw = 0;
	if (flags & AL_FL_USERACC) entries[t].us = 1; else entries[t].us = 0;
	entries[t].us = 1;
	entries[t].rw = 1;
	entries[t].pwt = 1;
	entries[t].pcd = 1;
}

void allocate_page_to_stub(uintn virt, uint16 flags) {
	map_page_to_stub(virt, get_free_page_stub(), flags);
}

