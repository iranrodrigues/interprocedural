/* AtlantisOS source file - /src/boot/floppy.c
 *
 * This file is solely responsible for loading files and handling the FAT12
 * code.
 * 
 * It has functions for determining file size, and functions for loading
 * files given by name to a given destination point
 *
 * Because I don't feel like doing the floppy code this code doesn't exist
 * yet.
 *
 * Todo list:
 *   xx-xx-xxxx xx:xx xxxxx - make the code
 *
 * Revision history:
 *   31-10-2003 08:35 candy - Creation of this file and the revision history
 */

//#include "cinit.h"
//#include "floppy.h"

// until the real floppy driver for setup is made, the kernel will be loaded
// by the boot sector at 0x20000 up to 0xA0000 (max is thus 512k)

