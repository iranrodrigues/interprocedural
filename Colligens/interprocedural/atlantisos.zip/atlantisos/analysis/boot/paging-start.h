/* AtlantisOS source file - /src/boot/paging-start.h
 *
 * This file contains all the paging setup functions.
 *
 * Todo list:
 *   xx-xx-xxxx xx:xx xxxxx - Clean up code
 *   xx-xx-xxxx xx:xx xxxxx - Make code support 64-bit paging
 *
 * Revision history:
 *   31-10-2003 13:02 candy - Separate into multiple files
 *   31-10-2003 08:35 candy - Creation of this file and the revision history
 */
// for 64-bit sometime soon, the page that maps himself will be at 
// 1111.1111.0111.1111.1011.1111.1101.1111.1110.0000.0000.0000 = FF7F_BFDF_E000

#ifndef PAGING_START_H
#define PAGING_START_H

//#include "defines.h"

extern int gfp_cur;

void cpu_setopts(void);
void setup_paging(void);

#endif /* !PAGING_START_H */
