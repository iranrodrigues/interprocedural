/* AtlantisOS source file - /src/boot/paging.h
 *
 * This file contains the functions to use the paging functionality, and a 
 * number of  functions that is used by the paging functions to keep the 
 * processor up to date.
 *
 * Todo list:
 *   xx-xx-xxxx xx:xx xxxxx - Clean up code
 *   xx-xx-xxxx xx:xx xxxxx - Make code support 64-bit paging
 *
 * Revision history:
 *   31-10-2003 13:05 candy - Separate into multiple files
 *   31-10-2003 08:35 candy - Creation of this file and the revision history
 */
// for 64-bit sometime soon, the page that maps himself will be at 
// 1111.1111.0111.1111.1011.1111.1101.1111.1110.0000.0000.0000 = FF7F_BFDF_E000

#ifndef PAGING_H
#define PAGING_H

//#include "defines.h"

extern int gfp_cur;

uint32 get_free_page_stub(void);
void map_page_to_stub(uintn todovirt, uintn todophys, uint16 flags);
void allocate_page_to_stub(uintn virt, uint16 flags);

#define AL_FL_WRITABLE 0x0002
#define AL_FL_USERACC  0x0004
#define AL_FL_GLOBAL   0x0001
#define AL_FL_NOEXEC   0x0008

#ifndef PAE
struct pte {
        uint64 p:1;
        uint64 rw:1;
        uint64 us:1;
        uint64 pwt:1;
        uint64 pcd:1;
        uint64 a:1;
        uint64 d:1;
        uint64 pat:1;
        uint64 g:1;
        uint64 avl1:3;
        uint64 addr:20;
};
#else /* !PAE */
struct pte {
	uint64 p:1;
	uint64 rw:1;
	uint64 us:1;
	uint64 pwt:1;
	uint64 pcd:1;
	uint64 a:1;
	uint64 d:1;
	uint64 pat:1;
	uint64 g:1;
	uint64 avl1:3;
	uint64 addr:40;
	uint64 avl2:11;
	uint64 nx:1;
};
#endif /* !PAE */
#endif /* !PAGING_H */
