#ifndef __KERNEL_BOOT_HEADER
#define __KERNEL_BOOT_HEADER

#ifndef PAGING_H
#ifndef __KERNEL_CORE_PAGER_PAGER
//#include "paging.h"
#endif
#endif

struct kernel_boot_header {
	struct {
		unsigned short int offset, segment;
	} ivt[256];

	char bda[512];

#ifdef PAE
	struct pte boot_pdpt[4];
#else
	char pad1[32];
#endif
	struct {
		unsigned long long offset;
		unsigned long long size;
		unsigned long type;
		unsigned long pad;
	} e820_map[16];
 
	// memory structure:
	// 0-1 = this
	// 1-2 = IDT + GDT
	// 2-TOP4 = page frames in use for page tables
	// TOP4-20 = free
	// 20-TOP1 = temp in use
	// TOP1-9F = free
	// 100-TOP2 = temp in use
	// TOP2-TOP3 = kernelspace mapped
	// TOP3-1FF = free

	unsigned int TOP1, TOP2, TOP3, TOP4;

	char pad[1104];
	char ebda[1024];
};

#endif

