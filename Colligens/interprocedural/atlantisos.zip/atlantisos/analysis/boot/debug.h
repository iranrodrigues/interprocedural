/* AtlantisOS source file - /src/boot/debug.h
 *
 * This file contains the debug function definitions.
 *
 * Todo list:
 *   xx-xx-xxxx xx:xx xxxxx - Make a decent debug system from this
 *
 * Revision history:
 *   31-10-2003 08:35 candy - Creation of this file and the revision history
 */

#ifndef DEBUG_H
#define DEBUG_H

void setup_die(char *x);
void print_num(unsigned int num);

#endif

