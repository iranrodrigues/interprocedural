/* AtlantisOS source file - /src/boot/floppy.h
 *
 * This file has the functions definitions for all floppy functions
 *
 * At the moment, no floppy handling code exists, so this file is empty.
 *
 * Todo list:
 *   xx-xx-xxxx xx:xx xxxxx - make the floppy driver
 *
 * Revision history:
 *   31-10-2003 08:35 candy - Creation of this file and the revision history
 */

#ifndef FLOPPY_H
#define FLOPPY_H

#endif

