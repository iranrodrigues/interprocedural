/* AtlantisOS source file - /src/boot/debug.c
 *
 * This file contains the heart of the debug functions.
 * 
 * Todo list:
 *   xx-xx-xxxx xx:xx xxxxx - Make some sensible debug system
 *
 * Revision history:
 *   31-10-2003 08:35 candy - Creation of this file and the revision history
 */

//#include "debug.h"

void setup_die(char *why) {
	char *vidmem = (char *)0xB8000;
	while(*why != 0) {
		*vidmem++ = *why++;
		*vidmem++ = 007;
	}
	while(1);
}

void print_num(unsigned int num) {
	char *vidmem = (char *)0xB80A0;
	int i;

	for (i=0; i<8; i++) {
		vidmem[2*i] = ((num >> (28-4*i)) & 0xF) + '0';
		if (vidmem[2*i] > '9') vidmem[2*i] += 7;
	}
}

