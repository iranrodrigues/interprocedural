/* AtlantisOS source file - /src/boot/loader.h
 *
 * This file contains the load_kernel function. It is responsible for loading
 * the kernel using lots of other functions.
 * 
 * Todo list:
 *   xx-xx-xxxx xx:xx xxxxx - Change to use floppy loading mechanism
 *   xx-xx-xxxx xx:xx xxxxx - adding code to distinguish between 32 and 64
 *                            bit processors, and loading the appropriate
 *                            kernel
 *   xx-xx-xxxx xx:xx xxxxx - finishing up
 *
 * Revision history:
 *   31-10-2003 08:35 candy - Creation of this file and the revision history
 */

#ifndef LOADER_H
#define LOADER_H

void load_kernel(void);

#endif

