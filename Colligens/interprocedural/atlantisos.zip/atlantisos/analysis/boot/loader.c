/* AtlantisOS source file - /src/boot/loader.c
 *
 * This file contains the code for load_kernel. It selects which kernel to
 * load, orders the paging subsystem to make room, the floppy subsystem to
 * load it and the elf subsystem to make it runnable. Then, it runs it.
 * 
 * Todo list:
 *   xx-xx-xxxx xx:xx xxxxx - Make the kernel loadable
 *   xx-xx-xxxx xx:xx xxxxx - Determine which kernel to load
 *   xx-xx-xxxx xx:xx xxxxx - actually copy it to different pages
 *
 * Revision history:
 *   31-10-2003 08:35 candy - Creation of this file and the revision history
 */

//#include "cinit.h"
//#include "floppy.h"
//#include "elf.h"
//#include "debug.h"
//#include "loader.h"

void load_kernel(void) {
	struct elf_header *head = (struct elf_header *)0x20000;
	struct elf_program_table *pt = (struct elf_program_table *)(0x20000 + head->e_phoff);
	int i;

	// check the ELF header for all required things, such as right 
	// machine etc
	elf_check(head);

	// loop through all program header table entries
	for (i=0; i<head->e_phnum; i++) {
		elf_load(&pt[i]);
	}

	// elf file loaded
	head->e_entry();	// doesn't return
}

