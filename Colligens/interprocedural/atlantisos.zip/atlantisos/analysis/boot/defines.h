/* AtlantisOS source file - /src/boot/defines.h
 *
 * This file contains the defines that are used in the kernel, which are also
 * needed in the setup routine. These include the definition of NULL, true 
 * and false, as well as the default int types (uintX and sintX).
 *
 * Revision history:
 *   31-10-2003 08:35 candy - Creation of this file and the revision history
 */

#ifndef DEFINES_H
#define DEFINES_H

// unsigned of varying formats
typedef unsigned long		uintn;
typedef unsigned char		uint8;
typedef unsigned short int	uint16;
typedef unsigned int		uint32;
typedef unsigned long long	uint64;

// signed of varying formats
typedef signed long		sintn;
typedef signed char		sint8;
typedef signed short int	sint16;
typedef signed int		sint32;
typedef signed long long	sint64;

#define true 1
#define false 0
#define NULL (void *)0

//#include "config.h"

#endif
