#ifndef __KERNEL_CORE_TRAMP_TRAMP_LOCAL
#define __KERNEL_CORE_TRAMP_TRAMP_LOCAL

//#include <kernel/defines.h>

#if FAMILY==2 && WORD_LENGTH==64
// 64-bit cpl3 entry point
uintn tramp_syscall_64(uintn a, uintn b, uintn c, uintn d, uintn e);
#endif

#if FAMILY==2
// 32-bit cpl3 entry point, amd
uintn tramp_syscall_32(uintn a, uintn b, uintn c, uintn d, uintn e);
#else
// 32-bit cpl3 entry point, intel
uintn tramp_sysenter(uintn a, uintn b, uintn c, uintn d, uintn e);
#endif

extern struct {
	uintn (*func)(uintn a, uintn b, uintn c, uintn d, uintn e);
	uintn numargs;
} tramp_functions[] = {
        {&tramp_sbrk, 1},
        {&tramp_create_thread, 3},
        {&tramp_create_process, 3},
        {&tramp_exit, 0},
        {&tramp_kill_thread, 1},
        {&tramp_kill_process, 1},
        {&tramp_get_object, 2},
        {&tramp_set_object_var, 3},
        {&tramp_get_object_var, 2},
        {&tramp_return_object, 1},
        {0, 0}
};

extern uintn tramp_max_funcs;

//  functionality:
//memory:
// Enlarge the user level memory space by (at least) nbytes bytes
char *tramp_sbrk(uint32 bytes);

//processes:
// create thread in current context
void tramp_create_thread(void (*start)(void *arg), void *arg, uint32 flags);
// create thread in new context
void tramp_create_process(void (*start)(void *arg), void *arg, uint32 flags);
// exit thread in current context, and delete process if its the last
// never returns
void tramp_exit();

// kill thread in current process
uintn tramp_kill_thread(tid_t thread);
// kill process including all threads
uintn tramp_kill_process(pid_t process);

//objects:
// get an object from the kernel object repository
obj_t *tramp_get_object(uint32 type, uint32 num);

// set a value on an object, aka configure
void tramp_set_object_var(obj_t *object, int number, void *value);
// retrieves a value on an object, aka read configuration
void *tramp_get_object_var(obj_t *object, int number);

// return an object to the kernel repository (it is never removed,
// but the reference count will be reduced)
void tramp_return_object(obj_t *object);

#endif
