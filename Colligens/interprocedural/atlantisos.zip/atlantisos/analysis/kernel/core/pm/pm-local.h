#ifndef __KERNEL_CORE_PM_PM_LOCAL
#define __KERNEL_CORE_PM_PM_LOCAL

//#include <kernel/defines.h>

#if WORD_LENGTH==32
#define MAX_PID 4095
#define MAX_TID 16383
#else
#define MAX_PID 16383
#define MAX_TID 65535
#endif

extern tid_t pm_terminator_thread;

#endif
