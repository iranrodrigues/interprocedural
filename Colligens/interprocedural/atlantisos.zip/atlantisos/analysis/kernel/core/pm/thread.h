#ifndef __KERNEL_CORE_PM_THREAD
#define __KERNEL_CORE_PM_THREAD

//#include <kernel/defines.h>

// somehow I can't figure out how to make an enum typedef of type uint8
enum {THREAD_NONE, THREAD_RUNNING, THREAD_AVAILABLE, THREAD_BLOCKED, THREAD_SWAPPED, THREAD_SWAPPEDBLOCKED, THREAD_DEAD, THREAD_NEW};
typedef uint8 thread_state_t;

struct thread {
	uintn eax, ecx, edx, ebx, esi, edi, esp, ebp;
#if WORD_LENGTH==64
	uintn r8, r9, r10, r11, r12, r13, r14, r15;
#endif

	uintn kernelstackbase;
	uintn kernelstack;
	uintn stackbase;
	uintn stack;
	uintn fsbase;

	uint16 pid;
	uint8 priority;
	uint8 quantum;
	thread_state_t state;
	uint8 unblocks;
	uint16 killed:1;
	uint16 type:3;
	uint16 signal_waiting:1;
	uint16 pad:11;

	uint16 next;
	uint16 previous;

#if WORD_LENGTH==32
	char pad2[448];
#else
	char pad2[332];
#endif

	char xmm_state_area[512];
};

extern struct thread *pm_tids;
extern mutex_t pm_tids_mutex;
extern tid_t pm_terminator_thread;

#endif
