#ifndef __KERNEL_CORE_PM_PROCDATA
#define __KERNEL_CORE_PM_PROCDATA

//#include <kernel/defines.h>
//#include <kernel/core/xh/xh.h>

struct procdata {
	uintn gs_off;

	tid_t cthread;
	pid_t cprocess;
	uint8 quantum;

	xh_handler xh_table[32];
};

#endif
