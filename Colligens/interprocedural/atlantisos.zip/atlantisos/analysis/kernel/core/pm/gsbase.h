#ifndef __KERNEL_CORE_PM_GSBASE
#define __KERNEL_CORE_PM_GSBASE

//#include <kernel/defines.h>
//#include <kernel/core/pm/procdata.h>

struct procdata *gs_base(void);
void gs_init(void);

#endif
