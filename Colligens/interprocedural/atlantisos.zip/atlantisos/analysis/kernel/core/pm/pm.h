#ifndef __KERNEL_CORE_PM_PM
#define __KERNEL_CORE_PM_PM

//#include <kernel/defines.h>

void pm_init(void);

// information functions
tid_t pm_get_current_thread(void);
char *pm_get_name(pid_t process);
pid_t pm_get_pid(tid_t thread);

typedef void (*pm_entry)(void);

// the functions that are only for fp
uintn pm_get_pagetable_entry(pid_t process);
void pm_set_pagetable_entry(pid_t process, uintn value);

// returns only if pm_get_pid(pm_get_current_thread()) != process
pid_t pm_create_process(void);
tid_t pm_create_thread(pid_t process, pm_entry entrypoint);
void pm_kill_process(pid_t process);
void pm_kill_thread(tid_t thread);
void pm_idle(void);

#endif
