//#include <kernel/core/pm/pm.h>
//#include <kernel/core/pm/pm-local.h>
//#include <kernel/core/pm/procdata.h>
//#include <kernel/core/pm/gsbase.h>
//#include <kernel/core/mutex/mutex.h>
//#include <kernel/core/pm/thread.h>
//#include <kernel/core/pm/process.h>
//#include <kernel/core/pm/terminator.h>

// information functions
tid_t pm_get_current_thread(void) {
	// note: this has to be done with gs offset... fucking gcc is too 
	// stupid to be told some variables are gs-bound...
	// return procdata->cstate->cthread;
	struct procdata *pd;
	pd = gs_base();
	return pd->cthread;
}

char *pm_get_name(pid_t process) {
	return pm_pids[process].procname;
}

pid_t pm_get_pid(tid_t thread) {
	return pm_tids[thread].pid;
}

void pm_idle(void) {
	while(1) asm ("hlt");
}

void pm_init(void) {
	mutex_start(&pm_tids_mutex);
	mutex_start(&pm_pids_mutex);
	mutex_start(&pm_process_mutex);

	pm_create_thread(0, &pm_idle);

	pm_set_pagetable_entry(0, 0);

	// start the terminator
	pm_create_thread(0, &terminator);
}

