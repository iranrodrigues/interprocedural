//#include <kernel/core/pm/process.h>
//#include <kernel/core/pm/thread.h>
//#include <kernel/core/pm/pm.h>
//#include <kernel/core/fp/fp.h>
//#include <kernel/core/pager/pager.h>
//#include <kernel/core/mutex/mutex.h>
//#include <kernel/core/sched/sched.h>
//#include <kernel/defines.h>

#if WORD_LENGTH==32
struct process *pm_pids = (struct process *)0xFF102000;
#else
struct process *pm_pids = (struct process *)0xFFFFFF8040208000;
#endif

mutex_t pm_pids_mutex;

mutex_t pm_process_mutex;

pid_t pm_create_process(void) {
	uint32 *pt_old = (uint32 *)0xFFFFF000, *pt_new = (uint32 *)0xFF300000;
	uintn page_num = fp_get_free_page();
	struct pte *page_table;
	int i;

	// create memory space for the new process
	// to do that, allocate a few pages and fill them with the to-be-page-tables
	mutex_wait(&pm_process_mutex);

	pager_map_page(0xFF300, page_num, AL_FL_WRITABLE);

	// non-pae: the top 64 pages, minus the last one, from 0xFFFFF to be copied to 0xFF300
	// these are kernel pages, never to be freed
	// the last page must map to the physical address of the page itself

#ifndef PAE
	for (i=0x3C0; i<0x3FF; i++) {
		pt_new[i] = pt_old[i];
	}

	page_table = (struct pte *)0xFF300000;

	page_table[0x3FF].p = 1;
	page_table[0x3FF].addr = page_num;
	page_table[0x3FF].rw = 1;
#else
	for (i=0x380; i<0x3FF; i++) {
		pt_new[i] = pt_old[i];
	}

	page_table = (struct pte *)0xFF300000;

	page_table[0x1FF].p = 1;
	page_table[0x1FF].addr = page_num;
	page_table[0x1FF].rw = 1;
#endif

	pager_unmap(0xFF300);

	mutex_release(&pm_process_mutex);

	// find a free pid
	mutex_wait(&pm_pids_mutex);

	i=1;
	while(pm_pids[i].cr3 != 0) i++;

	pm_pids[i].cr3 = page_num << 12;
//	pm_pids[i].filetab = 
//	pm_pids[i].sighandler = 
//	pm_pids[i].accounting =

	mutex_release(&pm_pids_mutex);

	return i;
}

void pm_kill_process(pid_t process) {
	// killing a process is killing all threads, and then signaling the terminator (maid) to clean up
	mutex_wait(&pm_pids_mutex);

	// if the process is not active (doesnt exist), dont do anything.
	if (pm_pids[process].status != PROCESS_ACTIVE) {
		mutex_release(&pm_pids_mutex);
		return;
	}

	pm_pids[process].status = PROCESS_DEAD;

	mutex_release(&pm_pids_mutex);

	// send a SMP IPI to tell all processors to check whether their process is marked as PROCESS_DEAD
	// if it is, they should switch to some other process and mark their thread as available
	// even if smp isn't supported yet, I myself still need to check
	// so just call int 31 :)
#ifdef SMP
	smp_send_ipi(all_including_me, 0x31);
#else
	asm ("int $0x31");
#endif

	// at this point, there is a guarantee that no processor is executing this process, nor will any be allowed to do so
	// since there is nothing else to do with actually making sure the process is killed, only that it is reclaimed,
	// leave it as it is now, for the terminator to come along and pick up the remnants
	// note to the terminator, only delete the process as soon as active_threads == 0

	sched_signal(pm_terminator_thread);
}
