#ifndef __KERNEL_CORE_PM_TERMINATOR
#define __KERNEL_CORE_PM_TERMINATOR

void terminator(void);

#endif

