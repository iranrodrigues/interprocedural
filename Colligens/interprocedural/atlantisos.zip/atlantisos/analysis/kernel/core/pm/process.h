#ifndef __KERNEL_CORE_PM_PROCESS
#define __KERNEL_CORE_PM_PROCESS

//#include <kernel/defines.h>
//#include <kernel/core/pager/pager.h>

typedef uint8 process_status_t;

struct process {
	uintn cr3;
	uintn filetab;
	uintn sighandler;
	uintn accounting;
	char *procname;

	// two entities administered by the fp module, they represent the 
	// last link in the chain of pages in use as page or page table
	// in the fp module context.
	// since they are strictly process-dependant, they must be kept
	// in the PM module.
	// there are also the two firsts for these lists, they are here too
	// note too that neither of the two will ever be empty
	uintn pagetable_entry;
	uintn page_entry;

	uintn pagetable_first;
	uintn page_first;

	// in 32-bit PAE there is a need for a 32-byte structure for each process
	// containing the topmost page directory pointer table
#if WORD_LENGTH == 32
#ifdef PAE
	struct pte pdpt[4];
#endif
#endif

	// process status is the state in which the process is right now. 
	// see below for a list
	process_status_t status;
	char pad[27];
};

enum {PROCESS_FREE, PROCESS_ACTIVE, PROCESS_DEAD};

extern struct process *pm_pids;

extern mutex_t pm_pids_mutex;

extern mutex_t pm_process_mutex;

#endif
