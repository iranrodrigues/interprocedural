//#include <kernel/core/pm/pm.h>
//#include <kernel/core/pm/thread.h>
//#include <kernel/core/pm/process.h>
//#include <kernel/core/mutex/mutex.h>
//#include <kernel/core/sched/sched.h>
//#include <kernel/core/kmm/kmm.h>
//#include <kernel/defines.h>

#if WORD_LENGTH==32
struct thread *pm_tids = (struct thread *)0xFE000000;
#else
struct thread *pm_tids = (struct thread *)0xFFFFFF8040210000;
#endif

mutex_t pm_tids_mutex;
uint16 pm_max_tid;

tid_t pm_create_thread(pid_t process, pm_entry entry) {
	int i = 0;
	uintn *returnstack;

	mutex_wait(&pm_tids_mutex);

	while(pm_tids[i].state != THREAD_NONE) i++;

	pm_tids[i].state = THREAD_NEW;

	pm_tids[i].type = 0;
	if (process == 0) pm_tids[i].type = 3;

	if (sched_p[pm_tids[i].type] == 0) {
		pm_tids[i].next = 0;
		sched_p[pm_tids[i].type] = i;
		sched_end[pm_tids[i].type] = i;
	} else {
		// add it to the scheduler stack
		pm_tids[i].next = sched_p[pm_tids[i].type];
		pm_tids[sched_p[pm_tids[i].type]].previous = i;
		sched_p[pm_tids[i].type] = i;
	}

	mutex_release(&pm_tids_mutex);

	pm_tids[i].pid = process;
	pm_tids[i].priority = 20;
	pm_tids[i].quantum = 20;

	pm_tids[i].unblocks = 0;
	pm_tids[i].killed = 0;
	pm_tids[i].signal_waiting = 0;

	pm_tids[i].previous = 0;

	if ((uintn)entry >= (uintn)0xF0000000) {
		// needs a stack in kernel space
		// these threads may not have more than 8k of stack space need........
		// use them only for quick tasks, such as cleaning up in some table or doing initial fills
		pm_tids[i].stackbase = (int)kmm_malloc(8192);	// points to bottom of stack
		pm_tids[i].stack = pm_tids[i].stackbase + 8168;	// points to top of stack

		pm_tids[i].esp = pm_tids[i].stack;

		pm_tids[i].kernelstackbase = 0;
		pm_tids[i].kernelstack = 0;
		returnstack = (uintn *)pm_tids[i].stack;
		returnstack[0] = 0;		// eax
		returnstack[1] = 0x30;		// gs
		returnstack[2] = (uintn)entry;	// eip
		returnstack[3] = 0x8;		// cs
		returnstack[4] = 0x40200;	// eflags
	} else {
		// allocate some user space stack
		// using user space stack allocator...
		pm_tids[i].kernelstackbase = (int)kmm_malloc(8192);
		pm_tids[i].kernelstack = pm_tids[i].kernelstackbase + 8160;

		// XXX - fix user space stack?

		returnstack = (uintn *)pm_tids[i].kernelstack;
		returnstack[0] = 0;		// eax
		returnstack[1] = 0x30;		// gs
		returnstack[2] = (uintn)entry;	// eip
		returnstack[3] = 0x20;		// cs
		returnstack[4] = 0x40200;	// eflags
		returnstack[5] = (uintn)pm_tids[i].stack;	// esp
		returnstack[6] = 0x28;		// ss
	}

	pm_tids[i].state = THREAD_AVAILABLE;

	return i;
}

void pm_kill_thread(tid_t thread) {
	// since just setting the state, sending an IPI and signaling the 
	// terminator would generate a race condition, set the killed flag
	if (thread == 0) return;

	mutex_wait(&pm_tids_mutex);

	if (pm_tids[thread].state == THREAD_NONE ||
	    pm_tids[thread].state == THREAD_DEAD ||
	    pm_tids[thread].killed != false) {
		// if any of these conditions is true, it doesn't exist
		// or it is already dead
		mutex_release(&pm_tids_mutex);
		return;
	}

	pm_tids[thread].killed = true;

	// if present in a list (at any position) remove it
	if (pm_tids[thread].next != 0) {
		pm_tids[pm_tids[thread].next].previous = pm_tids[thread].previous;
	} else {
		if (sched_end[pm_tids[thread].type] == thread) {
			// remove the end
			sched_end[pm_tids[thread].type] = pm_tids[thread].previous;
		}
	}

	if (pm_tids[thread].previous != 0) {
		pm_tids[pm_tids[thread].previous].next = pm_tids[thread].next;
	} else {
		if (sched_p[pm_tids[thread].type] == thread) {
			// remove the start
			sched_p[pm_tids[thread].type] = pm_tids[thread].next;
		}
	}

	pm_tids[thread].next = 0;
	pm_tids[thread].previous = 0;

	mutex_release(&pm_tids_mutex);

	// thread is now officially killed.
	// if the thread appears to be active (running), send a 0x31 IPI
	if (pm_tids[thread].state == THREAD_RUNNING) {
#ifdef SMP
		smp_send_ipi(all_including_me, 0x31);
#else
		asm ("int $0x31");
#endif
	}

	sched_signal(pm_terminator_thread);
}

