//#include <kernel/core/pm/pm.h>
//#include <kernel/core/pm/process.h>
//#include <kernel/core/pm/thread.h>
//#include <kernel/core/pm/terminator.h>
//#include <kernel/core/sched/sched.h>

tid_t pm_terminator_thread;

void terminator(void) {
	while(1) {
		// do some termination things
		sched_block();
	}
}
