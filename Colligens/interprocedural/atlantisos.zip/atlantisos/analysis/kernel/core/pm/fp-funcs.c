//#include <kernel/core/pm/pm.h>
//#include <kernel/core/pm/pm-local.h>
//#include <kernel/core/pm/process.h>
//#include <kernel/core/mutex/mutex.h>

// these functions are only for fp usage, so they do not use the mutex that
// is otherwise mandatory for access to the pm_pids table. It would only slow
// down both modules.

uintn pm_get_pagetable_entry(pid_t process) {
	return pm_pids[process].pagetable_entry;
}

void pm_set_pagetable_entry(pid_t process, uintn value) {
	pm_pids[process].pagetable_entry = value;
}

