//#include <kernel/core/pm/procdata.h>
//#include <kernel/core/pm/gsbase.h>

struct procdata *gs_base (void) {
	struct procdata *toreturn;
	asm("	xorl	%%ebx, %%ebx\n"
	    "	movl	%%gs:(%%ebx), %0\n"
	    : "=r"(toreturn) :: "ebx");
	return toreturn;
}

void gs_init(void) {
	struct procdata *procdata = (struct procdata *)0xFF000000;
	procdata->gs_off = (uintn)procdata;

	procdata->cthread = 0;
	procdata->cprocess = 0;
	procdata->quantum = 1;
}
