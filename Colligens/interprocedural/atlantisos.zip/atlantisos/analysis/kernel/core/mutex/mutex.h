#ifndef __KERNEL_CORE_MUTEX_MUTEX
#define __KERNEL_CORE_MUTEX_MUTEX

//#include <kernel/defines.h>

void mutex_start(uint8 *mutex);
void mutex_wait(uint8 *mutex);
void mutex_wait_long(uint8 *mutex);
void mutex_release(uint8 *mutex);
void mutex_stop(uint8 *mutex);

#endif
