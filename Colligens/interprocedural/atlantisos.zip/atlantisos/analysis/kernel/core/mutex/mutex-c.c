/*
 * This is kernel code that is NOT for user access! These functions allow a 
 * mutex to be defined (mutex_start), a quick spinlock to be done 
 * (mutex_wait), a slow wait to be done (mutex_wait_long), the mutex to
 * be released again (mutex_release) and the mutex to be undefined 
 * (mutex_stop)
 * 
 * When creating a kernel mutex, define it with value 0 since that will never
 * allow the mutex to fail.
 */
//#include <kernel/core/mutex/mutex.h>
//#include <kernel/defines.h>

void mutex_start(uint8 *mutex) {
	// simple, put in a 1 without checking what was in there. Mutexes
	// should only be started once, and before any use. If you do not
	// comply, you will only shit yourself.
	*mutex = 1;
}

/* at the moment, taking a mutex permanently simply disables the mutex 
 * function, which is what should happen if the mutex is never to be
 * accessed again.
 */
void mutex_stop(uint8 *mutex) {
	mutex_wait(mutex);
}

