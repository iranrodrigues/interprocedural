#ifndef __KERNEL_CORE_FP_FP_LOCAL
#define __KERNEL_CORE_FP_FP_LOCAL

//#include <kernel/defines.h>

void fp_initial_filler(void);

extern struct page_frame *page_frames;
extern uint16 page_frame_list[16];
extern uint16 page_frame_lend[16];
extern mutex_t page_frame_list_mutex[16];
extern mutex_t page_frame_mutex;

enum page_frame_states {
	PAGE_BAD,
	PAGE_UNCHECKED,
	PAGE_FREE,
	PAGE_ZEROED,
	PAGE_USERSPACE_MAPPED,
	PAGE_TABLE = 7,
	PAGE_KERNELSPACE_MAPPED = 8,
	PAGE_KERNELSPACE_LOCKED,
	PAGE_KERNELSPACE_TEMP_MAPPED,
	PAGE_UNKNOWN = 15
};

#define PAGE_FRAME_MAJOR 0xC
#define PAGE_FRAME_MINOR 0x3
#define PAGE_FRAME_KERNEL 0x8
#define PAGE_FRAME_USER 0x4

#define PAGE_FRAME_ISKERNEL(x) (((x).state & PAGE_FRAME_MAJOR) == PAGE_FRAME_KERNEL)
#define PAGE_FRAME_ISFREE(x) (((x).state == PAGE_FREE) || ((x).state == PAGE_ZEROED))
#define PAGE_FRAME_ISUSER(x) (((x).state & PAGE_FRAME_MAJOR) == PAGE_FRAME_USER)

#endif
