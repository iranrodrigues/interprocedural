//#include <kernel/core/fp/fp.h>
//#include <kernel/core/fp/fp-local.h>
//#include <kernel/core/pager/pager.h>
//#include <boot/boot.h>
//#include <kernel/core/mutex/mutex.h>
//#include <kernel/core/sched/sched.h>
//#include <kernel/core/pm/pm.h>

uintn fp_get_page(int type) {
	uintn toreturn;

	mutex_wait(&page_frame_list_mutex[type]);
	
	toreturn = page_frame_list[type];

	if (toreturn != 0) {
		page_frame_list[type] = page_frames[toreturn].next;

		if (page_frame_list[type] == 0) {
			page_frame_lend[type] = 0;
		}
	}

	mutex_release(&page_frame_list_mutex[type]);

	fp_set_page(toreturn, PAGE_UNKNOWN);

	return toreturn;
}

void fp_add_page(uintn phys) {
	// this function looks as if it does something else, but in fact does the right thing
	// all pages are either in use at startup or marked as bad (code 0). If a page is marked
	// bad, it's assumed that the page cannot be used, broken memory or so
	// if the page is thus marked as unchecked, it will be checked, and if necessary be marked
	// bad again. However, if it truly is memory, it will be accepted and used as memory.
	if (page_frames[phys].state == PAGE_BAD) {
		fp_set_page(phys, PAGE_UNCHECKED);
	}
}

void fp_set_page(uintn phys, int type) {
	// sets the content of a page to the type indicated, removes it from the old list and adds it to the new list.
	mutex_wait(&page_frame_list_mutex[page_frames[phys].state]);
	if (phys == page_frame_list[type]) {
		// its the first, no prev
		page_frame_list[type] = page_frames[phys].next;
	} else {
		page_frames[page_frames[phys].next].prev = page_frames[phys].prev;
	}
	if (phys == page_frame_lend[type]) {
		page_frame_lend[type] = page_frames[phys].prev;
	} else {
		page_frames[page_frames[phys].prev].next = page_frames[phys].next;
	}

	mutex_release(&page_frame_list_mutex[page_frames[phys].state]);

	// unlinked from old list
	page_frames[phys].state = type;

	// special case handling
	if (PAGE_FRAME_ISUSER(page_frames[phys])) {
		// the pages that have code 01xx must be mapped per PID
		// they have their list heads and tails stored inside their PM section
		// so ask PM for help :)
		// XXX - todo when I feel like it
	} else {
		mutex_wait(&page_frame_list_mutex[type]);
		// relink in end of new list
		if (page_frame_list[type] == 0) {
			page_frame_list[type] = phys;
			page_frame_lend[type] = phys;
		} else {
			// some page there
			// connect this page to the last one in the list
			page_frames[page_frame_lend[type]].next = phys;
			page_frames[phys].prev = page_frame_lend[type];
			// and set the end to this one
			page_frame_lend[type] = phys;
		}
		mutex_release(&page_frame_list_mutex[type]);
	}
}

void fp_unget_page(uintn phys) {

}

int fp_test_page(uintn phys) {
	return 1;
}

void fp_zero_page(uintn phys) {
	// page MUST be zeroed. System stability issue
	// XXX - must fix this static mapping, 0xF0008 isn't always going to be free!'
	pager_map_page(0xF0008, phys, AL_FL_WRITABLE | AL_FL_USERACC | AL_FL_PCD | AL_FL_PWT);

	asm ("movl $0xF0008000, %%edi\n"
	     "movl $0x400, %%ecx\n"
	     "xorl %%eax, %%eax\n"
	     "rep stosl\n" :::"ecx","edi","eax");

	pager_unmap(0xF0008);
}

