#ifndef __KERNEL_DRIVERS_FP_FP
#define __KERNEL_DRIVERS_FP_FP

//#include <kernel/defines.h>
//#include <kernel/core/fp/fp.h>
//#include <kernel/core/fp/fp-local.h>

struct page_frame *page_frames = (struct page_frame *)0xC0000000;
uint16 page_frame_list[16];
uint16 page_frame_lend[16];
mutex_t page_frame_list_mutex[16];
mutex_t page_frame_mutex;

#endif
