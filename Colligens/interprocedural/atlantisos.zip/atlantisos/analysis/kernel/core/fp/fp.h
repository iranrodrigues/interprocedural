#ifndef __KERNEL_CORE_FP_FP
#define __KERNEL_CORE_FP_FP

//#include <kernel/defines.h>

struct e820_entry {
	uint64 start;
	uint64 length;
	uint32 type;
	uint32 pad;
};

struct page_frame {
	uint64 pid:16;
	uint64 virt:20;
	uint64 state:4;
	uint64 next:24;
	uint64 prev:24;
	uint64 pad:40;
};

void fp_init_1(void);
void fp_init_2(void);

uintn fp_get_zeroed_page(void);
uintn fp_get_free_page(void);
uintn fp_get_fresh_page(void);
void fp_free_page(uintn phys);
void fp_zero_page(uintn phys);

int fp_test_page(uintn phys);
void fp_unget_page(uintn phys);

void fp_set_page(uintn phys, int type);
uintn fp_get_page(int type);
void fp_add_page(uintn phys);

void fp_panic_nomem(void);

#endif
