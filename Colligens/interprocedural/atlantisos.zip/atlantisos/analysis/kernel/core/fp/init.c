//#include <kernel/core/fp/fp.h>
//#include <kernel/core/fp/fp-local.h>
//#include <boot/boot.h>
//#include <kernel/core/mutex/mutex.h>
//#include <kernel/core/sched/sched.h>
//#include <kernel/core/pm/pm.h>

void fp_init_1(void) {
	// two megs of memory free
	// memory from 0x2000 - 0x20000, TOP1-0xA0000, TOP2-0x200000 is free
	// top1/top2 are in the Initial OS Section (0x0-0x1000)
	// 0x20000-TOP1 = kernel image + additional modules
	// 0x100000-TOP2 = running kernel
	// init the free and zero tables, mutexes
	// clearing out the tables
	// at this point, the entire table is uninitialised.
	// assume 0-1M is safe to use, 1-2M is untested but does exist
	uint32 i;

	// the next is an INTENTIONAL null pointer, that will not give
	// an exception. The structure is just defined to be there.
	struct kernel_boot_header *core = (struct kernel_boot_header *)0;

	for (i=1; i<core->TOP4; i++) {
		page_frames[i].state = PAGE_TABLE;
		page_frames[i].next = i+1;
	}

	for (i=core->TOP4; i<0x1E; i++) {
		page_frames[i].state = PAGE_FREE;
		page_frames[i].next = i+1;
	}

	for (i=0x20; i<core->TOP1; i++) {
		page_frames[i].state = PAGE_KERNELSPACE_TEMP_MAPPED;
		page_frames[i].next = i+1;
	}

	for (i=core->TOP1; i<0xA0; i++) {
		page_frames[i].state = PAGE_FREE;
		page_frames[i].next = i+1;
	}

	for (i=0x100; i<core->TOP2; i++) {
		page_frames[i].state = PAGE_KERNELSPACE_TEMP_MAPPED;
		page_frames[i].next = i+1;
	}

	for (i=core->TOP2; i<core->TOP3; i++) {
		page_frames[i].state = PAGE_KERNELSPACE_MAPPED;
		page_frames[i].next = i+1;
	}

	for (i=core->TOP3; i<0x200; i++) {
		page_frames[i].state = PAGE_UNCHECKED;
		page_frames[i].next = i+1;
	}

	for (i=0; i<16; i++) {
		page_frame_list[i] = 0;
		page_frame_lend[i] = 0;
	}

	// 0-2 in use by table & page tables
	page_frames[0].next = 0x20;
	page_frames[0].state = PAGE_KERNELSPACE_TEMP_MAPPED;
	page_frames[1].next = 0;
	page_frames[1].state = PAGE_TABLE;
	page_frames[1].pid = 0;
	#ifdef PAE
	page_frames[1].virt = 0xFFF00;
	#else
	page_frames[1].virt = 0xFFE00;
	#endif

	// maps from C0000000-C0001000, so page frame is at
	// at virtual 1111 1111 1111 0000 0000 in non-pae and 
	// at virtual 1111 1111 1110 0000 0000 in pae
	page_frame_list[PAGE_KERNELSPACE_TEMP_MAPPED] = 0x0;
	page_frames[0].next = 0x20;
	// page one is not in any list administered here, process control 
	// needs to be started for that
	page_frame_list[PAGE_FREE] = core->TOP4;
	page_frames[0x1D].next = core->TOP1;
	page_frames[0x1E].state = PAGE_KERNELSPACE_MAPPED;
	page_frames[0x1E].next = 0x1F;
	page_frames[0x1F].state = PAGE_KERNELSPACE_MAPPED;
	page_frames[0x1F].next = core->TOP2;
	
	page_frame_list[PAGE_KERNELSPACE_TEMP_MAPPED] = 0x20;
	page_frames[core->TOP1-1].next = 0x100;
	// PAGE_FREE continues here, at TOP1
	page_frame_lend[PAGE_FREE] = 0x9F;
        page_frames[0x9F].next = 0;
	// space from A0 - FF empty, hardware section
	// PAGE_KERNELSPACE_TEMP_MAPPED continues here, at 0x100
	page_frame_lend[PAGE_KERNELSPACE_TEMP_MAPPED] = core->TOP2-1;
        page_frames[core->TOP2-1].next = 0;
	page_frame_list[PAGE_KERNELSPACE_MAPPED] = 0x1E;
	page_frame_lend[PAGE_KERNELSPACE_MAPPED] = core->TOP3-1;
        page_frames[core->TOP3-1].next = 0;
	page_frame_list[PAGE_UNCHECKED] = core->TOP3;
	page_frame_lend[PAGE_UNCHECKED] = 0x1FF;
	page_frames[0x1FF].next = 0;
	mutex_start(&page_frame_mutex);
	for (i=0; i<16; i++) {
		mutex_start(&page_frame_list_mutex[i]);
	}
}

void fp_init_2() {
	struct kernel_boot_header *boot = (struct kernel_boot_header *)0;
	long long start, end;
	uint32 i, j;
	// add the missing frame 0 to the kernel-space process handle
	uintn cpagetable = pm_get_pagetable_entry(0);

	page_frames[cpagetable].next = 1;
	page_frames[1].next = 0;

	// init the page table stuff
	for (i=0; i<16; i++) {
		if (boot->e820_map[i].type == 1) {
			start = (boot->e820_map[i].offset + 0xFFF) >> 12;
			end = (boot->e820_map[i].offset + boot->e820_map[i].size) >> 12;
			for (j=start; j<end; j++) {
				fp_add_page(j);
			}
		}
	}

	pm_set_pagetable_entry(0, 1);
}
