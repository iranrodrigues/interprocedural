//#include <kernel/core/fp/fp.h>
//#include <kernel/core/fp/fp-local.h>
//#include <boot/boot.h>
//#include <kernel/core/mutex/mutex.h>
//#include <kernel/core/sched/sched.h>
//#include <kernel/core/pm/pm.h>

uintn fp_get_zeroed_page() {
	uintn toreturn;
	
	mutex_wait(&page_frame_mutex);

	toreturn = fp_get_page(PAGE_ZEROED);
	if (toreturn != 0) return toreturn;
	toreturn = fp_get_page(PAGE_FREE);
	if (toreturn == 0) {
		toreturn = fp_get_fresh_page();
		if (toreturn == 0) {
			mutex_release(&page_frame_mutex);
			fp_panic_nomem();
			return fp_get_zeroed_page();
		}
	}
	mutex_release(&page_frame_mutex);

	fp_zero_page(toreturn);

	return toreturn;
}

uintn fp_get_fresh_page() {
	uintn toreturn;

	toreturn = fp_get_page(PAGE_UNCHECKED);
	while (toreturn != 0 && !fp_test_page(toreturn))
		toreturn = fp_get_page(PAGE_UNCHECKED);

	return toreturn; // if its zero, tough luck. Out of unchecked pages.
}

uintn fp_get_free_page() {
	uintn toreturn;

	mutex_wait(&page_frame_mutex);

	toreturn = fp_get_page(PAGE_FREE);
	if (toreturn == 0) toreturn = fp_get_fresh_page();
	if (toreturn == 0) toreturn = fp_get_page(PAGE_ZEROED);

	mutex_release(&page_frame_mutex);

	if (toreturn != 0) {
		return toreturn;
	}


	fp_panic_nomem();
	return fp_get_free_page();	//if the panic returns, you might hope something is available
}

void fp_free_page(uintn phys) {
	fp_unget_page(phys);
}

void fp_panic_nomem() {

}
