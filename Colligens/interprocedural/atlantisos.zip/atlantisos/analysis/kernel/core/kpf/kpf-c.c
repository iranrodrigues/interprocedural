//#include <kernel/core/kpf/kpf.h>
//#include <kernel/core/text/kprintf.h>
//#include <kernel/core/pager/pager.h>
//#include <kernel/core/fp/fp.h>

void kpf_init(void) {
	pager_add_pf_handler(kpf_code_fault, 0xF0000000, 0xF3FFFFFF, 0xF0000000, 0xF3FFFFFF);
	pager_add_pf_handler(kpf_data_fault, 0xF4000000, 0xFDFFFFFF, 0xF0000000, 0xF3FFFFFF);
	pager_add_pf_handler(kpf_static_data_fault, 0xFE000000, (uintn)PML1BASE-1, 0xF0000000, 0xF3FFFFFF);
	pager_add_pf_handler(kpf_page_frame_fault, 0xC0000000, 0xCFFFFFFF, 0xF0000000, 0xF3FFFFFF);
}

void kpf_data_fault(uintn error, uintn eip, uintn virt) {
	// XXX - add an error message here
	kprintf(0, "Kernel page fault in data area! Access from %d to %d failed!", eip, virt);
}

void kpf_static_data_fault(uintn error, uintn eip, uintn virt) {
	// allocate page to the fault place
	pager_map_page(virt >> 12, fp_get_zeroed_page(), AL_FL_WRITABLE | AL_FL_GLOBAL | AL_FL_NOEXEC);
	invlpg(virt);
}

void kpf_code_fault(uintn error, uintn eip, uintn virt) {
	kprintf(0, "Kernel page fault in code area! Access from %d to %d failed!", eip, virt);
}

void kpf_page_frame_fault(uintn error, uintn eip, uintn virt) {
	// pages should be mapped here upon request, never mapped out
	// so, type PAGE_KERNELSPACE_MAPPED_LOCKED or so
	pager_map_page(virt >> 12, fp_get_zeroed_page(), AL_FL_WRITABLE | AL_FL_GLOBAL | AL_FL_NOEXEC);
	invlpg(virt);
}
