#ifndef __KERNEL_CORE_KPF_KPF
#define __KERNEL_CORE_KPF_KPF

//#include <kernel/defines.h>

void kpf_init(void);

void kpf_data_fault(uintn error, uintn eip, uintn virt);
void kpf_static_data_fault(uintn error, uintn eip, uintn virt);
void kpf_code_fault(uintn error, uintn eip, uintn virt);
void kpf_page_frame_fault(uintn error, uintn eip, uintn virt);

#endif

