//#include <kernel/core/hwint/hwint.h>
//#include <kernel/core/mutex/mutex.h>
//#include <kernel/core/sched/sched.h>
//#include <kernel/core/pm/pm.h>
//#include <kernel/core/ih/ih.h>
//#include <kernel/core/timer/timer.h>
//#include <kernel/defines.h>

struct {
	tid_t tid;
	uint8 mutex;
	uint8 next;
} hwint_handler[64];

uint8 hwint_handler_mutex;

void hwint_init() {
	int i;
	for (i=0; i<0x10; i++) {
		hwint_handler[i].tid = 0;
		hwint_handler[i].mutex = 0;
		hwint_handler[i].next = 0;
	}
	// this looks shitty but is simply the only way
	ih_setinterrupt_safe(32, &hwint_asm_0);
	ih_setinterrupt_safe(33, &hwint_asm_1);
        ih_setinterrupt_safe(34, &hwint_asm_2);
        ih_setinterrupt_safe(35, &hwint_asm_3);
        ih_setinterrupt_safe(36, &hwint_asm_4);
        ih_setinterrupt_safe(37, &hwint_asm_5);
        ih_setinterrupt_safe(38, &hwint_asm_6);
        ih_setinterrupt_safe(39, &hwint_asm_7);
        ih_setinterrupt_safe(40, &hwint_asm_8);
        ih_setinterrupt_safe(41, &hwint_asm_9);
        ih_setinterrupt_safe(42, &hwint_asm_10);
        ih_setinterrupt_safe(43, &hwint_asm_11);
        ih_setinterrupt_safe(44, &hwint_asm_12);
        ih_setinterrupt_safe(45, &hwint_asm_13);
        ih_setinterrupt_safe(46, &hwint_asm_14);
        ih_setinterrupt_safe(47, &hwint_asm_15);
	mutex_start(&hwint_handler_mutex);
}

void hwint_c_handler(int cnum) {
	// interrupts are disabled at this point, the only thing that could 
	// happen is another processor (SMP) having the hwint lock. Since
	// this file contains all the code for the hwint_handler array
	// all code in this file will be so far optimized that should 
	// another processor want the table, it should not have to wait more
	// than about 1 microsecond.
	mutex_wait(&hwint_handler_mutex);
	if (hwint_handler[cnum].mutex == 1) {
		hwint_handler[cnum].mutex = 0;
		sched_signal(hwint_handler[cnum].tid);
	}
	while (hwint_handler[cnum].next != 0) {
		cnum = hwint_handler[cnum].next;
		hwint_handler[cnum].mutex = 0;
		sched_signal(hwint_handler[cnum].tid);
	}
	mutex_release(&hwint_handler_mutex);

	if (cnum == 0) timer_handle();
}

void hwint_wait_for_interrupt(int hwint) {
	hwint_register_interrupt(hwint);
	sched_block();
}

void hwint_register_interrupt(int hwint) {
	// take the table, add this handler, release the table
	uint16 hwint_f = 16, hwint_c = hwint;
	mutex_wait(&hwint_handler_mutex);
	while (hwint_handler[hwint_c].next != 0) {
		hwint = hwint_handler[hwint_c].next;
	}
	while (hwint_handler[hwint_f].mutex == 1) hwint_f++;

	// hwint_f points to a free one, hwint_c points to the last in the chain
	if (hwint_c == hwint && hwint_handler[hwint].mutex == 0) {
		// if the chain is empty!
		hwint_handler[hwint].tid = pm_get_current_thread();
		hwint_handler[hwint].mutex = 1;
		hwint_handler[hwint].next = 0;
	} else {
		hwint_handler[hwint].next = hwint_f;
 		hwint_handler[hwint_f].tid = pm_get_current_thread();
		hwint_handler[hwint_f].mutex = 1;
		hwint_handler[hwint_f].next = 0;
	}

	mutex_release(&hwint_handler_mutex);
}

void hwint_fini() {
	int i;
	mutex_stop(&hwint_handler_mutex);
	for (i=32; i<48; i++) {
		ih_setinterrupt(i, NULL);
	}
}
