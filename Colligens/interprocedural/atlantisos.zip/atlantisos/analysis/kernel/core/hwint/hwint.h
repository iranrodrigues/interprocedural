#ifndef __KERNEL_CORE_HWINT_HWINT
#define __KERNEL_CORE_HWINT_HWINT

//#include <kernel/defines.h>

void hwint_init(void);
void hwint_asm_0(void);
void hwint_asm_1(void);
void hwint_asm_2(void);
void hwint_asm_3(void);
void hwint_asm_4(void);
void hwint_asm_5(void);
void hwint_asm_6(void);
void hwint_asm_7(void);
void hwint_asm_8(void);
void hwint_asm_9(void);
void hwint_asm_10(void);
void hwint_asm_11(void);
void hwint_asm_12(void);
void hwint_asm_13(void);
void hwint_asm_14(void);
void hwint_asm_15(void);
void hwint_c_handler(int cnum);
void hwint_wait_for_interrupt(int hwint);
void hwint_register_interrupt(int hwint);
void hwint_fini(void);

#endif
