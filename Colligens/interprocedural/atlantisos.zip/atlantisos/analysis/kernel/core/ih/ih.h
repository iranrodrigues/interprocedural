/*
 * Interrupt handling code in modular driver format
 * (C) 2003 Candy
 *
 * Using the functions in this module:
 *
 * ih_setinterrupt(uint8 interrupt, function handler, uint8 type);
 *   Use ih_setinterrupt for setting an interrupt vector to your code
 *
 * uint8 interrupt
 *   The number of the interrupt you wish to allocate
 *      0-1F ( 0-31) are exceptions according to intel docs
 *     20-2F (32-47) are hardware interrupts in order
 *     30-FF (48-255) are software interrupts
 * function handler
 *   The function that should be called when / if the interrupt occurs
 *
 * See LICENSE in the top-level directory for licensing information
 */

#ifndef __KERNEL_CORE_IH
#define __KERNEL_CORE_IH

//#include <kernel/defines.h> 

#define IDT_BASE 0xFF100000

typedef void (*ih_handler)(void);

// init function
void ih_init(void);

// finish function 
void ih_fini(void);

// runtime functions
void ih_setinterrupt(uint8 interrupt, ih_handler handler);
void ih_setinterrupt_safe(uint8 interrupt, ih_handler handler);

#endif
