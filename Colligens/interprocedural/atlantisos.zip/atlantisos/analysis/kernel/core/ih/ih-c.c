//#include <kernel/core/ih/ih.h>
//#include <kernel/core/text/kprintf.h>
//#include <kernel/defines.h>

void ih_unhandled(void);
void ih_setinterrupt_safe(uint8 interrupt, ih_handler handler);

void ih_init(void) {
	int i = 0;
	for (i=0; i<0x100; i++) {
		ih_setinterrupt_safe(i, &ih_unhandled);
	}
}

void ih_fini(void) {
	__asm__ ("cli");
}

void ih_unhandled(void) {
	// print message about the interrupt not being handled
	kprintf(15, "Unhandled interrupt!");

	__asm__ ("leave\n\tiret");
}

void ih_setinterrupt(uint8 interrupt, ih_handler handler) {
	ih_setinterrupt_safe(interrupt, handler);
	__asm__ ("sti");
}

void ih_setinterrupt_safe(uint8 interrupt, ih_handler handler) {
	char *interrupt_entry = (char *)(interrupt << 3) + IDT_BASE;
	int location;

	__asm__ ("cli");

	if (handler == NULL) {
		location = (int) &ih_unhandled;
	} else {
		location = (int) handler;
	}

	// install interrupt handler
	interrupt_entry[6] = (location >> 16) & 0xFF;
	interrupt_entry[7] = (location >> 24) & 0xFF;
	interrupt_entry[0] = (location >> 0) & 0xFF;
	interrupt_entry[1] = (location >> 8) & 0xFF;
	interrupt_entry[5] = 0x8E;
	interrupt_entry[4] = 0;
	interrupt_entry[2] = 8;
	interrupt_entry[3] = 0;
}

