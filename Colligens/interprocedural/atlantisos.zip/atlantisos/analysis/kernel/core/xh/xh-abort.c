//#include <kernel/core/xh/xh-abort.h>

void xh_cpu_crash(void) {
	
}

void xh_do_nmi(void) {
	
}

