#ifndef __KERNEL_CORE_XH_XH_ABORT
#define __KERNEL_CORE_XH_XH_ABORT

void xh_cpu_crash(void);
void xh_do_nmi(void);

#endif

