//#include <kernel/core/xh/xh.h>
//#include <kernel/core/xh/xh-kill.h>
//#include <kernel/core/text/kprintf.h>
//#include <kernel/core/pm/pm.h>
//#include <kernel/defines.h>


/*
 * The current thread has executed an invalid opcode, and will be deleted.
 */
void xh_do_invalid_opcode(uintn error, uintn eip) {
	kprintf(2, "%s has executed an invalid instruction and is being terminated. If you want to report this error to the author of the application, you can use the following information:\n\nEIP=%d", pm_get_name(pm_get_pid(pm_get_current_thread())), eip);
	pm_kill_process(pm_get_pid(pm_get_current_thread()));
}

/*
 * The current thread has executed some fp instruction when the state is
 * still unsaved. Save state & return
 */
void xh_do_device_not_available(uintn error, uintn eip) {
	
}

/*
 * This is the general "something went wrong"-error. Since we are not so 
 * much interested what is wrong, but we are more interested in THAT it 
 * was wrong, we don't research how it happened yet.
 */
void xh_do_general_protection(uintn error, uintn eip) {
	kprintf(2, "%s has caused a general protection fault with error code %d, and is being terminated. If you want to report this error to the author of the application, you can use the following information:\n\nEIP=%d", pm_get_name(pm_get_pid(pm_get_current_thread())), error, eip);
	pm_kill_process(pm_get_pid(pm_get_current_thread()));
}

void xh_do_divide_error(uintn error, uintn eip) {
	
}

void xh_do_stack_error(uintn error, uintn eip) {
	
}

void xh_do_fpe_outstanding(uintn error, uintn eip) {
	
}

void xh_do_alignment_check(uintn error, uintn eip) {
	
}

