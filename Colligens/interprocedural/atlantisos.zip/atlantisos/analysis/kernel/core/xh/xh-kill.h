#ifndef __KERNEL_CORE_XH_XH_KILL
#define __KERNEL_CORE_XH_XH_KILL

struct xh_memory_region {
#if WORD_LENGTH==32
	uintn start:20;
#else
	uintn pad:16;
	uintn start:36;
#endif
	uintn type:12;
};

void xh_do_divide_error(uintn, uintn);
void xh_do_invalid_opcode(uintn, uintn);
void xh_do_device_not_available(uintn, uintn);
void xh_do_stack_error(uintn, uintn);
void xh_do_general_protection(uintn, uintn);
void xh_do_fpe_outstanding(uintn, uintn);
void xh_do_alignment_check(uintn, uintn);

#endif

