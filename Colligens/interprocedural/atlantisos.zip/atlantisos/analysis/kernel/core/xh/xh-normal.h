#ifndef __KERNEL_CORE_XH_XH_NORMAL
#define __KERNEL_CORE_XH_XH_NORMAL

void xh_do_debug(int, int);
void xh_do_breakpoint(int, int);
void xh_do_overflow(int, int);
void xh_do_bound_range(int, int);
void xh_do_simd_fault(int, int);

#endif

