//#include <kernel/core/xh/xh-normal.h>

void xh_do_debug(int error, int eip) {
	
}

void xh_do_breakpoint(int error, int eip) {
	
}

void xh_do_overflow(int error, int eip) {
	
}

void xh_do_bound_range(int error, int eip) {
	
}

void xh_do_simd_fault(int error, int eip) {
	
}

