#ifndef __KERNEL_CORE_XH_XH
#define __KERNEL_CORE_XH_XH

//#include <kernel/defines.h>

typedef void (*xh_handler)(uintn, uintn);
extern xh_handler *xh_exception_handler;

void xh_init(void);
void xh_fini(void);
void xh_empty(uintn, uintn);
void xh_register(int exception, xh_handler handler);

void xh_asm_normal(void);
void xh_asm_nmi(void);
void xh_asm_ex0(void);
void xh_asm_ex1(void);
void xh_asm_ex3(void);
void xh_asm_ex4(void);
void xh_asm_ex5(void);
void xh_asm_ex6(void);
void xh_asm_ex7(void);
void xh_asm_ex8(void);
void xh_asm_ex10(void);
void xh_asm_ex11(void);
void xh_asm_ex12(void);
void xh_asm_ex13(void);
void xh_asm_ex14(void);
void xh_asm_ex16(void);
void xh_asm_ex17(void);
void xh_asm_ex18(void);
void xh_asm_ex19(void);

#endif
