// uses PM module
//#include <kernel/core/pm/procdata.h>
//#include <kernel/core/pm/gsbase.h>

// uses IH module
//#include <kernel/core/ih/ih.h>

// uses pager module
//#include <kernel/core/pager/pager.h>

//#include <kernel/core/xh/xh.h>
//#include <kernel/core/xh/xh-kill.h>
//#include <kernel/core/xh/xh-abort.h>
//#include <kernel/core/xh/xh-normal.h>
//#include <kernel/defines.h>

xh_handler *xh_exception_handler;

void xh_init(void) {
	xh_exception_handler = gs_base()->xh_table;

//	for (int i=0; i<32; i++) {
//		xh_exception_handler[i] = (xh_handler)&xh_empty;
//	}

	ih_setinterrupt_safe(0, (ih_handler)&xh_asm_ex0);
	ih_setinterrupt_safe(1, (ih_handler)&xh_asm_ex1);
	ih_setinterrupt_safe(2, (ih_handler)&xh_asm_nmi);
	ih_setinterrupt_safe(3, (ih_handler)&xh_asm_ex3);
	ih_setinterrupt_safe(4, (ih_handler)&xh_asm_ex4);
	ih_setinterrupt_safe(5, (ih_handler)&xh_asm_ex5);
	ih_setinterrupt_safe(6, (ih_handler)&xh_asm_ex6);
	ih_setinterrupt_safe(7, (ih_handler)&xh_asm_ex7);
	ih_setinterrupt_safe(8, (ih_handler)&xh_asm_ex8);
	ih_setinterrupt_safe(10, (ih_handler)&xh_asm_ex10);
	ih_setinterrupt_safe(11, (ih_handler)&xh_asm_ex11);
	ih_setinterrupt_safe(12, (ih_handler)&xh_asm_ex12);
	ih_setinterrupt_safe(13, (ih_handler)&xh_asm_ex13);
	ih_setinterrupt_safe(14, (ih_handler)&xh_asm_ex14);
	ih_setinterrupt_safe(16, (ih_handler)&xh_asm_ex16);
	ih_setinterrupt_safe(17, (ih_handler)&xh_asm_ex17);
	ih_setinterrupt_safe(18, (ih_handler)&xh_asm_ex18);
	ih_setinterrupt_safe(19, (ih_handler)&xh_asm_ex19);
	

	// register the exception handlers in the supplemental xh
	// code packages (xh_kill, xh_abort and xh_normal)

	// xh_kill package
	xh_register(0, (xh_handler)&xh_do_divide_error);
	xh_register(6, (xh_handler)&xh_do_invalid_opcode);
	xh_register(7, (xh_handler)&xh_do_device_not_available);
	xh_register(12, (xh_handler)&xh_do_stack_error);
	xh_register(13, (xh_handler)&xh_do_general_protection);
	xh_register(14, (xh_handler)&pager_handle_pf);
	xh_register(16, (xh_handler)&xh_do_fpe_outstanding);
	xh_register(17, (xh_handler)&xh_do_alignment_check);

	// xh_abort has xh_cpu_crash function, which is frankly the only
	// function that can be called from true aborts

	// xh_normal package
	xh_register(1, (xh_handler)&xh_do_debug);
	xh_register(3, (xh_handler)&xh_do_breakpoint);
	xh_register(4, (xh_handler)&xh_do_overflow);
	xh_register(5, (xh_handler)&xh_do_bound_range);
	xh_register(19, (xh_handler)&xh_do_simd_fault);
}

void xh_empty(uintn error, uintn eip) {}

void xh_fini(void) {}

void xh_register(int exception, xh_handler handler) {
	if (handler != NULL) {
		xh_exception_handler[exception] = handler;
	} else {
		xh_exception_handler[exception] = (xh_handler)&xh_empty;
	}
}

