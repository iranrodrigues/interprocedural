//#include <kernel/core/hwint/hwint.h>
//#include <kernel/core/pm/thread.h>
//#include <kernel/core/sched/sched.h>
//#include <kernel/core/kmm/kmm.h>
//#include <kernel/core/pm/gsbase.h>
//#include <kernel/core/timer/timer.h>

struct timer_ent *timers;

void timer_handle(void) {
	struct timer_ent *temp;
	if ((timers != NULL) && (--(timers->delay) == 0)) {
		while (timers->delay == 0) {
			// timer went off
			temp = timers;
			timers = timers->next;
			sched_signal(temp->thread);
			kmm_free((char *)temp);
		}
	}

	struct procdata *procdata = gs_base();
	if (--(procdata->quantum) == 0) asm ("int $0x30");
}

void timer_init(void) {
	timers = NULL;
}

