#ifndef TIMER_H
#define TIMER_H

//#include <kernel/defines.h>

struct timer_ent {
	uint16 delay;
	tid_t thread;
	struct timer_ent *next;
};

void timer_handle(void);
void timer_init(void);

#endif
