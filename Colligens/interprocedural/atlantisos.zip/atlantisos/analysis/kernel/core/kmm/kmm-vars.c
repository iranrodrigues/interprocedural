//#include <kernel/core/kmm/kmm.h>

mutex_t kmm_mutex;

struct memblock *usedlist;
struct memblock *freelist;
int curindex;
int freecount;
int freesize;
int usedcount;
int usedsize;

