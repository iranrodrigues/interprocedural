#ifndef __KERNEL_CORE_KMM_KMM
#define __KERNEL_CORE_KMM_KMM

//#include <kernel/defines.h>

void kmm_init(void);
char *kmm_malloc(uintn amount);
void kmm_free(char *what);

extern uintn kernel_max_mem;

extern mutex_t kmm_mutex;

struct memblock {
        uintn size;
        char *offset;
};

extern struct memblock *usedlist;
extern struct memblock *freelist;
extern int curindex;
extern int freecount;
extern int freesize;
extern int usedcount;
extern int usedsize;

void kmm_rfree(char *what);
char *kmm_rmalloc(uintn amount);
void kmm_checkbounds(void);
void kmm_memres(uintn sizeinc);

#endif
