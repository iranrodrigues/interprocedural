#ifndef INTERNAL_H
#define INTERNAL_H

void clear_mem(char *what, int count);
void move_mem(char *dst, char *src, int count);

#endif
