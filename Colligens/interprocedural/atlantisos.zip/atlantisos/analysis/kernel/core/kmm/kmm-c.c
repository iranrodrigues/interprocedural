//#include <kernel/core/kmm/kmm.h>
//#include <kernel/core/mutex/mutex.h>
//#include <kernel/core/pager/pager.h>
//#include <kernel/core/fp/fp.h>
//#include <kernel/core/kmm/internal.h>
//#include <kernel/defines.h>

extern uintn kernel_max_mem;
/* kmeminit - function that initialises the kernel memory manager so that 
 * kmalloc/kfree/ksfree can be used.
 */
void kmm_init() {
	uintn cbase;
	int i;
	kernel_max_mem = (uintn)&kernel_max_mem + 16;

	// map in a 32k block extra
	cbase = (kernel_max_mem + 4095) >> 12;

	for (i=0; i<8; i++) {
		pager_map_page(cbase + i, fp_get_free_page(), AL_FL_WRITABLE | AL_FL_GLOBAL | AL_FL_NOEXEC);
	}

	freelist = (struct memblock *)kernel_max_mem;
 	usedlist = (struct memblock *)(kernel_max_mem + sizeof(struct memblock) * 128);
	freesize = usedsize = 128;

	freecount = 1;	// the "leftover" block
	usedcount = 2;	// the freelist, the used list and the kernel itself

	kernel_max_mem += 32768;

	freelist[0].offset = (char *)freelist + sizeof(struct memblock) * 256;
	freelist[0].size = (uintn)kernel_max_mem - (uintn)freelist[0].offset;
	usedlist[0].size = freesize * sizeof(struct memblock);
	usedlist[0].offset = (char *)freelist;
	usedlist[1].size = usedsize * sizeof(struct memblock);
	usedlist[1].offset = (char *)usedlist;	// cyclic

	curindex = 0;

	mutex_start(&kmm_mutex);
}

char *kmm_malloc(uintn amount) {
	char *toreturn;

	mutex_wait(&kmm_mutex);
	toreturn = kmm_rmalloc(amount);
	mutex_release(&kmm_mutex);

	return toreturn;
}

char *kmm_rmalloc(uintn amount) {
	// find the first that fits, starting at curindex
	int tcount = curindex;
	int cseg = -1;
	char *pbackup;
	amount = (amount + 15) & ~15;		// ensures all allocates are 16-bit aligned

	for (tcount = curindex; tcount < freecount; tcount++) {
		if (freelist[tcount].size >= amount) {
			// found a fitting block, save & escape
			cseg = tcount;
			break;
		}
	}
	if (cseg < 0)
	for (tcount = 0; tcount < curindex; tcount++) {
		if (freelist[tcount].size >= amount) {
			//ditto
			cseg = tcount;
			break;
		}
	}
	if (cseg < 0) {
		kmm_memres(amount);
		return kmm_rmalloc(amount);	// second chance - works as soon as kmemres works.
	}
	// found a segment fitting the description
	// resize and possibly remove the old segment
	curindex = tcount;
	freelist[curindex].size -= amount;
	pbackup = freelist[curindex].offset;
	freelist[curindex].offset += amount;
	if (freelist[curindex].size == 0) {
		// empty block, not useful.
		freelist[curindex].size = freelist[freecount-1].size;
		freelist[curindex].offset = freelist[freecount-1].offset;
		freecount--;
	}

	// add the new segment to the usedlist
	usedlist[usedcount].size = amount;
	usedlist[usedcount].offset = pbackup;
	usedcount++;

	kmm_checkbounds();

	return pbackup;
}

void kmm_free(char *what) {
	if (what == (char *)freelist || 
	    what == (char *)usedlist)
		return;

	mutex_wait(&kmm_mutex);
	kmm_rfree(what);
	mutex_release(&kmm_mutex);
}

void kmm_rfree(char *what) {
	// search the usedlist for this block
	int tcount;
	int cnum = -1;
	int newsize; char *newoffset;

	for (tcount = 0; tcount < usedcount; tcount++) {
		if (usedlist[tcount].offset == what) {
			cnum = tcount;
			break;
		}
	}
	if (cnum == -1) return; // nonexistant or already freed block
	// create new block & merge other blocks
	newsize = usedlist[cnum].size;
	newoffset = usedlist[cnum].offset;
	usedlist[cnum].size = usedlist[usedcount-1].size;
	usedlist[cnum].offset = usedlist[usedcount-1].offset;
	usedcount--;

	// seek adjacent blocks in freelist
	for (tcount = 0; tcount < freecount; tcount++) {
		if (freelist[tcount].offset + freelist[tcount].size == newoffset) {
			newsize += freelist[tcount].size;
			newoffset -= freelist[tcount].size;
			freelist[tcount].offset = freelist[freecount-1].offset;
			freelist[tcount].size = freelist[freecount-1].size;
			freecount--;
		}
		if (freelist[tcount].offset == newoffset + newsize) {
			newsize += freelist[tcount].size;
			freelist[tcount].offset = freelist[freecount-1].offset;
			freelist[tcount].size = freelist[freecount-1].size;
			freecount--;
		}
	}

	freelist[freecount].size = newsize;
	freelist[freecount].offset = newoffset;
	freecount++;

	kmm_checkbounds();
}

void kmm_checkbounds() {
	// indien er minder dan 5 lege plekken zijn de lijst vergroten
	// indien er meer dan 1/2 * lengte + 16 lege plekken zijn de lijst verkleinen
	// indien de lijst korter dan 128 entries zou worden, niets doen.
	int numfreefree, numfreeused;
	char *temp;

	numfreefree = freesize - freecount;
	numfreeused = usedsize - usedcount;
	// if any of the updating conditions is true, and there is nobody already updating, update it
	if (numfreefree < 5 ||
	    (numfreefree >= ((freesize / 2) + 16) &&
	     freesize > 128) ||
	    numfreeused < 5 ||
	    (numfreeused >= ((freesize / 2) + 16) &&
	     usedsize > 128)) {
		if (numfreefree < 5) {								// make bigger
			temp = kmm_rmalloc(freesize * 2 * sizeof(struct memblock));	// allocate new list
			move_mem(temp, (char *)freelist, freesize);			// copy contents
			kmm_rfree((char *)freelist);					// free old list
			freelist = (struct memblock *)temp;				// set pointer to new list
			freesize *= 2;							// and update description
		} else if (numfreefree >= ((freesize / 2) + 16) && freesize > 128) {		// make smaller
			temp = kmm_rmalloc(freesize * sizeof(struct memblock) / 2);	// allocate new list
			move_mem(temp, (char *)freelist, freesize / 2);			// copy contents
			kmm_rfree((char *)freelist);					// free old list
			freelist = (struct memblock *)temp;				// set pointer to new list
			freesize /= 2;							// and update description
		}
		if (numfreeused < 5) {								// make bigger
			temp = kmm_rmalloc(usedsize * 2 * sizeof(struct memblock));	// allocate new list
			move_mem(temp, (char *)usedlist, usedsize);			// copy contents
			kmm_rfree((char *)usedlist);					// free current list
			usedlist = (struct memblock *)temp;				// set pointer to new list
			usedsize *= 2;							// and update description
		} else if (numfreeused >= ((usedsize / 2) + 16) && usedsize > 128) {		// make smaller
			temp = kmm_rmalloc(usedsize * sizeof(struct memblock) / 2);	// allocate new list
			move_mem(temp, (char *)usedlist, usedsize / 2);			// copy contents
			kmm_rfree((char *)usedlist);					// free current list
			usedlist = (struct memblock *)temp;				// set pointer to new list
			usedsize /= 2;							// and update description
		}
	}
}

/* kernel memory resize function
 * can only be created after paging is enabled, and functions similar to brk()
 * sizeinc must be a whole amount of 4k-blocks.
 */
void kmm_memres(uintn sizeinc) {
	// global algorithm: allocate a couple of new pages of kernel memory, add a used 
	// block for that size manually into the used list, free it (thus adding it merged 
	// to the free list) and then return.

	uint32 i;
	uintn cmaxmem, togotomaxmem;
	cmaxmem = ((((uintn)(kernel_max_mem) - 1) & 0xFFFFF000) >> 12) + 1;
	togotomaxmem = ((((uintn)(kernel_max_mem) + sizeinc - 1) & 0xFFFFF000) >> 12) + 1;

	for (i=cmaxmem; i<togotomaxmem; i++) {
		pager_map_page(i, fp_get_free_page(), AL_FL_WRITABLE | AL_FL_GLOBAL | AL_FL_NOEXEC);
	}

	// pages mapped, add a block for it to the used list, call kfree for that 
	// block, and then increase the kernel_max_mem variable
	usedlist[usedcount].size = sizeinc;
	usedlist[usedcount].offset = (char *)kernel_max_mem;
	usedcount++;

	kmm_rfree((char *)kernel_max_mem);

	kernel_max_mem += sizeinc;
}

