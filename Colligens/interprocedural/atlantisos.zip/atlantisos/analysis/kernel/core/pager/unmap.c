//#include <kernel/core/pager/pager.h>
//#include <kernel/core/fp/fp.h>

uintn pager_unmap(uintn virt) {
	// check if it is even mapped
	// first check the page directory pointer table
	int /*clean,*/ t;
//	uint64 i;
	struct pte *entries;
	uintn toreturn;

#ifdef PML2BASE
#ifdef PML3BASE
#ifdef PML4BASE
	entries = PML4BASE;
	t = ((unsigned int)virt >> 3*PAGE_SHIFT) & (PAGE_MASK >> (3*PAGE_SHIFT));
	if (entries[t].p == 0) {
		return -1;
	}
#endif
	entries = PML3BASE;
	t = ((unsigned int)virt >> 2*PAGE_SHIFT) & (PAGE_MASK >> (2*PAGE_SHIFT));
	if (entries[t].p == 0) {
		return -1;
	}
#endif
	entries = PML2BASE;
	t = ((unsigned int)virt >> PAGE_SHIFT) & (PAGE_MASK >> (PAGE_SHIFT));
	if (entries[t].p == 0) {
		return -1;
	}
#endif
	entries = PML1BASE;
	t = (unsigned int)virt & PAGE_MASK;
	if (entries[t].p == 0) {
		return -1;
	}

	// remove the page itself
	if (entries[t].p == 0) return -1;

	entries[t].p = 0;

	invlpg(virt << 12);
	
	toreturn = entries[t].addr;
	
/*	// free next levels of page tables until clean is false, or there are no more page tables
	// there are always pages left (this code has to be somewhere :) so no fucking with cr3
	clean = true;
	
#ifdef PML2BASE	
	entries = PML1BASE;
	for (i=((virt & PAGE_MASK) >> (PAGE_SHIFT * 0)) & (~((1 << PAGE_SHIFT) - 1));
	     i<(((virt & PAGE_MASK) >> (PAGE_SHIFT * 0)) | ((1 << PAGE_SHIFT) - 1));
	     i++) {
		if (entries[i].p == 1) {
			clean=false;
		}
	}
	
	if (!clean) return toreturn;
	
	entries = PML2BASE;
	
	fp_free_page(pager_unmap((int)(&entries[(virt & PAGE_MASK) >> (PAGE_SHIFT * 1)]) >> 12));
#ifdef PML3BASE
	for (i=((virt & PAGE_MASK) >> (PAGE_SHIFT * 1)) & (~((1 << PAGE_SHIFT) - 1));
	     i<(((virt & PAGE_MASK) >> (PAGE_SHIFT * 1)) | ((1 << PAGE_SHIFT) - 1));
	     i++) {
		if (entries[i].p == 1) {
			clean=false;
		}
	}
	
	if (!clean) return toreturn;
	
	entries = PML3BASE;

	fp_free_page(pager_unmap((int)(&entries[(virt & PAGE_MASK) >> (PAGE_SHIFT * 2)]) >> 12));
#ifdef PML4BASE
	for (i=((virt & PAGE_MASK) >> (PAGE_SHIFT * 2)) & (~((1 << PAGE_SHIFT) - 1));
	     i<(((virt & PAGE_MASK) >> (PAGE_SHIFT * 2)) | ((1 << PAGE_SHIFT) - 1));
	     i++) {
		if (entries[t].p == 1) {
			clean=false;
		}
	}
	
	if (!clean) return toreturn;
	
	entries = PML4BASE;

	fp_free_page(pager_unmap((int)(&entries[(virt & PAGE_MASK) >> (PAGE_SHIFT * 3)]) >> 12));
#endif
#endif
#endif
*/
	return toreturn;
}
