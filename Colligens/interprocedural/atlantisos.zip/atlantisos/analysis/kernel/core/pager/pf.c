//#include <kernel/core/pager/pager.h>
//#include <kernel/core/xh/xh.h>

struct pagefault_handler *pagefaults = (struct pagefault_handler *)0xFF120000;

void pager_add_pf_handler(pf_handler handler, uintn minvirt, uintn maxvirt, uintn mineip, uintn maxeip) {
	int i = 0;
	while (pagefaults[i].handler != 0) i++;
	pagefaults[i].handler = handler;
	pagefaults[i].minvirt = minvirt;
	pagefaults[i].maxvirt = maxvirt;
	pagefaults[i].mineip = mineip;
	pagefaults[i].maxeip = maxeip;
}

void pager_delete_pf_handler(pf_handler handler, uintn minvirt, uintn maxvirt, uintn mineip, uintn maxeip) {
	int i = 0;
	while (pagefaults[i].handler != handler && i < 8) i++;
	if (i < 8) {
		pagefaults[i].handler = (pf_handler)0;
		pagefaults[i].minvirt = 0;
		pagefaults[i].maxvirt = 0;
		pagefaults[i].mineip = 0;
		pagefaults[i].maxeip = 0;
	}
}

void pager_handle_pf(uintn error, uintn eip) {
	int i;

	// search the virt to go with this
	uintn virt;

	asm ("movl %%cr2, %0":"=r"(virt));

	for (i=0; i<8; i++) {
		// if there is a handler there and it fits the range, call it
		if (pagefaults[i].minvirt < virt &&
		    pagefaults[i].maxvirt > virt &&
		    pagefaults[i].mineip < eip &&
		    pagefaults[i].maxeip > eip &&
		    pagefaults[i].handler != (pf_handler)0) {
			pagefaults[i].handler(error, eip, virt);
		}
	}
}

