#ifndef HASH_H
#define HASH_H

//#include <kernel/defines.h>

struct hash_swap_entry {
	uint8 type;
	uint8 flags;
	uint8 pad;
	struct {
		uint8 p1;
		uint32 p2;
	} offset;
	uint64 inode;
};

struct hash_table {
	uintn curentrycount;	// max == modulus1
	uintn modulus1;		// some uneven number
	uintn modulus2;		// some OTHER uneven number, preferably coprime with modulus1
	struct hash_swap_entry *table;	// the table itself
};

#endif

