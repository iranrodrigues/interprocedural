//#include <kernel/core/pager/pager.h>
//#include <kernel/core/fp/fp.h>

void pager_map_page(uintn todovirt, uintn todophys, int flags) {
	int t;
	struct pte *entries;
	int nphys;

#ifdef PML2BASE
#ifdef PML3BASE
#ifdef PML4BASE
        entries = PML4BASE;
        t = ((todovirt & PAGE_MASK) >> (PAGE_SHIFT * 3));

        if (entries[t].p == 0) {
                nphys = fp_get_zeroed_page();
                entries[t].p = 1;
                entries[t].rw = 1;
                entries[t].us = 1;
                entries[t].pwt = 1;
                entries[t].pcd = 1;
                entries[t].addr = nphys;
	}
#endif
        entries = PML3BASE;
        t = ((todovirt & PAGE_MASK) >> (PAGE_SHIFT * 2));

        if (entries[t].p == 0) {
                nphys = fp_get_zeroed_page();
                entries[t].p = 1;
                entries[t].rw = 1;
                entries[t].us = 1;
                entries[t].pwt = 1;
                entries[t].pcd = 1;
                entries[t].addr = nphys;
	}
#endif
	entries = PML2BASE;
	t = ((todovirt & PAGE_MASK) >> (PAGE_SHIFT * 1));

	if (entries[t].p == 0) {
		nphys = fp_get_zeroed_page();
		entries[t].p = 1;
		entries[t].rw = 1;
		entries[t].us = 1;
		entries[t].pwt = 1;
		entries[t].pcd = 1;
		entries[t].addr = nphys;
	}
#endif
	entries = PML1BASE;

	t = todovirt;

	if (entries[t].p == 1) return;

	entries[t].addr = todophys;
	entries[t].p = 1;
	if (flags & AL_FL_WRITABLE) entries[t].rw = 1; else entries[t].rw = 0;
	if (flags & AL_FL_USERACC) entries[t].us = 1; else entries[t].us = 0;
#if WORD_LENGTH==64
	if (flags & AL_FL_NOEXEC) entries[t].nx = 1; else entries[t].nx = 0;
	if (flags & AL_FL_GLOBAL) entries[t].g = 1; else entries[t].g = 0;
#endif
	if (flags & AL_FL_PCD) entries[t].pcd = 1; else entries[t].pcd = 0;
	if (flags & AL_FL_PWT) entries[t].pwt = 1; else entries[t].pwt = 0;
	if (flags & AL_FL_PAT) entries[t].pat = 1; else entries[t].pat = 0;
//#endif
}
