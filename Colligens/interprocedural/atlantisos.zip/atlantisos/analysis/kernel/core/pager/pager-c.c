//#include <kernel/core/pager/pager.h>

void pager_init(void) {
	int i;

	for (i=0; i<16; i++) {
		pagefaults[i].minvirt = 0;
		pagefaults[i].maxvirt = 0;
		pagefaults[i].mineip = 0;
		pagefaults[i].maxeip = 0;
		pagefaults[i].handler = (pf_handler)0;
	}
}

struct pagefault_handler *pagefaults = (struct pagefault_handler *)0xFF120000;
