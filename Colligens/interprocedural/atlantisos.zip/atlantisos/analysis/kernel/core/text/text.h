#ifndef __KERNEL_CORE_TEXT_TEXT
#define __KERNEL_CORE_TEXT_TEXT

#define KERNEL_CONSOLE 0
void text_printch(int console, char ch);

#endif
