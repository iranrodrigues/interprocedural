#ifndef __KERNEL_CORE_TEXT_KPRINTF
#define __KERNEL_CORE_TEXT_KPRINTF

void kprintf(int level, char *text, ...);

#endif
