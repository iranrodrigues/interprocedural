//#include <kernel/core/text/kprintf.h>
//#include <kernel/core/text/text.h>
//#include <kernel/defines.h>

typedef int *va_list;
#define va_args(before_first) ((va_list)(before_first)-4)
#define va_arg(type, list, num) (*(type *)(list - num))

void kprintf(int level, char *text, ...) {
	va_list therest = va_args(&text);
	int carg = 0;
//	char hextab[32] = "0123456789ABCDEF0123456789abcdef";
	int addend = 0, cch, i;
	char *cstr;

	while(*text) {
		if (*text == '%') {
			text++;
			switch((int)*text) {
			    case 'c':
//				text_printch(KERNEL_CONSOLE, va_arg(char, therest, carg++));
				break;
			    case 'x':
				addend=16;
			    case 'X':
				for (i=0; i<8; i++) {
					cch = (va_arg(uintn, therest, carg) >> ((7-i)<<2));
//					text_printch(KERNEL_CONSOLE, hextab[cch+addend]);
				}
				carg++;
				addend=0;
				break;
			    case 's':
				cstr = va_arg(char *, therest, carg++);
//				while (*cstr) text_printch(KERNEL_CONSOLE, *cstr);
				break;
			}
		} else {
//			text_printch(KERNEL_CONSOLE, *text);
		}
		text++;
	}
}
