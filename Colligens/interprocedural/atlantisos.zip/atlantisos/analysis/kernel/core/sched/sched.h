#ifndef __KERNEL_SCHED_H
#define __KERNEL_SCHED_H

//#include <kernel/defines.h>

/*
 * FREE: Entry not in use
 * RUNNING: thread running on some processor right now
 * AVAILABLE: thread runnable, but not running
 * BLOCKED: thread blocked
 * SWAPPED: thread is on disk (indicating the working set is on disk)
 * SWAPPED_BLOCKED: thread is on disk, and is also still blocked.
 * NEW: Thread has never run before, still needs setting up. Note: 
 *	this entry may never be written to from the general code, 
 *	only from the threadstarter code
 * DEAD: Thread has died, will be removed. Note: this entry may 
 *	never be written to from the general code, only from the 
 *	executioner code
 */
enum {SCHED_FREE, SCHED_RUNNING, SCHED_AVAILABLE, SCHED_BLOCKED, SCHED_SWAPPED, SCHED_SWAPPED_BLOCKED, SCHED_NEW, SCHED_DEAD};

void sched_yield(tid_t thread);
void sched_block(void);
void sched_signal(tid_t thread);
void sched_handler(void);
void sched_refill(void);
void sched_init(void);
void sched_handler_asm(void);
void sched_check_asm(void);
void sched_switch_to(uintn cr3);
void sched_loadthread(char *thread);
void sched_check(void);

extern tid_t sched_maxthr;
extern tid_t sched_p[4], sched_idle;
extern tid_t sched_end[4];

#endif
