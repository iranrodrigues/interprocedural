//#include <kernel/core/sched/sched.h>
//#include <kernel/core/mutex/mutex.h>
//#include <kernel/core/ih/ih.h>
//#include <kernel/core/pm/gsbase.h>
//#include <kernel/core/pm/procdata.h>
//#include <kernel/core/pm/thread.h>
//#include <kernel/core/pm/process.h>

void sched_yield(tid_t thread) {
	uint16 bu;
	uint8 ctype;

	// find out if thread is available (peeking only)
	if (thread != 0 && pm_tids[thread].state == SCHED_AVAILABLE &&
	    pm_tids[thread].quantum > 0) {
		mutex_wait(&pm_tids_mutex);
		// now check whether it is available
		if (pm_tids[thread].state == SCHED_AVAILABLE
		    && pm_tids[thread].quantum > 0) {
			ctype = pm_tids[thread].type;
			if (pm_tids[thread].next != 0) {
				pm_tids[pm_tids[thread].next].previous = pm_tids[thread].previous;
			}
			if (pm_tids[thread].previous != 0) {
				pm_tids[pm_tids[thread].previous].next = pm_tids[thread].next;
			}
			
			// this entity coupled loose
			bu = sched_p[ctype];
			sched_p[ctype] = thread;
			pm_tids[thread].next = bu;
			pm_tids[thread].previous = 0;
			pm_tids[bu].previous = thread;
		}
		mutex_release(&pm_tids_mutex);
	}

	// yield (just call the hardware int manually)
	asm ("int $0x30");	// int 0x30 == scheduler switch code
}

void sched_block(void) {
	struct procdata *procdata = gs_base();
	
	mutex_wait(&pm_tids_mutex);
	
	if (pm_tids[procdata->cthread].signal_waiting == 0) {
		pm_tids[procdata->cthread].state = THREAD_BLOCKED;

		mutex_release(&pm_tids_mutex);
	
		asm ("int $0x30");	// yield without the thread part
	} else {
		pm_tids[procdata->cthread].signal_waiting = 0;
		mutex_release(&pm_tids_mutex);
	}
}

void sched_signal(tid_t thread) {
	mutex_wait(&pm_tids_mutex);
	
	if (pm_tids[thread].state == THREAD_BLOCKED) {
		pm_tids[thread].state = THREAD_AVAILABLE;
		pm_tids[thread].next = sched_p[pm_tids[thread].type];
		pm_tids[sched_p[pm_tids[thread].type]].previous = thread;
		sched_p[pm_tids[thread].type] = thread;
	} else if (pm_tids[thread].state == THREAD_SWAPPEDBLOCKED)
		pm_tids[thread].state = THREAD_SWAPPED;
	else
		pm_tids[thread].signal_waiting = 1;
	
	mutex_release(&pm_tids_mutex);
}

// current thread has no quantum left, or
// cannot (or doesn't want to) continue
void sched_handler(void) {
	tid_t end, togo;
	struct procdata *procdata = gs_base();
	uintn t_cr3;

	mutex_wait(&pm_tids_mutex);
	 
	// if we weren't idling...
	if (pm_tids[procdata->cthread].killed == 0 &&
	    pm_tids[procdata->cthread].state == THREAD_RUNNING) {
		pm_tids[procdata->cthread].state = THREAD_AVAILABLE;
		pm_tids[procdata->cthread].quantum = procdata->quantum;
		
		// if there was an end, attach it. If there wasn't, make a new queue
		if ((end = sched_end[pm_tids[procdata->cthread].type])) {
			pm_tids[end].next = procdata->cthread;
			pm_tids[procdata->cthread].previous = end;
			pm_tids[procdata->cthread].next = 0;
			sched_end[pm_tids[procdata->cthread].type] = procdata->cthread;
		} else {
			sched_p[pm_tids[procdata->cthread].type] = procdata->cthread;
			sched_end[pm_tids[procdata->cthread].type] = procdata->cthread;
			pm_tids[procdata->cthread].next = 0;
			pm_tids[procdata->cthread].previous = 0;
		}
	}

	// if nothing's available refill the quanta for all
	if (pm_tids[sched_p[3]].quantum == 0 &&
	    pm_tids[sched_p[2]].quantum == 0 &&
	    pm_tids[sched_p[1]].quantum == 0 &&
	    pm_tids[sched_p[0]].quantum == 0) sched_refill();

	// pick the highest available thread
	if (sched_p[3] != 0 && 
	    pm_tids[sched_p[3]].quantum > 0) {
		// priority 3
		togo = sched_p[3];
		
		sched_p[3] = pm_tids[togo].next;
		pm_tids[sched_p[3]].previous = 0;
		pm_tids[togo].next = 0;
		pm_tids[togo].state = THREAD_RUNNING;

		procdata->quantum = pm_tids[togo].quantum;
	} else if (sched_p[2] != 0 &&
		   pm_tids[sched_p[2]].quantum > 0) {
		togo = sched_p[2];

		sched_p[2] = pm_tids[togo].next;
		pm_tids[sched_p[2]].previous = 0;
		pm_tids[togo].next = 0;
		pm_tids[togo].state = THREAD_RUNNING;

		procdata->quantum = pm_tids[togo].quantum;
	} else if (sched_p[1] != 0 &&
		   pm_tids[sched_p[1]].quantum > 0) {
		togo = sched_p[1];

		sched_p[1] = pm_tids[togo].next;
		pm_tids[sched_p[1]].previous = 0;
		pm_tids[togo].next = 0;
		pm_tids[togo].state = THREAD_RUNNING;

		procdata->quantum = pm_tids[togo].quantum;
	} else if (sched_p[0] != 0 &&
		   pm_tids[sched_p[0]].quantum > 0) {
		togo = sched_p[0];

		sched_p[0] = pm_tids[togo].next;
		pm_tids[sched_p[0]].previous = 0;
		pm_tids[togo].next = 0;
		pm_tids[togo].state = THREAD_RUNNING;

		procdata->quantum = pm_tids[togo].quantum;
	} else {
		togo = sched_idle;
	}
	
	mutex_release(&pm_tids_mutex);
	
	procdata->cthread = togo;
	procdata->cprocess = pm_tids[togo].pid;

	sched_loadthread((char *)&pm_tids[togo]);
	
	// if the context does not need a change (kernel-only thread f.i.) don't change it.
	
	asm ("movl %%cr3, %0":"=r"(t_cr3));
	
	if (pm_pids[pm_tids[togo].pid].cr3 != 0 && 
	    pm_pids[pm_tids[togo].pid].cr3 != t_cr3) {
		// context switch to the new process
		sched_switch_to(pm_pids[pm_tids[togo].pid].cr3);
	}
}

void sched_refill() {
	// assumes: mutex is already acquired
	// note: also for running threads!
	int i;
	
	for (i=0; i<sched_maxthr; i++) {
		if (pm_tids[i].state != THREAD_DEAD &&
		    pm_tids[i].state != THREAD_NEW &&
		    pm_tids[i].state != THREAD_NONE) {
			pm_tids[i].quantum >>= 1; 
			pm_tids[i].quantum += pm_tids[i].priority;
		}
	}
}

void sched_init() {
	int i;

	ih_setinterrupt_safe(0x30, (ih_handler)&sched_handler_asm);
	ih_setinterrupt_safe(0x31, (ih_handler)&sched_check_asm);
	for (i=0; i<4; i++) {
		sched_p[i] = sched_end[i] = 0;
	}
}

void sched_switch_to(uintn cr3) {
	asm ("movl %0, %%cr3"::"r"(cr3));
}

void sched_loadthread(char *thread) {
	char *gdt = (char *)0xFF100838;
	uintn thread_ = (uintn)thread;

	gdt[2] = thread_ & 0xFF;
	gdt[3] = (thread_ >> 8) & 0xFF;
	gdt[4] = (thread_ >> 16) & 0xFF;
	gdt[7] = (thread_ >> 24) & 0xFF;
}

void sched_check(void) {
	struct procdata *procdata = gs_base();

	// check if the current thread may still be executed (that is, the
	// thread and the process are still active)

	if (pm_pids[procdata->cprocess].status == PROCESS_DEAD ||
	    pm_tids[procdata->cthread].killed == 1) {
		asm("int $0x30");
	}
}

