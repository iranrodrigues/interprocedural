//#include <kernel/core/sched/sched.h>

tid_t sched_maxthr;
tid_t sched_p[4], sched_idle = 0; 
tid_t sched_end[4];

