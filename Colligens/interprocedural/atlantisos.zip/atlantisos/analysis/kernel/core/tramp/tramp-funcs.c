//#include <kernel/core/tramp/tramp-local.h>
//#include <kernel/core/tramp/tramp.h>

char *tramp_sbrk(uint32 bytes) {
	if (bytes > 1<<31) {
		return NULL;
	}

	pm_brk(bytes);
}

/*
 * process functionality
 */
void tramp_create_thread(void (*start)(void *arg), void *arg, uint32 flags) {
	
}

void tramp_create_process(void (*start)(void *arg), void *arg, uint32 flags) {
	
}

void tramp_exit() {
	
}

uintn tramp_kill_thread(tid_t thread) {
	
}

uintn tramp_kill_process(pid_t process) {
	
}

/*
 * Object repository functions
 */
obj_t *tramp_get_object(uint32 type, uint32 num) {
	
}

void tramp_set_object_var(obj_t *object, int number, void *value) {
	
}

void *tramp_get_object_var(obj_t *object, int number) {
	
}

void tramp_return_object(obj_t *object) {
	
}

