#ifndef __KERNEL_CORE_TRAMP_TRAMP
#define __KERNEL_CORE_TRAMP_TRAMP

uintn tramp_cpl0call(...);

#endif
