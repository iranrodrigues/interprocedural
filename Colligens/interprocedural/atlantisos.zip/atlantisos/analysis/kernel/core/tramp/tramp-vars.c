//#include <kernel/core/tramp/tramp-local.h>
//#include <kernel/defines.h>

struct tramp_funcs tramp_functions[] = {
        {(tramp_func)&tramp_sbrk, 1},
        {(tramp_func)&tramp_create_thread, 3},
        {(tramp_func)&tramp_create_process, 3},
        {(tramp_func)&tramp_exit, 0},
        {(tramp_func)&tramp_kill_thread, 1},
        {(tramp_func)&tramp_kill_process, 1},
        {(tramp_func)&tramp_get_object, 2},
        {(tramp_func)&tramp_set_object_var, 3},
        {(tramp_func)&tramp_get_object_var, 2},
        {(tramp_func)&tramp_return_object, 1},
        {(tramp_func)0, 0}
};

uintn tramp_max_funcs = 10;

