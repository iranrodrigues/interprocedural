//#include <kernel/core/tramp/tramp.h>
//#include <kernel/core/tramp/tramp-local.h>

uintn tramp_general_entry(uintn a, uintn b, uintn c, uintn d, uintn e) {
	// a == number of function, b-e == arguments
	if (a > tramp_max_func) {
		
	}

	tramp_functions[a].func(b, c, d, e);
}
