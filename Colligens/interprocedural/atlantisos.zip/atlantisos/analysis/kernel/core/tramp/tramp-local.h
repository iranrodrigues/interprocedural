#ifndef __KERNEL_CORE_TRAMP_TRAMP_LOCAL
#define __KERNEL_CORE_TRAMP_TRAMP_LOCAL

//#include <kernel/defines.h>

#if FAMILY==2 && WORD_LENGTH==64
// 64-bit cpl3 entry point
uintn tramp_syscall_64(uintn a, uintn b, uintn c, uintn d, uintn e);
#endif

#if FAMILY==2
// 32-bit cpl3 entry point, amd
uintn tramp_syscall_32(uintn a, uintn b, uintn c, uintn d, uintn e);
#else
// 32-bit cpl3 entry point, intel
uintn tramp_sysenter(uintn a, uintn b, uintn c, uintn d, uintn e);
#endif

typedef uintn(*tramp_func)(uintn, uintn, uintn, uintn);

extern uintn tramp_max_funcs;

char *tramp_sbrk(uint32 bytes);
void tramp_create_thread(void (*start)(void *arg), void *arg, uint32 flags);
void tramp_create_process(void (*start)(void *arg), void *arg, uint32 flags);
void tramp_exit();
uintn tramp_kill_thread(tid_t thread);
uintn tramp_kill_process(pid_t process);
obj_t *tramp_get_object(uint32 type, uint32 num);
void tramp_set_object_var(obj_t *object, int number, void *value);
void *tramp_get_object_var(obj_t *object, int number);
void tramp_return_object(obj_t *object);

struct tramp_funcs{
	tramp_func func;
	uintn numargs;
};

extern struct tramp_funcs tramp_functions[];

#endif
