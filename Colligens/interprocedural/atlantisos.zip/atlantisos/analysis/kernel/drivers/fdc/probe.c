//#include "probe.h"

// there is no probe for this driver
// since probe is required in the driver interface, place it here anyway

bool probe() {
	return 1;
}

