//#include "fd.h"

iosa_reach_t r1;
iosa_reach_t r2;
dma_handle_t dma_ch;

int init() {
	// register all things required, start worker thread
	// the interrupt is constantly reregistered by the worker
	// the IO reach must be allocated and stored in the driver context
	iosa_reach_t r1 = iosa_get(0x3F0, 0x3F7);
	if (r1 == 0) return 1;
	iosa_reach_t r2 = iosa_get(0x370, 0x377);
	if (r2 == 0) return 2;
	dma_handle_t dma_ch = dma_get(2);
	if (dma_ch == 0) return 3;

	pm_create_thread(0, &worker);
}

