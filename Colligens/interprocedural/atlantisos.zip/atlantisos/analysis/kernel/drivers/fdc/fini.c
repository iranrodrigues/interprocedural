//#include "fd.h"

void fini() {
	// wait until the last thread using this module has stopped, and
	// steal the mutex (as in, stop)
	mutex_stop(&current_mutex);
	pm_kill_thread(worker_tid);
	pm_kill_thread(cothread_tid);
	for (i=0; i<8; i++) {
		if (drive_shutdown_tids[i] != 0) {
			pm_kill_thread(drive_shutdown_tids[i]);
		}
	}

	// all active threads stopped, finish off the usage
	dma_release(dma_ch);
	iosa_release(r1);
	iosa_release(r2);
}

