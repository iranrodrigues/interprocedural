//#include "fd.h"

command current;
tid_t drive_shutdown_tids[8];
tid_t worker_tid, cothread_tid;
mutex_t current_mutex;

void worker() {
	// this thread actually does the trouble.
	// it processes all calls in order. No trouble at all is made to
	// speed up the process, since its an ancient technology.
	// the algorithm is spread out in comments

	int cport = 0;
	int cdrive = 0;
	int retry_count = 0;
	int i;

	mutex_start(&current_mutex);

	current.command.check = 0;

	worker_tid = pm_get_current_tid();
	cothread_tid = pm_create_thread(0, &cothread);

	while(1) {
		// wait for a command
		sched_block();

		// check command byte to set current environment variables correctly
		// check == 0 for results, check == 1 for commands
		if (current.command.check == 0) continue;

		if (current.command.controller == 1) {
			cport = 0x370;
		} else {
			cport = 0x3F0;
		}

		// signal timer module to give me a signal in 1.5 second
		timer_register(1500, cothread_tid);
		
		// wait for controller and send command (slowly)
		if (current.command.drivecommand == 1) {
			// activate drive
			outb(cport + 2, 0xC + (1 << (current.command.drive + 4)) + current.command.drive);
			timer_unregister(drive_shutdown_tids[current.command.drive + current.command.controller * 4]);
		}

		for (i=0; i<current.command.bytecount; i++) {
			while((inb(cport + 4) & 0x80) != 0x80);	// intentionally empty, busy wait for the controller
			outb(cport + 5, current.command.bytes[i]);
		}

		// block waiting for signal
		sched_block();

		// there has been some sort of signal, so start the timer for
		// the floppy drive disable thread
		timer_register(2000, drive_shutdown_tids[current.command.drive + current.command.controller * 4]);

		// check whether the floppy controller sent an interrupt
		if (current.command.gonebad) {
			// if not, attempt reset, signal myself (to avoid a block
			// at the next attempt to execute this (signals are stored))
			current.command.gonebad = 0;

			outb(cport + 2, 0x8);	// kick the controller

			retry_count++;
			if (retry_count > 2) {
				// assume command is invalid
				// store result, signal owner and move to next command
				current.result.check = 0;
				retry_count = 0;
			}
			sched_signal(worker_tid);
		} else {
			int tid = current.command.tid;

			// if so, store the result
			current.result.check = 0;

			for (i=0; i<current.command.statusbytes; i++) {
				while(inb(cport+4) & 0x80 == 0);
				current.result.bytes[i] = inb(cport + 5);
			}

			// signal the owner
			sched_signal(tid);
		}
		// and loop back
	}
}

void cothread() {
	// this thread is solely responsible for telling the main thread 
	// that the command was unjustly terminated by timeout.
	// sucky solution but its the only one
	while(1) {
		sched_block();
		current.command.gonebad = 1;
		sched_signal(worker_tid);
	}
}
