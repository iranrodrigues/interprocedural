#ifndef __KERNEL_DRIVERS_FDC
#define __KERNEL_DRIVERS_FDC

//#include <driver.h>
//#include <defines.h>

typedef union {
	struct {
		char bytes[10];
		uint16 bytecount:4;
		uint16 statusbytes:4;
		uint16 check:1;
		uint16 controller:1;
		uint16 drive:2;
		uint16 drivecommand:1;
		uint16 gonebad:1;
		uint16 retrycount:2;
		tid_t tid;
	} command;

	struct {
		char bytes[10]; // result phase
                uint16 bytecount:4;
                uint16 statusbytes:4;
                uint16 check:1;
                uint16 controller:1;
                uint16 drive:2;
                uint16 drivecommand:1;
                uint16 gonebad:1;
                uint16 retrycount:2;
		tid_t tid;
	} result;
} command;

extern iosa_handle_t r1;
extern iosa_handle_t r2;
extern dma_handle_t dma_ch;
extern command current;
extern tid_t drive_shutdown_tids[8];
extern tid_t worker_tid, cothread_tid;
extern mutex_t current_mutex;

void cothread(void);
void worker(void);

#endif

