#ifndef __KERNEL_DRIVERS_XH
#define __KERNEL_DRIVERS_XH

//#include <defines.h>

typedef void (*xh_handler)(uintn, uintn);

void xh_register(int exception, xh_handler handler);

#endif
