#ifndef __KERNEL_DRIVERS_PAGER
#define __KERNEL_DRIVERS_PAGER

//#include <defines.h>

void pager_map_page(uintn virt, uintn phys, int flags);
uintn pager_unmap(uintn virt);

typedef void (*pf_handler)(uintn error, uintn eip, uintn virt);

void pager_add_pf_handler(pf_handler handler, uintn minvirt, uintn maxvirt, uintn mineip, uintn maxeip);
void pager_delete_pf_handler(pf_handler handler, uintn minvirt, uintn maxvirt, uintn mineip, uintn maxeip);

#endif

