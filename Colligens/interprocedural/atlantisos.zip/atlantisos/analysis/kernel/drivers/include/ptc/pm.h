#ifndef __KERNEL_DRIVERS_PM
#define __KERNEL_DRIVERS_PM

//#include <defines.h>

tid_t pm_get_current_thread(void);
char *pm_get_name(pid_t process);
pid_t pm_get_pid(tid_t thread);

typedef void (*pm_entry)(void);

pid_t pm_create_process(void);
tid_t pm_create_thread(pid_t process, pm_entry entrypoint);
void pm_kill_process(pid_t process);
void pm_kill_thread(tid_t thread);

#endif
