#ifndef __KERNEL_DRIVERS_SCHED
#define __KERNEL_DRIVERS_SCHED

//#include <defines.h>

void sched_yield(tid_t thread);
void sched_block(void);
void sched_signal(tid_t thread);

#endif
