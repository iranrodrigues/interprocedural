#ifndef __KERNEL_DRIVERS_KPRINTF
#define __KERNEL_DRIVERS_KPRINTF

void kprintf(int level, char *text, ...);

#endif
