#ifndef __KERNEL_DRIVERS_HWINT
#define __KERNEL_DRIVERS_HWINT

//#include <defines.h>

void hwint_wait_for_interrupt(int hwint);
void hwint_register_interrupt(int hwint);

#endif
