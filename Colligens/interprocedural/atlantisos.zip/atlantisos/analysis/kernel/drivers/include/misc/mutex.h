#ifndef __KERNEL_DRIVERS_MUTEX
#define __KERNEL_DRIVERS_MUTEX

//#include <defines.h>

void mutex_start(uint8 *mutex);
void mutex_wait(uint8 *mutex);
void mutex_wait_long(uint8 *mutex);
void mutex_release(uint8 *mutex);
void mutex_stop(uint8 *mutex);

#endif
