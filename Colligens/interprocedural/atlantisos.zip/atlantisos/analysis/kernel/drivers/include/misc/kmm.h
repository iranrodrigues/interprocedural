#ifndef __KERNEL_DRIVERS_KMM
#define __KERNEL_DRIVERS_KMM

//#include <defines.h>

#define kmalloc(x) kmm_malloc(x)
#define kfree(x) kmm_free(x)

char *kmm_malloc(uintn amount);
void kmm_free(char *what);

#endif
