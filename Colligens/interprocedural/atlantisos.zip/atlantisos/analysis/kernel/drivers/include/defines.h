#ifndef __KERNEL_DEFINES
#define __KERNEL_DEFINES

//#include <types.h>
//#include <asm-macros.h>
//#include <config.h>

#define true 1
#define false 0
#define NULL (void *)0

#endif
