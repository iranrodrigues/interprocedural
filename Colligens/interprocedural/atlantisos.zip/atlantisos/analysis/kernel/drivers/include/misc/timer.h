#ifndef __KERNEL_DRIVERS_TIMER
#define __KERNEL_DRIVERS_TIMER

void timer_register(int jiffies, int tid);
void timer_cancel(int tid);

#endif

