#ifndef __KERNEL_TYPES
#ifndef DEFINES_H
#define __KERNEL_TYPES
#define DEFINES_H

// different INT types

// unsigned of varying formats
typedef unsigned long		uintn;
typedef unsigned char		uint8;
typedef unsigned short int	uint16;
typedef unsigned int		uint32;
typedef unsigned long long	uint64;

// signed of varying formats
typedef signed long		sintn;
typedef signed char		sint8;
typedef signed short int	sint16;
typedef signed int		sint32;
typedef signed long long	sint64;

/*********************\
|** threading types **|
\*********************/
typedef uint16 tid_t;
typedef uint16 pid_t;

/*************************\
|** user administration **|
\*************************/
typedef uint16 uid_t;
typedef uint16 gid_t;

/*********************\
|** subsystem types **|
\*********************/
typedef uint32 wchar;
typedef wchar wchar_t;

/*****************************\
|** object repository types **|
\*****************************/
typedef struct {
	uint8 majortype;
	uint8 minortype;
	uint16 num;
} obj_t;

typedef uint8 mutex_t;

#endif
#endif

