//#include <kernel/core/ih/ih.h>
//#include <kernel/core/xh/xh.h>
//#include <kernel/core/hwint/hwint.h>
//#include <kernel/core/mutex/mutex.h>
//#include <kernel/core/fp/fp.h>
//#include <kernel/core/pm/pm.h>
//#include <kernel/core/pager/pager.h>
//#include <kernel/core/sched/sched.h>
//#include <kernel/core/kpf/kpf.h>
//#include <kernel/core/kmm/kmm.h>
//#include <kernel/core/timer/timer.h>
//#include <kernel/core/pm/gsbase.h>

void do_bootup_message(void);
int _start(void);
void start_core(void);
void remap_stack(void);

int _start(void) {
	start_core();
	remap_stack();

	asm ("sti");

	asm ("int $0x30");
	while(1);
}

extern uintn kernel_max_mem;

void start_core(void) {
	char *gdt;
	// init the very first set of free pages
	// between the markers YYYYY and ZZZZZ only up to 7 MB of
	// memory may be allocated!
	// more memory requires having an actual page thread running, 
	// which cannot be done until after the scheduler runs, which 
	// requires the process manager, which depends on some free pages

	// this variable is positioned at the end of the file, explicitly
	// so it's address is also the end of the memory (that is mapped), when increased by its size
	// after this point dynamic memory allocation may start

	// fp_init_1 makes a small set of free pages available without
	// needing those threads, also allows freeing some pages
	// because the buffers are not yet maintained, its cripple.
	// YYYYY
	fp_init_1();

	// map a number of pages that would be auto-mapped by the exception handler, 
	// which needs those pages to function... chicken & egg situation, so let's 
	// make a manual egg
	// procdata for this processor
	pager_map_page(0xFF000, fp_get_zeroed_page(), AL_FL_WRITABLE | AL_FL_GLOBAL | AL_FL_NOEXEC);

	// first three thread pages (first 12 threads)
	pager_map_page(0xFE000, fp_get_zeroed_page(), AL_FL_WRITABLE | AL_FL_GLOBAL | AL_FL_NOEXEC);
	pager_map_page(0xFE001, fp_get_zeroed_page(), AL_FL_WRITABLE | AL_FL_GLOBAL | AL_FL_NOEXEC);
	pager_map_page(0xFE002, fp_get_zeroed_page(), AL_FL_WRITABLE | AL_FL_GLOBAL | AL_FL_NOEXEC);

	// first process page (first N processes)
	pager_map_page(0xFF102, fp_get_zeroed_page(), AL_FL_WRITABLE | AL_FL_GLOBAL | AL_FL_NOEXEC);

	// IDT & GDT
	pager_map_page(0xFF100, 0x1, AL_FL_WRITABLE | AL_FL_GLOBAL | AL_FL_NOEXEC);

	// tell the GDT where he is now
	// limit == 0x7FF
	gdt = (char *)0xFF100802;
	gdt[0] = 0xFF;
	gdt[1] = 0x07;

	gdt[2] = 0x00;
	gdt[3] = 0x00;
	gdt[4] = 0x10;
	gdt[5] = 0xFF;

	asm ("lidt (%0)\n" :: "r"(gdt));

	gdt[1] = 0x03;
	gdt[3] = 0x08;
	asm ("lgdt (%0)\n" :: "r"(gdt));

	// page fault handler table
	pager_map_page(0xFF120, fp_get_zeroed_page(), AL_FL_WRITABLE | AL_FL_GLOBAL | AL_FL_NOEXEC);

	// init the gs procdata mechanism
	gs_init();

	// interrupt and exception mechanism, total
	ih_init();
	xh_init();
	hwint_init();
	kpf_init();

	// memory management for pm code
	kmm_init();

	// starting process & thread management, and the scheduling of them
	sched_init();
	pm_init();

	// memory management final initialisation
	fp_init_2();

	// ZZZZZ

	timer_init();

	// for now, this is all
}

void do_bootup_message(void) {
	char *vmem = (char *)0xB8000;
	char *message = "AtlantisOS booted up correctly! Kernel started!";
	char color = 0x07;

	while (*message != 0) {
		*(vmem++) = *message++;
		*(vmem++) = color;
	}
	while(1);
}

void remap_stack(void) {
	pager_map_page(0xFDFFF, 0x9F, AL_FL_WRITABLE | AL_FL_GLOBAL | AL_FL_NOEXEC);
	asm ("add $0xFDF60000, %ebp");
}

