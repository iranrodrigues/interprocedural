#ifndef __KERNEL_KERNEL_START
#define __KERNEL_KERNEL_START

void do_bootup_message(void);
int _start(void);

#endif
