#ifndef __KERNEL_CONFIG_IA32
#define __KERNEL_CONFIG_IA32

#define WORD_LENGTH 32
#define RUNCALL

#endif
