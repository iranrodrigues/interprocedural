#ifndef __KERNEL_DEFINES
#define __KERNEL_DEFINES

//#include <kernel/types.h>
//#include <kernel/asm-macros.h>
//#include <kernel/config.h>

#define true 1
#define false 0
#define NULL (void *)0

#endif
