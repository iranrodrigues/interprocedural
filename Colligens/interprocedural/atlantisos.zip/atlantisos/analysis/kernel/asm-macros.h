#ifndef __KERNEL_ASM_MACROS
#define __KERNEL_ASM_MACROS
#define __KERNEL_I386_ASM_MACROS

#define outb(x,y) asm("\toutb %%dx, %%al"::"d"(x),"a"(y))
#define outw(x,y) asm("\toutw %%dx, %%ax"::"d"(x),"a"(y))
#define outd(x,y) asm("\toutl %%dx, %%eax"::"d"(x),"a"(y))

#endif
