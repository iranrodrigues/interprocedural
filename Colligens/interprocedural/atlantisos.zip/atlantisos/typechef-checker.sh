echo FILE: analysis/boot/boot.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/boot/boot.h
echo FILE: analysis/boot/cinit.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/boot/cinit.c
echo FILE: analysis/boot/cinit.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/boot/cinit.h
echo FILE: analysis/boot/config.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/boot/config.h
echo FILE: analysis/boot/debug.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/boot/debug.c
echo FILE: analysis/boot/debug.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/boot/debug.h
echo FILE: analysis/boot/defines.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/boot/defines.h
echo FILE: analysis/boot/elf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/boot/elf.c
echo FILE: analysis/boot/elf.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/boot/elf.h
echo FILE: analysis/boot/floppy.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/boot/floppy.c
echo FILE: analysis/boot/floppy.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/boot/floppy.h
echo FILE: analysis/boot/loader.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/boot/loader.c
echo FILE: analysis/boot/loader.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/boot/loader.h
echo FILE: analysis/boot/paging-start.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/boot/paging-start.c
echo FILE: analysis/boot/paging-start.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/boot/paging-start.h
echo FILE: analysis/boot/paging.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/boot/paging.c
echo FILE: analysis/boot/paging.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/boot/paging.h
echo FILE: analysis/kernel/asm-macros.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/asm-macros.h
echo FILE: analysis/kernel/config-ia32.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/config-ia32.h
echo FILE: analysis/kernel/config.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/config.h
echo FILE: analysis/kernel/core/fp/fp-local.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/fp/fp-local.h
echo FILE: analysis/kernel/core/fp/fp.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/fp/fp.h
echo FILE: analysis/kernel/core/fp/high.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/fp/high.c
echo FILE: analysis/kernel/core/fp/init.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/fp/init.c
echo FILE: analysis/kernel/core/fp/low.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/fp/low.c
echo FILE: analysis/kernel/core/fp/vars.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/fp/vars.c
echo FILE: analysis/kernel/core/hwint/hwint-c.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/hwint/hwint-c.c
echo FILE: analysis/kernel/core/hwint/hwint.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/hwint/hwint.h
echo FILE: analysis/kernel/core/ih/ih-c.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/ih/ih-c.c
echo FILE: analysis/kernel/core/ih/ih.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/ih/ih.h
echo FILE: analysis/kernel/core/kmm/internal.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/kmm/internal.h
echo FILE: analysis/kernel/core/kmm/kmm-c.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/kmm/kmm-c.c
echo FILE: analysis/kernel/core/kmm/kmm-vars.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/kmm/kmm-vars.c
echo FILE: analysis/kernel/core/kmm/kmm.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/kmm/kmm.h
echo FILE: analysis/kernel/core/kpf/kpf-c.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/kpf/kpf-c.c
echo FILE: analysis/kernel/core/kpf/kpf.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/kpf/kpf.h
echo FILE: analysis/kernel/core/mutex/mutex-c.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/mutex/mutex-c.c
echo FILE: analysis/kernel/core/mutex/mutex.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/mutex/mutex.h
echo FILE: analysis/kernel/core/pager/hash.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pager/hash.h
echo FILE: analysis/kernel/core/pager/map.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pager/map.c
echo FILE: analysis/kernel/core/pager/pager-c.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pager/pager-c.c
echo FILE: analysis/kernel/core/pager/pager.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pager/pager.h
echo FILE: analysis/kernel/core/pager/pf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pager/pf.c
echo FILE: analysis/kernel/core/pager/unmap.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pager/unmap.c
echo FILE: analysis/kernel/core/pm/fp-funcs.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pm/fp-funcs.c
echo FILE: analysis/kernel/core/pm/gsbase.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pm/gsbase.c
echo FILE: analysis/kernel/core/pm/gsbase.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pm/gsbase.h
echo FILE: analysis/kernel/core/pm/pm-c.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pm/pm-c.c
echo FILE: analysis/kernel/core/pm/pm-local.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pm/pm-local.h
echo FILE: analysis/kernel/core/pm/pm.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pm/pm.h
echo FILE: analysis/kernel/core/pm/procdata.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pm/procdata.h
echo FILE: analysis/kernel/core/pm/process.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pm/process.c
echo FILE: analysis/kernel/core/pm/process.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pm/process.h
echo FILE: analysis/kernel/core/pm/terminator.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pm/terminator.c
echo FILE: analysis/kernel/core/pm/terminator.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pm/terminator.h
echo FILE: analysis/kernel/core/pm/thread.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pm/thread.c
echo FILE: analysis/kernel/core/pm/thread.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/pm/thread.h
echo FILE: analysis/kernel/core/sched/sched-c.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/sched/sched-c.c
echo FILE: analysis/kernel/core/sched/sched-vars.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/sched/sched-vars.c
echo FILE: analysis/kernel/core/sched/sched.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/sched/sched.h
echo FILE: analysis/kernel/core/text/kprintf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/text/kprintf.c
echo FILE: analysis/kernel/core/text/kprintf.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/text/kprintf.h
echo FILE: analysis/kernel/core/text/text.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/text/text.h
echo FILE: analysis/kernel/core/timer/timer-c.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/timer/timer-c.c
echo FILE: analysis/kernel/core/timer/timer.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/timer/timer.h
echo FILE: analysis/kernel/core/tramp/tramp-entry.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/tramp/tramp-entry.c
echo FILE: analysis/kernel/core/tramp/tramp-funcs.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/tramp/tramp-funcs.c
echo FILE: analysis/kernel/core/tramp/tramp-local.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/tramp/tramp-local.h
echo FILE: analysis/kernel/core/tramp/tramp-vars.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/tramp/tramp-vars.c
echo FILE: analysis/kernel/core/tramp/tramp.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/tramp/tramp.h
echo FILE: analysis/kernel/core/xh/xh-abort.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/xh/xh-abort.c
echo FILE: analysis/kernel/core/xh/xh-abort.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/xh/xh-abort.h
echo FILE: analysis/kernel/core/xh/xh-c.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/xh/xh-c.c
echo FILE: analysis/kernel/core/xh/xh-kill.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/xh/xh-kill.c
echo FILE: analysis/kernel/core/xh/xh-kill.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/xh/xh-kill.h
echo FILE: analysis/kernel/core/xh/xh-normal.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/xh/xh-normal.c
echo FILE: analysis/kernel/core/xh/xh-normal.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/xh/xh-normal.h
echo FILE: analysis/kernel/core/xh/xh.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/core/xh/xh.h
echo FILE: analysis/kernel/defines.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/defines.h
echo FILE: analysis/kernel/drivers/fdc/fd.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/fdc/fd.h
echo FILE: analysis/kernel/drivers/fdc/fini.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/fdc/fini.c
echo FILE: analysis/kernel/drivers/fdc/init.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/fdc/init.c
echo FILE: analysis/kernel/drivers/fdc/probe.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/fdc/probe.c
echo FILE: analysis/kernel/drivers/fdc/receive.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/fdc/receive.c
echo FILE: analysis/kernel/drivers/fdc/send.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/fdc/send.c
echo FILE: analysis/kernel/drivers/fdc/worker.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/fdc/worker.c
echo FILE: analysis/kernel/drivers/include/asm-macros.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/asm-macros.h
echo FILE: analysis/kernel/drivers/include/config.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/config.h
echo FILE: analysis/kernel/drivers/include/defines.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/defines.h
echo FILE: analysis/kernel/drivers/include/driver.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/driver.h
echo FILE: analysis/kernel/drivers/include/imc.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/imc.h
echo FILE: analysis/kernel/drivers/include/int/hwint.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/int/hwint.h
echo FILE: analysis/kernel/drivers/include/int/ih.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/int/ih.h
echo FILE: analysis/kernel/drivers/include/int/xh.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/int/xh.h
echo FILE: analysis/kernel/drivers/include/int.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/int.h
echo FILE: analysis/kernel/drivers/include/iosa.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/iosa.h
echo FILE: analysis/kernel/drivers/include/lasa.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/lasa.h
echo FILE: analysis/kernel/drivers/include/misc/kmm.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/misc/kmm.h
echo FILE: analysis/kernel/drivers/include/misc/kprintf.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/misc/kprintf.h
echo FILE: analysis/kernel/drivers/include/misc/mutex.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/misc/mutex.h
echo FILE: analysis/kernel/drivers/include/misc/timer.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/misc/timer.h
echo FILE: analysis/kernel/drivers/include/misc.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/misc.h
echo FILE: analysis/kernel/drivers/include/pager/pager.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/pager/pager.h
echo FILE: analysis/kernel/drivers/include/pager.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/pager.h
echo FILE: analysis/kernel/drivers/include/ptc/pm.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/ptc/pm.h
echo FILE: analysis/kernel/drivers/include/ptc/sched.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/ptc/sched.h
echo FILE: analysis/kernel/drivers/include/ptc.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/ptc.h
echo FILE: analysis/kernel/drivers/include/types.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/drivers/include/types.h
echo FILE: analysis/kernel/kernel_start.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/kernel_start.c
echo FILE: analysis/kernel/kernel_start.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/kernel_start.h
echo FILE: analysis/kernel/types.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/kernel/types.h
echo FILE: analysis/libc/blah.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libc/blah.h
