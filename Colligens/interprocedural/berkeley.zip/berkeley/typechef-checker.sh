echo FILE: analysis/btree/bt_compact.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_compact.c
echo FILE: analysis/btree/bt_compare.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_compare.c
echo FILE: analysis/btree/bt_conv.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_conv.c
echo FILE: analysis/btree/bt_curadj.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_curadj.c
echo FILE: analysis/btree/bt_cursor.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_cursor.c
echo FILE: analysis/btree/bt_delete.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_delete.c
echo FILE: analysis/btree/bt_method.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_method.c
echo FILE: analysis/btree/bt_open.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_open.c
echo FILE: analysis/btree/bt_put.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_put.c
echo FILE: analysis/btree/bt_rec.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_rec.c
echo FILE: analysis/btree/bt_reclaim.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_reclaim.c
echo FILE: analysis/btree/bt_recno.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_recno.c
echo FILE: analysis/btree/bt_rsearch.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_rsearch.c
echo FILE: analysis/btree/bt_search.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_search.c
echo FILE: analysis/btree/bt_split.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_split.c
echo FILE: analysis/btree/bt_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_stat.c
echo FILE: analysis/btree/bt_upgrade.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_upgrade.c
echo FILE: analysis/btree/bt_verify.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/bt_verify.c
echo FILE: analysis/btree/btree_auto.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/btree_auto.c
echo FILE: analysis/btree/btree_autop.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/btree/btree_autop.c
echo FILE: analysis/build_brew/brew_db.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_brew/brew_db.h
echo FILE: analysis/build_brew/clib_port.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_brew/clib_port.h
echo FILE: analysis/build_brew/db.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_brew/db.h
echo FILE: analysis/build_brew/db_config.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_brew/db_config.h
echo FILE: analysis/build_brew/db_int.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_brew/db_int.h
echo FILE: analysis/build_brew/errno.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_brew/errno.h
echo FILE: analysis/build_s60/clib_port.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_s60/clib_port.h
echo FILE: analysis/build_s60/db.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_s60/db.h
echo FILE: analysis/build_s60/db_config.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_s60/db_config.h
echo FILE: analysis/build_s60/db_int.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_s60/db_int.h
echo FILE: analysis/build_vxworks/clib_port.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/clib_port.h
echo FILE: analysis/build_vxworks/db.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/db.h
echo FILE: analysis/build_vxworks/db_archive/db_archive.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/db_archive/db_archive.c
echo FILE: analysis/build_vxworks/db_checkpoint/db_checkpoint.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/db_checkpoint/db_checkpoint.c
echo FILE: analysis/build_vxworks/db_config.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/db_config.h
echo FILE: analysis/build_vxworks/db_config_small.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/db_config_small.h
echo FILE: analysis/build_vxworks/db_deadlock/db_deadlock.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/db_deadlock/db_deadlock.c
echo FILE: analysis/build_vxworks/db_dump/db_dump.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/db_dump/db_dump.c
echo FILE: analysis/build_vxworks/db_hotbackup/db_hotbackup.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/db_hotbackup/db_hotbackup.c
echo FILE: analysis/build_vxworks/db_int.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/db_int.h
echo FILE: analysis/build_vxworks/db_load/db_load.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/db_load/db_load.c
echo FILE: analysis/build_vxworks/db_printlog/db_printlog.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/db_printlog/db_printlog.c
echo FILE: analysis/build_vxworks/db_recover/db_recover.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/db_recover/db_recover.c
echo FILE: analysis/build_vxworks/db_stat/db_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/db_stat/db_stat.c
echo FILE: analysis/build_vxworks/db_upgrade/db_upgrade.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/db_upgrade/db_upgrade.c
echo FILE: analysis/build_vxworks/db_verify/db_verify.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/db_verify/db_verify.c
echo FILE: analysis/build_vxworks/dbdemo/dbdemo.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/dbdemo/dbdemo.c
echo FILE: analysis/build_vxworks/test_micro/b_curalloc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/b_curalloc.c
echo FILE: analysis/build_vxworks/test_micro/b_curwalk.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/b_curwalk.c
echo FILE: analysis/build_vxworks/test_micro/b_del.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/b_del.c
echo FILE: analysis/build_vxworks/test_micro/b_get.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/b_get.c
echo FILE: analysis/build_vxworks/test_micro/b_inmem.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/b_inmem.c
echo FILE: analysis/build_vxworks/test_micro/b_load.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/b_load.c
echo FILE: analysis/build_vxworks/test_micro/b_open.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/b_open.c
echo FILE: analysis/build_vxworks/test_micro/b_put.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/b_put.c
echo FILE: analysis/build_vxworks/test_micro/b_recover.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/b_recover.c
echo FILE: analysis/build_vxworks/test_micro/b_txn.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/b_txn.c
echo FILE: analysis/build_vxworks/test_micro/b_txn_write.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/b_txn_write.c
echo FILE: analysis/build_vxworks/test_micro/b_uname.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/b_uname.c
echo FILE: analysis/build_vxworks/test_micro/b_util.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/b_util.c
echo FILE: analysis/build_vxworks/test_micro/b_workload.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/b_workload.c
echo FILE: analysis/build_vxworks/test_micro/b_workload.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/b_workload.h
echo FILE: analysis/build_vxworks/test_micro/bench.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/bench.h
echo FILE: analysis/build_vxworks/test_micro/bench.h.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/bench.h.c
echo FILE: analysis/build_vxworks/test_micro/inmem.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/inmem.c
echo FILE: analysis/build_vxworks/test_micro/test_micro.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/test_micro.c
echo FILE: analysis/build_vxworks/test_micro/uname.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_vxworks/test_micro/uname.c
echo FILE: analysis/build_wince/clib_port.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_wince/clib_port.h
echo FILE: analysis/build_wince/db.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_wince/db.h
echo FILE: analysis/build_wince/db_config.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_wince/db_config.h
echo FILE: analysis/build_wince/db_int.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_wince/db_int.h
echo FILE: analysis/build_wince/errno.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_wince/errno.h
echo FILE: analysis/build_windows/clib_port.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_windows/clib_port.h
echo FILE: analysis/build_windows/db.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_windows/db.h
echo FILE: analysis/build_windows/db_config.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_windows/db_config.h
echo FILE: analysis/build_windows/db_int.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/build_windows/db_int.h
echo FILE: analysis/clib/atoi.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/atoi.c
echo FILE: analysis/clib/atol.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/atol.c
echo FILE: analysis/clib/getcwd.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/getcwd.c
echo FILE: analysis/clib/getopt.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/getopt.c
echo FILE: analysis/clib/isalpha.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/isalpha.c
echo FILE: analysis/clib/isdigit.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/isdigit.c
echo FILE: analysis/clib/isprint.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/isprint.c
echo FILE: analysis/clib/isspace.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/isspace.c
echo FILE: analysis/clib/memcmp.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/memcmp.c
echo FILE: analysis/clib/memmove.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/memmove.c
echo FILE: analysis/clib/printf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/printf.c
echo FILE: analysis/clib/qsort.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/qsort.c
echo FILE: analysis/clib/raise.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/raise.c
echo FILE: analysis/clib/rand.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/rand.c
echo FILE: analysis/clib/snprintf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/snprintf.c
echo FILE: analysis/clib/strcasecmp.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/strcasecmp.c
echo FILE: analysis/clib/strcat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/strcat.c
echo FILE: analysis/clib/strchr.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/strchr.c
echo FILE: analysis/clib/strdup.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/strdup.c
echo FILE: analysis/clib/strerror.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/strerror.c
echo FILE: analysis/clib/strncat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/strncat.c
echo FILE: analysis/clib/strncmp.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/strncmp.c
echo FILE: analysis/clib/strrchr.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/strrchr.c
echo FILE: analysis/clib/strsep.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/strsep.c
echo FILE: analysis/clib/strtol.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/strtol.c
echo FILE: analysis/clib/strtoul.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/strtoul.c
echo FILE: analysis/clib/time.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/clib/time.c
echo FILE: analysis/common/crypto_stub.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/common/crypto_stub.c
echo FILE: analysis/common/db_byteorder.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/common/db_byteorder.c
echo FILE: analysis/common/db_err.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/common/db_err.c
echo FILE: analysis/common/db_getlong.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/common/db_getlong.c
echo FILE: analysis/common/db_idspace.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/common/db_idspace.c
echo FILE: analysis/common/db_log2.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/common/db_log2.c
echo FILE: analysis/common/db_shash.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/common/db_shash.c
echo FILE: analysis/common/dbt.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/common/dbt.c
echo FILE: analysis/common/mkpath.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/common/mkpath.c
echo FILE: analysis/common/openflags.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/common/openflags.c
echo FILE: analysis/common/os_method.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/common/os_method.c
echo FILE: analysis/common/util_arg.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/common/util_arg.c
echo FILE: analysis/common/util_cache.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/common/util_cache.c
echo FILE: analysis/common/util_log.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/common/util_log.c
echo FILE: analysis/common/util_sig.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/common/util_sig.c
echo FILE: analysis/common/zerofill.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/common/zerofill.c
echo FILE: analysis/crypto/aes_method.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/crypto/aes_method.c
echo FILE: analysis/crypto/crypto.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/crypto/crypto.c
echo FILE: analysis/crypto/mersenne/mt19937db.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/crypto/mersenne/mt19937db.c
echo FILE: analysis/crypto/rijndael/rijndael-alg-fst.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/crypto/rijndael/rijndael-alg-fst.c
echo FILE: analysis/crypto/rijndael/rijndael-alg-fst.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/crypto/rijndael/rijndael-alg-fst.h
echo FILE: analysis/crypto/rijndael/rijndael-api-fst.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/crypto/rijndael/rijndael-api-fst.c
echo FILE: analysis/crypto/rijndael/rijndael-api-fst.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/crypto/rijndael/rijndael-api-fst.h
echo FILE: analysis/db/crdel_auto.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/crdel_auto.c
echo FILE: analysis/db/crdel_autop.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/crdel_autop.c
echo FILE: analysis/db/crdel_rec.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/crdel_rec.c
echo FILE: analysis/db/db.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db.c
echo FILE: analysis/db/db_am.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_am.c
echo FILE: analysis/db/db_auto.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_auto.c
echo FILE: analysis/db/db_autop.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_autop.c
echo FILE: analysis/db/db_cam.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_cam.c
echo FILE: analysis/db/db_cds.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_cds.c
echo FILE: analysis/db/db_conv.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_conv.c
echo FILE: analysis/db/db_dispatch.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_dispatch.c
echo FILE: analysis/db/db_dup.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_dup.c
echo FILE: analysis/db/db_iface.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_iface.c
echo FILE: analysis/db/db_join.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_join.c
echo FILE: analysis/db/db_meta.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_meta.c
echo FILE: analysis/db/db_method.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_method.c
echo FILE: analysis/db/db_open.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_open.c
echo FILE: analysis/db/db_overflow.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_overflow.c
echo FILE: analysis/db/db_ovfl_vrfy.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_ovfl_vrfy.c
echo FILE: analysis/db/db_pr.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_pr.c
echo FILE: analysis/db/db_rec.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_rec.c
echo FILE: analysis/db/db_reclaim.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_reclaim.c
echo FILE: analysis/db/db_remove.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_remove.c
echo FILE: analysis/db/db_rename.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_rename.c
echo FILE: analysis/db/db_ret.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_ret.c
echo FILE: analysis/db/db_setid.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_setid.c
echo FILE: analysis/db/db_setlsn.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_setlsn.c
echo FILE: analysis/db/db_stati.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_stati.c
echo FILE: analysis/db/db_truncate.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_truncate.c
echo FILE: analysis/db/db_upg.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_upg.c
echo FILE: analysis/db/db_upg_opd.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_upg_opd.c
echo FILE: analysis/db/db_vrfy.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_vrfy.c
echo FILE: analysis/db/db_vrfy_stub.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_vrfy_stub.c
echo FILE: analysis/db/db_vrfyutil.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db/db_vrfyutil.c
echo FILE: analysis/db185/db185.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db185/db185.c
echo FILE: analysis/db_archive/db_archive.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db_archive/db_archive.c
echo FILE: analysis/db_checkpoint/db_checkpoint.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db_checkpoint/db_checkpoint.c
echo FILE: analysis/db_codegen/code_capi.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db_codegen/code_capi.c
echo FILE: analysis/db_codegen/code_parse.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db_codegen/code_parse.c
echo FILE: analysis/db_codegen/db_codegen.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db_codegen/db_codegen.c
echo FILE: analysis/db_codegen/db_codegen.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db_codegen/db_codegen.h
echo FILE: analysis/db_deadlock/db_deadlock.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db_deadlock/db_deadlock.c
echo FILE: analysis/db_dump/db_dump.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db_dump/db_dump.c
echo FILE: analysis/db_dump185/db_dump185.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db_dump185/db_dump185.c
echo FILE: analysis/db_hotbackup/db_hotbackup.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db_hotbackup/db_hotbackup.c
echo FILE: analysis/db_load/db_load.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db_load/db_load.c
echo FILE: analysis/db_printlog/db_printlog.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db_printlog/db_printlog.c
echo FILE: analysis/db_recover/db_recover.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db_recover/db_recover.c
echo FILE: analysis/db_stat/db_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db_stat/db_stat.c
echo FILE: analysis/db_upgrade/db_upgrade.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db_upgrade/db_upgrade.c
echo FILE: analysis/db_verify/db_verify.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/db_verify/db_verify.c
echo FILE: analysis/dbinc/btree.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/btree.h
echo FILE: analysis/dbinc/clock.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/clock.h
echo FILE: analysis/dbinc/crypto.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/crypto.h
echo FILE: analysis/dbinc/db_am.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/db_am.h
echo FILE: analysis/dbinc/db_dispatch.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/db_dispatch.h
echo FILE: analysis/dbinc/db_join.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/db_join.h
echo FILE: analysis/dbinc/db_page.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/db_page.h
echo FILE: analysis/dbinc/db_server_int.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/db_server_int.h
echo FILE: analysis/dbinc/db_swap.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/db_swap.h
echo FILE: analysis/dbinc/db_upgrade.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/db_upgrade.h
echo FILE: analysis/dbinc/db_verify.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/db_verify.h
echo FILE: analysis/dbinc/debug.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/debug.h
echo FILE: analysis/dbinc/fop.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/fop.h
echo FILE: analysis/dbinc/globals.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/globals.h
echo FILE: analysis/dbinc/hash.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/hash.h
echo FILE: analysis/dbinc/hmac.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/hmac.h
echo FILE: analysis/dbinc/lock.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/lock.h
echo FILE: analysis/dbinc/log.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/log.h
echo FILE: analysis/dbinc/mp.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/mp.h
echo FILE: analysis/dbinc/mutex.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/mutex.h
echo FILE: analysis/dbinc/os.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/os.h
echo FILE: analysis/dbinc/qam.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/qam.h
echo FILE: analysis/dbinc/queue.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/queue.h
echo FILE: analysis/dbinc/region.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/region.h
echo FILE: analysis/dbinc/rep.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/rep.h
echo FILE: analysis/dbinc/repmgr.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/repmgr.h
echo FILE: analysis/dbinc/shqueue.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/shqueue.h
echo FILE: analysis/dbinc/tcl_db.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/tcl_db.h
echo FILE: analysis/dbinc/txn.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/txn.h
echo FILE: analysis/dbinc/win_db.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/win_db.h
echo FILE: analysis/dbinc/xa.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc/xa.h
echo FILE: analysis/dbinc_auto/btree_auto.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/btree_auto.h
echo FILE: analysis/dbinc_auto/btree_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/btree_ext.h
echo FILE: analysis/dbinc_auto/clib_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/clib_ext.h
echo FILE: analysis/dbinc_auto/common_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/common_ext.h
echo FILE: analysis/dbinc_auto/crdel_auto.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/crdel_auto.h
echo FILE: analysis/dbinc_auto/crypto_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/crypto_ext.h
echo FILE: analysis/dbinc_auto/db_auto.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/db_auto.h
echo FILE: analysis/dbinc_auto/db_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/db_ext.h
echo FILE: analysis/dbinc_auto/dbreg_auto.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/dbreg_auto.h
echo FILE: analysis/dbinc_auto/dbreg_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/dbreg_ext.h
echo FILE: analysis/dbinc_auto/env_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/env_ext.h
echo FILE: analysis/dbinc_auto/fileops_auto.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/fileops_auto.h
echo FILE: analysis/dbinc_auto/fileops_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/fileops_ext.h
echo FILE: analysis/dbinc_auto/hash_auto.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/hash_auto.h
echo FILE: analysis/dbinc_auto/hash_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/hash_ext.h
echo FILE: analysis/dbinc_auto/hmac_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/hmac_ext.h
echo FILE: analysis/dbinc_auto/lock_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/lock_ext.h
echo FILE: analysis/dbinc_auto/log_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/log_ext.h
echo FILE: analysis/dbinc_auto/mp_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/mp_ext.h
echo FILE: analysis/dbinc_auto/mutex_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/mutex_ext.h
echo FILE: analysis/dbinc_auto/os_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/os_ext.h
echo FILE: analysis/dbinc_auto/qam_auto.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/qam_auto.h
echo FILE: analysis/dbinc_auto/qam_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/qam_ext.h
echo FILE: analysis/dbinc_auto/rep_auto.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/rep_auto.h
echo FILE: analysis/dbinc_auto/rep_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/rep_ext.h
echo FILE: analysis/dbinc_auto/repmgr_auto.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/repmgr_auto.h
echo FILE: analysis/dbinc_auto/repmgr_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/repmgr_ext.h
echo FILE: analysis/dbinc_auto/rpc_client_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/rpc_client_ext.h
echo FILE: analysis/dbinc_auto/rpc_server_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/rpc_server_ext.h
echo FILE: analysis/dbinc_auto/sequence_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/sequence_ext.h
echo FILE: analysis/dbinc_auto/tcl_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/tcl_ext.h
echo FILE: analysis/dbinc_auto/txn_auto.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/txn_auto.h
echo FILE: analysis/dbinc_auto/txn_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/txn_ext.h
echo FILE: analysis/dbinc_auto/xa_ext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbinc_auto/xa_ext.h
echo FILE: analysis/dbm/dbm.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbm/dbm.c
echo FILE: analysis/dbreg/dbreg.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbreg/dbreg.c
echo FILE: analysis/dbreg/dbreg_auto.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbreg/dbreg_auto.c
echo FILE: analysis/dbreg/dbreg_autop.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbreg/dbreg_autop.c
echo FILE: analysis/dbreg/dbreg_rec.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbreg/dbreg_rec.c
echo FILE: analysis/dbreg/dbreg_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbreg/dbreg_stat.c
echo FILE: analysis/dbreg/dbreg_util.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dbreg/dbreg_util.c
echo FILE: analysis/dist/api_flags.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dist/api_flags.c
echo FILE: analysis/dist/brew/brew_posix.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dist/brew/brew_posix.h
echo FILE: analysis/dist/errno.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/dist/errno.h
echo FILE: analysis/env/env_alloc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/env/env_alloc.c
echo FILE: analysis/env/env_config.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/env/env_config.c
echo FILE: analysis/env/env_failchk.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/env/env_failchk.c
echo FILE: analysis/env/env_file.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/env/env_file.c
echo FILE: analysis/env/env_globals.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/env/env_globals.c
echo FILE: analysis/env/env_method.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/env/env_method.c
echo FILE: analysis/env/env_name.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/env/env_name.c
echo FILE: analysis/env/env_open.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/env/env_open.c
echo FILE: analysis/env/env_recover.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/env/env_recover.c
echo FILE: analysis/env/env_region.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/env/env_region.c
echo FILE: analysis/env/env_register.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/env/env_register.c
echo FILE: analysis/env/env_sig.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/env/env_sig.c
echo FILE: analysis/env/env_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/env/env_stat.c
echo FILE: analysis/examples_c/bench_001.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/bench_001.c
echo FILE: analysis/examples_c/csv/code.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/csv/code.c
echo FILE: analysis/examples_c/csv/csv.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/csv/csv.h
echo FILE: analysis/examples_c/csv/csv_extern.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/csv/csv_extern.h
echo FILE: analysis/examples_c/csv/db.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/csv/db.c
echo FILE: analysis/examples_c/csv/DbRecord.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/csv/DbRecord.c
echo FILE: analysis/examples_c/csv/load.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/csv/load.c
echo FILE: analysis/examples_c/csv/load_main.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/csv/load_main.c
echo FILE: analysis/examples_c/csv/query.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/csv/query.c
echo FILE: analysis/examples_c/csv/query_main.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/csv/query_main.c
echo FILE: analysis/examples_c/csv/util.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/csv/util.c
echo FILE: analysis/examples_c/ex_access.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_access.c
echo FILE: analysis/examples_c/ex_apprec/ex_apprec.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_apprec/ex_apprec.c
echo FILE: analysis/examples_c/ex_apprec/ex_apprec.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_apprec/ex_apprec.h
echo FILE: analysis/examples_c/ex_apprec/ex_apprec_auto.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_apprec/ex_apprec_auto.c
echo FILE: analysis/examples_c/ex_apprec/ex_apprec_auto.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_apprec/ex_apprec_auto.h
echo FILE: analysis/examples_c/ex_apprec/ex_apprec_autop.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_apprec/ex_apprec_autop.c
echo FILE: analysis/examples_c/ex_apprec/ex_apprec_rec.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_apprec/ex_apprec_rec.c
echo FILE: analysis/examples_c/ex_btrec.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_btrec.c
echo FILE: analysis/examples_c/ex_dbclient.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_dbclient.c
echo FILE: analysis/examples_c/ex_env.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_env.c
echo FILE: analysis/examples_c/ex_lock.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_lock.c
echo FILE: analysis/examples_c/ex_mpool.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_mpool.c
echo FILE: analysis/examples_c/ex_rep/base/rep_base.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_rep/base/rep_base.c
echo FILE: analysis/examples_c/ex_rep/base/rep_base.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_rep/base/rep_base.h
echo FILE: analysis/examples_c/ex_rep/base/rep_msg.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_rep/base/rep_msg.c
echo FILE: analysis/examples_c/ex_rep/base/rep_net.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_rep/base/rep_net.c
echo FILE: analysis/examples_c/ex_rep/common/rep_common.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_rep/common/rep_common.c
echo FILE: analysis/examples_c/ex_rep/common/rep_common.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_rep/common/rep_common.h
echo FILE: analysis/examples_c/ex_rep/mgr/rep_mgr.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_rep/mgr/rep_mgr.c
echo FILE: analysis/examples_c/ex_sequence.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_sequence.c
echo FILE: analysis/examples_c/ex_thread.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_thread.c
echo FILE: analysis/examples_c/ex_tpcb.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/ex_tpcb.c
echo FILE: analysis/examples_c/getting_started/example_database_load.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/getting_started/example_database_load.c
echo FILE: analysis/examples_c/getting_started/example_database_read.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/getting_started/example_database_read.c
echo FILE: analysis/examples_c/getting_started/gettingstarted_common.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/getting_started/gettingstarted_common.c
echo FILE: analysis/examples_c/getting_started/gettingstarted_common.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/getting_started/gettingstarted_common.h
echo FILE: analysis/examples_c/txn_guide/txn_guide.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/txn_guide/txn_guide.c
echo FILE: analysis/examples_c/txn_guide/txn_guide_inmemory.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/examples_c/txn_guide/txn_guide_inmemory.c
echo FILE: analysis/fileops/fileops_auto.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/fileops/fileops_auto.c
echo FILE: analysis/fileops/fileops_autop.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/fileops/fileops_autop.c
echo FILE: analysis/fileops/fop_basic.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/fileops/fop_basic.c
echo FILE: analysis/fileops/fop_rec.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/fileops/fop_rec.c
echo FILE: analysis/fileops/fop_util.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/fileops/fop_util.c
echo FILE: analysis/hash/hash.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hash/hash.c
echo FILE: analysis/hash/hash_auto.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hash/hash_auto.c
echo FILE: analysis/hash/hash_autop.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hash/hash_autop.c
echo FILE: analysis/hash/hash_conv.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hash/hash_conv.c
echo FILE: analysis/hash/hash_dup.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hash/hash_dup.c
echo FILE: analysis/hash/hash_func.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hash/hash_func.c
echo FILE: analysis/hash/hash_meta.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hash/hash_meta.c
echo FILE: analysis/hash/hash_method.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hash/hash_method.c
echo FILE: analysis/hash/hash_open.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hash/hash_open.c
echo FILE: analysis/hash/hash_page.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hash/hash_page.c
echo FILE: analysis/hash/hash_rec.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hash/hash_rec.c
echo FILE: analysis/hash/hash_reclaim.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hash/hash_reclaim.c
echo FILE: analysis/hash/hash_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hash/hash_stat.c
echo FILE: analysis/hash/hash_stub.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hash/hash_stub.c
echo FILE: analysis/hash/hash_upgrade.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hash/hash_upgrade.c
echo FILE: analysis/hash/hash_verify.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hash/hash_verify.c
echo FILE: analysis/hmac/hmac.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hmac/hmac.c
echo FILE: analysis/hmac/sha1.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hmac/sha1.c
echo FILE: analysis/hsearch/hsearch.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/hsearch/hsearch.c
echo FILE: analysis/libdb_java/db_java_wrap.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libdb_java/db_java_wrap.c
echo FILE: analysis/libdb_java/java_stat_auto.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libdb_java/java_stat_auto.c
echo FILE: analysis/lock/lock.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lock/lock.c
echo FILE: analysis/lock/lock_deadlock.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lock/lock_deadlock.c
echo FILE: analysis/lock/lock_failchk.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lock/lock_failchk.c
echo FILE: analysis/lock/lock_id.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lock/lock_id.c
echo FILE: analysis/lock/lock_list.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lock/lock_list.c
echo FILE: analysis/lock/lock_method.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lock/lock_method.c
echo FILE: analysis/lock/lock_region.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lock/lock_region.c
echo FILE: analysis/lock/lock_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lock/lock_stat.c
echo FILE: analysis/lock/lock_stub.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lock/lock_stub.c
echo FILE: analysis/lock/lock_timer.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lock/lock_timer.c
echo FILE: analysis/lock/lock_util.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lock/lock_util.c
echo FILE: analysis/log/log.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/log/log.c
echo FILE: analysis/log/log_archive.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/log/log_archive.c
echo FILE: analysis/log/log_compare.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/log/log_compare.c
echo FILE: analysis/log/log_debug.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/log/log_debug.c
echo FILE: analysis/log/log_get.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/log/log_get.c
echo FILE: analysis/log/log_method.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/log/log_method.c
echo FILE: analysis/log/log_put.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/log/log_put.c
echo FILE: analysis/log/log_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/log/log_stat.c
echo FILE: analysis/mod_db4/mm_hash.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mod_db4/mm_hash.c
echo FILE: analysis/mod_db4/mm_hash.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mod_db4/mm_hash.h
echo FILE: analysis/mod_db4/mod_db4.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mod_db4/mod_db4.c
echo FILE: analysis/mod_db4/mod_db4_export.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mod_db4/mod_db4_export.h
echo FILE: analysis/mod_db4/sem_utils.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mod_db4/sem_utils.c
echo FILE: analysis/mod_db4/sem_utils.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mod_db4/sem_utils.h
echo FILE: analysis/mod_db4/skiplist.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mod_db4/skiplist.c
echo FILE: analysis/mod_db4/skiplist.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mod_db4/skiplist.h
echo FILE: analysis/mod_db4/utils.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mod_db4/utils.c
echo FILE: analysis/mod_db4/utils.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mod_db4/utils.h
echo FILE: analysis/mp/mp_alloc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mp/mp_alloc.c
echo FILE: analysis/mp/mp_bh.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mp/mp_bh.c
echo FILE: analysis/mp/mp_fget.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mp/mp_fget.c
echo FILE: analysis/mp/mp_fmethod.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mp/mp_fmethod.c
echo FILE: analysis/mp/mp_fopen.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mp/mp_fopen.c
echo FILE: analysis/mp/mp_fput.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mp/mp_fput.c
echo FILE: analysis/mp/mp_fset.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mp/mp_fset.c
echo FILE: analysis/mp/mp_method.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mp/mp_method.c
echo FILE: analysis/mp/mp_mvcc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mp/mp_mvcc.c
echo FILE: analysis/mp/mp_region.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mp/mp_region.c
echo FILE: analysis/mp/mp_register.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mp/mp_register.c
echo FILE: analysis/mp/mp_resize.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mp/mp_resize.c
echo FILE: analysis/mp/mp_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mp/mp_stat.c
echo FILE: analysis/mp/mp_sync.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mp/mp_sync.c
echo FILE: analysis/mp/mp_trickle.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mp/mp_trickle.c
echo FILE: analysis/mutex/mut_alloc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mutex/mut_alloc.c
echo FILE: analysis/mutex/mut_failchk.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mutex/mut_failchk.c
echo FILE: analysis/mutex/mut_fcntl.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mutex/mut_fcntl.c
echo FILE: analysis/mutex/mut_method.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mutex/mut_method.c
echo FILE: analysis/mutex/mut_pthread.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mutex/mut_pthread.c
echo FILE: analysis/mutex/mut_region.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mutex/mut_region.c
echo FILE: analysis/mutex/mut_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mutex/mut_stat.c
echo FILE: analysis/mutex/mut_stub.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mutex/mut_stub.c
echo FILE: analysis/mutex/mut_tas.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mutex/mut_tas.c
echo FILE: analysis/mutex/mut_win32.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mutex/mut_win32.c
echo FILE: analysis/mutex/test_mutex.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mutex/test_mutex.c
echo FILE: analysis/os/os_abort.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_abort.c
echo FILE: analysis/os/os_abs.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_abs.c
echo FILE: analysis/os/os_addrinfo.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_addrinfo.c
echo FILE: analysis/os/os_alloc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_alloc.c
echo FILE: analysis/os/os_clock.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_clock.c
echo FILE: analysis/os/os_config.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_config.c
echo FILE: analysis/os/os_cpu.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_cpu.c
echo FILE: analysis/os/os_ctime.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_ctime.c
echo FILE: analysis/os/os_dir.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_dir.c
echo FILE: analysis/os/os_errno.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_errno.c
echo FILE: analysis/os/os_fid.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_fid.c
echo FILE: analysis/os/os_flock.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_flock.c
echo FILE: analysis/os/os_fsync.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_fsync.c
echo FILE: analysis/os/os_getenv.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_getenv.c
echo FILE: analysis/os/os_handle.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_handle.c
echo FILE: analysis/os/os_map.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_map.c
echo FILE: analysis/os/os_mkdir.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_mkdir.c
echo FILE: analysis/os/os_open.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_open.c
echo FILE: analysis/os/os_pid.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_pid.c
echo FILE: analysis/os/os_rename.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_rename.c
echo FILE: analysis/os/os_root.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_root.c
echo FILE: analysis/os/os_rpath.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_rpath.c
echo FILE: analysis/os/os_rw.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_rw.c
echo FILE: analysis/os/os_seek.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_seek.c
echo FILE: analysis/os/os_stack.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_stack.c
echo FILE: analysis/os/os_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_stat.c
echo FILE: analysis/os/os_tmpdir.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_tmpdir.c
echo FILE: analysis/os/os_truncate.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_truncate.c
echo FILE: analysis/os/os_uid.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_uid.c
echo FILE: analysis/os/os_unlink.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_unlink.c
echo FILE: analysis/os/os_yield.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os/os_yield.c
echo FILE: analysis/os_brew/ctime.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/ctime.c
echo FILE: analysis/os_brew/fclose.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/fclose.c
echo FILE: analysis/os_brew/fgetc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/fgetc.c
echo FILE: analysis/os_brew/fgets.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/fgets.c
echo FILE: analysis/os_brew/fopen.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/fopen.c
echo FILE: analysis/os_brew/fwrite.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/fwrite.c
echo FILE: analysis/os_brew/getcwd.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/getcwd.c
echo FILE: analysis/os_brew/globals.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/globals.c
echo FILE: analysis/os_brew/localtime.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/localtime.c
echo FILE: analysis/os_brew/os_abort.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/os_abort.c
echo FILE: analysis/os_brew/os_abs.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/os_abs.c
echo FILE: analysis/os_brew/os_clock.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/os_clock.c
echo FILE: analysis/os_brew/os_config.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/os_config.c
echo FILE: analysis/os_brew/os_dir.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/os_dir.c
echo FILE: analysis/os_brew/os_errno.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/os_errno.c
echo FILE: analysis/os_brew/os_handle.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/os_handle.c
echo FILE: analysis/os_brew/os_mkdir.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/os_mkdir.c
echo FILE: analysis/os_brew/os_open.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/os_open.c
echo FILE: analysis/os_brew/os_pid.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/os_pid.c
echo FILE: analysis/os_brew/os_rename.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/os_rename.c
echo FILE: analysis/os_brew/os_rw.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/os_rw.c
echo FILE: analysis/os_brew/os_seek.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/os_seek.c
echo FILE: analysis/os_brew/os_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/os_stat.c
echo FILE: analysis/os_brew/os_truncate.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/os_truncate.c
echo FILE: analysis/os_brew/os_unlink.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/os_unlink.c
echo FILE: analysis/os_brew/os_yield.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_brew/os_yield.c
echo FILE: analysis/os_qnx/os_qnx_fsync.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_qnx/os_qnx_fsync.c
echo FILE: analysis/os_qnx/os_qnx_open.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_qnx/os_qnx_open.c
echo FILE: analysis/os_s60/os_config.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_s60/os_config.c
echo FILE: analysis/os_vxworks/os_vx_abs.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_vxworks/os_vx_abs.c
echo FILE: analysis/os_vxworks/os_vx_config.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_vxworks/os_vx_config.c
echo FILE: analysis/os_vxworks/os_vx_map.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_vxworks/os_vx_map.c
echo FILE: analysis/os_vxworks/os_vx_rpath.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_vxworks/os_vx_rpath.c
echo FILE: analysis/os_vxworks/os_vx_yield.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_vxworks/os_vx_yield.c
echo FILE: analysis/os_windows/ce_ctime.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/ce_ctime.c
echo FILE: analysis/os_windows/os_abs.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_abs.c
echo FILE: analysis/os_windows/os_clock.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_clock.c
echo FILE: analysis/os_windows/os_config.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_config.c
echo FILE: analysis/os_windows/os_cpu.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_cpu.c
echo FILE: analysis/os_windows/os_dir.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_dir.c
echo FILE: analysis/os_windows/os_errno.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_errno.c
echo FILE: analysis/os_windows/os_fid.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_fid.c
echo FILE: analysis/os_windows/os_flock.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_flock.c
echo FILE: analysis/os_windows/os_fsync.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_fsync.c
echo FILE: analysis/os_windows/os_getenv.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_getenv.c
echo FILE: analysis/os_windows/os_handle.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_handle.c
echo FILE: analysis/os_windows/os_map.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_map.c
echo FILE: analysis/os_windows/os_mkdir.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_mkdir.c
echo FILE: analysis/os_windows/os_open.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_open.c
echo FILE: analysis/os_windows/os_rename.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_rename.c
echo FILE: analysis/os_windows/os_rw.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_rw.c
echo FILE: analysis/os_windows/os_seek.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_seek.c
echo FILE: analysis/os_windows/os_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_stat.c
echo FILE: analysis/os_windows/os_truncate.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_truncate.c
echo FILE: analysis/os_windows/os_unlink.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_unlink.c
echo FILE: analysis/os_windows/os_yield.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/os_windows/os_yield.c
echo FILE: analysis/perl/BerkeleyDB/constants.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/perl/BerkeleyDB/constants.h
echo FILE: analysis/perl/BerkeleyDB/ppport.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/perl/BerkeleyDB/ppport.h
echo FILE: analysis/perl/DB_File/fallback.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/perl/DB_File/fallback.h
echo FILE: analysis/perl/DB_File/ppport.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/perl/DB_File/ppport.h
echo FILE: analysis/perl/DB_File/version.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/perl/DB_File/version.c
echo FILE: analysis/php_db4/php_db4.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/php_db4/php_db4.h
echo FILE: analysis/qam/qam.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/qam/qam.c
echo FILE: analysis/qam/qam_auto.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/qam/qam_auto.c
echo FILE: analysis/qam/qam_autop.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/qam/qam_autop.c
echo FILE: analysis/qam/qam_conv.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/qam/qam_conv.c
echo FILE: analysis/qam/qam_files.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/qam/qam_files.c
echo FILE: analysis/qam/qam_method.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/qam/qam_method.c
echo FILE: analysis/qam/qam_open.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/qam/qam_open.c
echo FILE: analysis/qam/qam_rec.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/qam/qam_rec.c
echo FILE: analysis/qam/qam_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/qam/qam_stat.c
echo FILE: analysis/qam/qam_stub.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/qam/qam_stub.c
echo FILE: analysis/qam/qam_upgrade.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/qam/qam_upgrade.c
echo FILE: analysis/qam/qam_verify.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/qam/qam_verify.c
echo FILE: analysis/rep/rep_auto.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rep/rep_auto.c
echo FILE: analysis/rep/rep_backup.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rep/rep_backup.c
echo FILE: analysis/rep/rep_elect.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rep/rep_elect.c
echo FILE: analysis/rep/rep_lease.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rep/rep_lease.c
echo FILE: analysis/rep/rep_log.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rep/rep_log.c
echo FILE: analysis/rep/rep_method.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rep/rep_method.c
echo FILE: analysis/rep/rep_record.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rep/rep_record.c
echo FILE: analysis/rep/rep_region.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rep/rep_region.c
echo FILE: analysis/rep/rep_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rep/rep_stat.c
echo FILE: analysis/rep/rep_stub.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rep/rep_stub.c
echo FILE: analysis/rep/rep_util.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rep/rep_util.c
echo FILE: analysis/rep/rep_verify.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rep/rep_verify.c
echo FILE: analysis/repmgr/repmgr_auto.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/repmgr/repmgr_auto.c
echo FILE: analysis/repmgr/repmgr_elect.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/repmgr/repmgr_elect.c
echo FILE: analysis/repmgr/repmgr_method.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/repmgr/repmgr_method.c
echo FILE: analysis/repmgr/repmgr_msg.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/repmgr/repmgr_msg.c
echo FILE: analysis/repmgr/repmgr_net.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/repmgr/repmgr_net.c
echo FILE: analysis/repmgr/repmgr_posix.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/repmgr/repmgr_posix.c
echo FILE: analysis/repmgr/repmgr_queue.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/repmgr/repmgr_queue.c
echo FILE: analysis/repmgr/repmgr_sel.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/repmgr/repmgr_sel.c
echo FILE: analysis/repmgr/repmgr_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/repmgr/repmgr_stat.c
echo FILE: analysis/repmgr/repmgr_stub.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/repmgr/repmgr_stub.c
echo FILE: analysis/repmgr/repmgr_util.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/repmgr/repmgr_util.c
echo FILE: analysis/repmgr/repmgr_windows.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/repmgr/repmgr_windows.c
echo FILE: analysis/rpc_client/client.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rpc_client/client.c
echo FILE: analysis/rpc_client/gen_client.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rpc_client/gen_client.c
echo FILE: analysis/rpc_client/gen_client_ret.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rpc_client/gen_client_ret.c
echo FILE: analysis/rpc_server/c/db_server_proc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rpc_server/c/db_server_proc.c
echo FILE: analysis/rpc_server/c/db_server_util.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rpc_server/c/db_server_util.c
echo FILE: analysis/rpc_server/c/gen_db_server.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rpc_server/c/gen_db_server.c
echo FILE: analysis/sequence/seq_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sequence/seq_stat.c
echo FILE: analysis/sequence/sequence.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sequence/sequence.c
echo FILE: analysis/tcl/tcl_compat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/tcl/tcl_compat.c
echo FILE: analysis/tcl/tcl_db.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/tcl/tcl_db.c
echo FILE: analysis/tcl/tcl_db_pkg.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/tcl/tcl_db_pkg.c
echo FILE: analysis/tcl/tcl_dbcursor.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/tcl/tcl_dbcursor.c
echo FILE: analysis/tcl/tcl_env.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/tcl/tcl_env.c
echo FILE: analysis/tcl/tcl_internal.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/tcl/tcl_internal.c
echo FILE: analysis/tcl/tcl_lock.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/tcl/tcl_lock.c
echo FILE: analysis/tcl/tcl_log.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/tcl/tcl_log.c
echo FILE: analysis/tcl/tcl_mp.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/tcl/tcl_mp.c
echo FILE: analysis/tcl/tcl_rep.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/tcl/tcl_rep.c
echo FILE: analysis/tcl/tcl_seq.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/tcl/tcl_seq.c
echo FILE: analysis/tcl/tcl_txn.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/tcl/tcl_txn.c
echo FILE: analysis/tcl/tcl_util.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/tcl/tcl_util.c
echo FILE: analysis/test/scr017/t.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/scr017/t.c
echo FILE: analysis/test/scr018/t.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/scr018/t.c
echo FILE: analysis/test/scr021/t.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/scr021/t.c
echo FILE: analysis/test/scr023/q.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/scr023/q.c
echo FILE: analysis/test/scr028/t.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/scr028/t.c
echo FILE: analysis/test/scr029/t.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/scr029/t.c
echo FILE: analysis/test/scr031/src/client.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/scr031/src/client.c
echo FILE: analysis/test/scr031/src/datafml.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/scr031/src/datafml.h
echo FILE: analysis/test/scr031/src/hcommonxa.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/scr031/src/hcommonxa.h
echo FILE: analysis/test/scr031/src/hdbrec.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/scr031/src/hdbrec.h
echo FILE: analysis/test/scr031/src/htimestampxa.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/scr031/src/htimestampxa.c
echo FILE: analysis/test/scr031/src/htimestampxa.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/scr031/src/htimestampxa.h
echo FILE: analysis/test/scr031/src/server.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/scr031/src/server.c
echo FILE: analysis/test_micro/source/b_curalloc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test_micro/source/b_curalloc.c
echo FILE: analysis/test_micro/source/b_curwalk.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test_micro/source/b_curwalk.c
echo FILE: analysis/test_micro/source/b_del.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test_micro/source/b_del.c
echo FILE: analysis/test_micro/source/b_get.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test_micro/source/b_get.c
echo FILE: analysis/test_micro/source/b_inmem.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test_micro/source/b_inmem.c
echo FILE: analysis/test_micro/source/b_load.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test_micro/source/b_load.c
echo FILE: analysis/test_micro/source/b_open.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test_micro/source/b_open.c
echo FILE: analysis/test_micro/source/b_put.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test_micro/source/b_put.c
echo FILE: analysis/test_micro/source/b_recover.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test_micro/source/b_recover.c
echo FILE: analysis/test_micro/source/b_txn.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test_micro/source/b_txn.c
echo FILE: analysis/test_micro/source/b_txn_write.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test_micro/source/b_txn_write.c
echo FILE: analysis/test_micro/source/b_uname.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test_micro/source/b_uname.c
echo FILE: analysis/test_micro/source/b_util.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test_micro/source/b_util.c
echo FILE: analysis/test_micro/source/b_workload.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test_micro/source/b_workload.c
echo FILE: analysis/test_micro/source/b_workload.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test_micro/source/b_workload.h
echo FILE: analysis/test_micro/source/bench.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test_micro/source/bench.h
echo FILE: analysis/test_micro/source/test_micro.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test_micro/source/test_micro.c
echo FILE: analysis/txn/txn.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/txn/txn.c
echo FILE: analysis/txn/txn_auto.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/txn/txn_auto.c
echo FILE: analysis/txn/txn_autop.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/txn/txn_autop.c
echo FILE: analysis/txn/txn_chkpt.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/txn/txn_chkpt.c
echo FILE: analysis/txn/txn_failchk.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/txn/txn_failchk.c
echo FILE: analysis/txn/txn_method.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/txn/txn_method.c
echo FILE: analysis/txn/txn_rec.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/txn/txn_rec.c
echo FILE: analysis/txn/txn_recover.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/txn/txn_recover.c
echo FILE: analysis/txn/txn_region.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/txn/txn_region.c
echo FILE: analysis/txn/txn_stat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/txn/txn_stat.c
echo FILE: analysis/txn/txn_util.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/txn/txn_util.c
echo FILE: analysis/xa/xa.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/xa/xa.c
echo FILE: analysis/xa/xa_db.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/xa/xa_db.c
echo FILE: analysis/xa/xa_map.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/xa/xa_map.c
echo FILE: analysis/xa/xa_stub.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/xa/xa_stub.c
