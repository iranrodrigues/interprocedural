#include <stubs.h>
#define TK_AND                             1
#define TK_OR                              2
#define TK_EQ                              3
#define TK_NE                              4
#define TK_GT                              5
#define TK_GE                              6
#define TK_LT                              7
#define TK_LE                              8
#define TK_NOT                             9
#define TK_LPARAN                         10
#define TK_RPARAN                         11
#define TK_VALUE                          12
