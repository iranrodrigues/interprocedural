echo FILE: analysis/contrib/bitdomain.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/contrib/bitdomain.c
echo FILE: analysis/editmap/editmap.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/editmap/editmap.c
echo FILE: analysis/include/libmilter/mfapi.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/libmilter/mfapi.h
echo FILE: analysis/include/libmilter/mfdef.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/libmilter/mfdef.h
echo FILE: analysis/include/libmilter/milter.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/libmilter/milter.h
echo FILE: analysis/include/libsmdb/smdb.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/libsmdb/smdb.h
echo FILE: analysis/include/sendmail/mailstats.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sendmail/mailstats.h
echo FILE: analysis/include/sendmail/pathnames.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sendmail/pathnames.h
echo FILE: analysis/include/sendmail/sendmail.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sendmail/sendmail.h
echo FILE: analysis/include/sm/assert.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/assert.h
echo FILE: analysis/include/sm/bdb.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/bdb.h
echo FILE: analysis/include/sm/bitops.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/bitops.h
echo FILE: analysis/include/sm/cdefs.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/cdefs.h
echo FILE: analysis/include/sm/cf.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/cf.h
echo FILE: analysis/include/sm/clock.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/clock.h
echo FILE: analysis/include/sm/conf.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/conf.h
echo FILE: analysis/include/sm/config.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/config.h
echo FILE: analysis/include/sm/debug.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/debug.h
echo FILE: analysis/include/sm/errstring.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/errstring.h
echo FILE: analysis/include/sm/exc.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/exc.h
echo FILE: analysis/include/sm/fdset.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/fdset.h
echo FILE: analysis/include/sm/gen.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/gen.h
echo FILE: analysis/include/sm/heap.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/heap.h
echo FILE: analysis/include/sm/io.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/io.h
echo FILE: analysis/include/sm/ldap.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/ldap.h
echo FILE: analysis/include/sm/limits.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/limits.h
echo FILE: analysis/include/sm/mbdb.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/mbdb.h
echo FILE: analysis/include/sm/misc.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/misc.h
echo FILE: analysis/include/sm/os/sm_os_aix.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_aix.h
echo FILE: analysis/include/sm/os/sm_os_dragonfly.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_dragonfly.h
echo FILE: analysis/include/sm/os/sm_os_freebsd.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_freebsd.h
echo FILE: analysis/include/sm/os/sm_os_hp.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_hp.h
echo FILE: analysis/include/sm/os/sm_os_irix.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_irix.h
echo FILE: analysis/include/sm/os/sm_os_linux.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_linux.h
echo FILE: analysis/include/sm/os/sm_os_mpeix.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_mpeix.h
echo FILE: analysis/include/sm/os/sm_os_next.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_next.h
echo FILE: analysis/include/sm/os/sm_os_openbsd.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_openbsd.h
echo FILE: analysis/include/sm/os/sm_os_openunix.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_openunix.h
echo FILE: analysis/include/sm/os/sm_os_osf1.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_osf1.h
echo FILE: analysis/include/sm/os/sm_os_qnx.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_qnx.h
echo FILE: analysis/include/sm/os/sm_os_sunos.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_sunos.h
echo FILE: analysis/include/sm/os/sm_os_ultrix.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_ultrix.h
echo FILE: analysis/include/sm/os/sm_os_unicos.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_unicos.h
echo FILE: analysis/include/sm/os/sm_os_unicosmk.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_unicosmk.h
echo FILE: analysis/include/sm/os/sm_os_unicosmp.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_unicosmp.h
echo FILE: analysis/include/sm/os/sm_os_unixware.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/os/sm_os_unixware.h
echo FILE: analysis/include/sm/path.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/path.h
echo FILE: analysis/include/sm/rpool.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/rpool.h
echo FILE: analysis/include/sm/sem.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/sem.h
echo FILE: analysis/include/sm/sendmail.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/sendmail.h
echo FILE: analysis/include/sm/setjmp.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/setjmp.h
echo FILE: analysis/include/sm/shm.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/shm.h
echo FILE: analysis/include/sm/signal.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/signal.h
echo FILE: analysis/include/sm/string.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/string.h
echo FILE: analysis/include/sm/sysexits.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/sysexits.h
echo FILE: analysis/include/sm/tailq.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/tailq.h
echo FILE: analysis/include/sm/test.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/test.h
echo FILE: analysis/include/sm/time.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/time.h
echo FILE: analysis/include/sm/types.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/types.h
echo FILE: analysis/include/sm/varargs.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/varargs.h
echo FILE: analysis/include/sm/xtrap.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/include/sm/xtrap.h
echo FILE: analysis/libmilter/comm.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libmilter/comm.c
echo FILE: analysis/libmilter/engine.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libmilter/engine.c
echo FILE: analysis/libmilter/example.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libmilter/example.c
echo FILE: analysis/libmilter/handler.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libmilter/handler.c
echo FILE: analysis/libmilter/libmilter.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libmilter/libmilter.h
echo FILE: analysis/libmilter/listener.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libmilter/listener.c
echo FILE: analysis/libmilter/main.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libmilter/main.c
echo FILE: analysis/libmilter/monitor.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libmilter/monitor.c
echo FILE: analysis/libmilter/signal.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libmilter/signal.c
echo FILE: analysis/libmilter/sm_gethost.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libmilter/sm_gethost.c
echo FILE: analysis/libmilter/smfi.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libmilter/smfi.c
echo FILE: analysis/libmilter/worker.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libmilter/worker.c
echo FILE: analysis/libsm/assert.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/assert.c
echo FILE: analysis/libsm/b-strcmp.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/b-strcmp.c
echo FILE: analysis/libsm/b-strl.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/b-strl.c
echo FILE: analysis/libsm/cf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/cf.c
echo FILE: analysis/libsm/clock.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/clock.c
echo FILE: analysis/libsm/clrerr.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/clrerr.c
echo FILE: analysis/libsm/config.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/config.c
echo FILE: analysis/libsm/debug.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/debug.c
echo FILE: analysis/libsm/errstring.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/errstring.c
echo FILE: analysis/libsm/exc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/exc.c
echo FILE: analysis/libsm/fclose.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/fclose.c
echo FILE: analysis/libsm/feof.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/feof.c
echo FILE: analysis/libsm/ferror.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/ferror.c
echo FILE: analysis/libsm/fflush.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/fflush.c
echo FILE: analysis/libsm/fget.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/fget.c
echo FILE: analysis/libsm/findfp.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/findfp.c
echo FILE: analysis/libsm/flags.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/flags.c
echo FILE: analysis/libsm/fopen.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/fopen.c
echo FILE: analysis/libsm/fpos.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/fpos.c
echo FILE: analysis/libsm/fprintf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/fprintf.c
echo FILE: analysis/libsm/fpurge.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/fpurge.c
echo FILE: analysis/libsm/fput.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/fput.c
echo FILE: analysis/libsm/fread.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/fread.c
echo FILE: analysis/libsm/fscanf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/fscanf.c
echo FILE: analysis/libsm/fseek.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/fseek.c
echo FILE: analysis/libsm/fvwrite.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/fvwrite.c
echo FILE: analysis/libsm/fvwrite.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/fvwrite.h
echo FILE: analysis/libsm/fwalk.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/fwalk.c
echo FILE: analysis/libsm/fwrite.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/fwrite.c
echo FILE: analysis/libsm/get.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/get.c
echo FILE: analysis/libsm/glue.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/glue.h
echo FILE: analysis/libsm/heap.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/heap.c
echo FILE: analysis/libsm/ldap.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/ldap.c
echo FILE: analysis/libsm/local.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/local.h
echo FILE: analysis/libsm/makebuf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/makebuf.c
echo FILE: analysis/libsm/match.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/match.c
echo FILE: analysis/libsm/mbdb.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/mbdb.c
echo FILE: analysis/libsm/memstat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/memstat.c
echo FILE: analysis/libsm/mpeix.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/mpeix.c
echo FILE: analysis/libsm/niprop.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/niprop.c
echo FILE: analysis/libsm/path.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/path.c
echo FILE: analysis/libsm/put.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/put.c
echo FILE: analysis/libsm/refill.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/refill.c
echo FILE: analysis/libsm/rewind.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/rewind.c
echo FILE: analysis/libsm/rpool.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/rpool.c
echo FILE: analysis/libsm/sem.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/sem.c
echo FILE: analysis/libsm/setvbuf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/setvbuf.c
echo FILE: analysis/libsm/shm.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/shm.c
echo FILE: analysis/libsm/signal.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/signal.c
echo FILE: analysis/libsm/smstdio.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/smstdio.c
echo FILE: analysis/libsm/snprintf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/snprintf.c
echo FILE: analysis/libsm/sscanf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/sscanf.c
echo FILE: analysis/libsm/stdio.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/stdio.c
echo FILE: analysis/libsm/strcasecmp.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/strcasecmp.c
echo FILE: analysis/libsm/strdup.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/strdup.c
echo FILE: analysis/libsm/strerror.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/strerror.c
echo FILE: analysis/libsm/strexit.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/strexit.c
echo FILE: analysis/libsm/string.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/string.c
echo FILE: analysis/libsm/stringf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/stringf.c
echo FILE: analysis/libsm/strio.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/strio.c
echo FILE: analysis/libsm/strl.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/strl.c
echo FILE: analysis/libsm/strrevcmp.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/strrevcmp.c
echo FILE: analysis/libsm/strto.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/strto.c
echo FILE: analysis/libsm/syslogio.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/syslogio.c
echo FILE: analysis/libsm/t-cf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-cf.c
echo FILE: analysis/libsm/t-event.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-event.c
echo FILE: analysis/libsm/t-exc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-exc.c
echo FILE: analysis/libsm/t-float.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-float.c
echo FILE: analysis/libsm/t-fopen.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-fopen.c
echo FILE: analysis/libsm/t-heap.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-heap.c
echo FILE: analysis/libsm/t-match.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-match.c
echo FILE: analysis/libsm/t-memstat.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-memstat.c
echo FILE: analysis/libsm/t-path.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-path.c
echo FILE: analysis/libsm/t-qic.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-qic.c
echo FILE: analysis/libsm/t-rpool.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-rpool.c
echo FILE: analysis/libsm/t-scanf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-scanf.c
echo FILE: analysis/libsm/t-sem.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-sem.c
echo FILE: analysis/libsm/t-shm.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-shm.c
echo FILE: analysis/libsm/t-smstdio.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-smstdio.c
echo FILE: analysis/libsm/t-string.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-string.c
echo FILE: analysis/libsm/t-strio.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-strio.c
echo FILE: analysis/libsm/t-strl.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-strl.c
echo FILE: analysis/libsm/t-strrevcmp.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-strrevcmp.c
echo FILE: analysis/libsm/t-types.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/t-types.c
echo FILE: analysis/libsm/test.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/test.c
echo FILE: analysis/libsm/ungetc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/ungetc.c
echo FILE: analysis/libsm/util.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/util.c
echo FILE: analysis/libsm/vasprintf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/vasprintf.c
echo FILE: analysis/libsm/vfprintf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/vfprintf.c
echo FILE: analysis/libsm/vfscanf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/vfscanf.c
echo FILE: analysis/libsm/vprintf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/vprintf.c
echo FILE: analysis/libsm/vsnprintf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/vsnprintf.c
echo FILE: analysis/libsm/wbuf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/wbuf.c
echo FILE: analysis/libsm/wsetup.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/wsetup.c
echo FILE: analysis/libsm/xtrap.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsm/xtrap.c
echo FILE: analysis/libsmdb/smdb.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsmdb/smdb.c
echo FILE: analysis/libsmdb/smdb1.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsmdb/smdb1.c
echo FILE: analysis/libsmdb/smdb2.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsmdb/smdb2.c
echo FILE: analysis/libsmdb/smndbm.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsmdb/smndbm.c
echo FILE: analysis/libsmutil/cf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsmutil/cf.c
echo FILE: analysis/libsmutil/debug.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsmutil/debug.c
echo FILE: analysis/libsmutil/err.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsmutil/err.c
echo FILE: analysis/libsmutil/lockfile.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsmutil/lockfile.c
echo FILE: analysis/libsmutil/safefile.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsmutil/safefile.c
echo FILE: analysis/libsmutil/snprintf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/libsmutil/snprintf.c
echo FILE: analysis/mail.local/mail.local.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mail.local/mail.local.c
echo FILE: analysis/mailstats/mailstats.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/mailstats/mailstats.c
echo FILE: analysis/makemap/makemap.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/makemap/makemap.c
echo FILE: analysis/praliases/praliases.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/praliases/praliases.c
echo FILE: analysis/rmail/rmail.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/rmail/rmail.c
echo FILE: analysis/sendmail/alias.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/alias.c
echo FILE: analysis/sendmail/arpadate.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/arpadate.c
echo FILE: analysis/sendmail/bf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/bf.c
echo FILE: analysis/sendmail/bf.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/bf.h
echo FILE: analysis/sendmail/collect.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/collect.c
echo FILE: analysis/sendmail/conf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/conf.c
echo FILE: analysis/sendmail/conf.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/conf.h
echo FILE: analysis/sendmail/control.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/control.c
echo FILE: analysis/sendmail/convtime.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/convtime.c
echo FILE: analysis/sendmail/daemon.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/daemon.c
echo FILE: analysis/sendmail/daemon.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/daemon.h
echo FILE: analysis/sendmail/deliver.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/deliver.c
echo FILE: analysis/sendmail/domain.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/domain.c
echo FILE: analysis/sendmail/envelope.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/envelope.c
echo FILE: analysis/sendmail/err.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/err.c
echo FILE: analysis/sendmail/headers.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/headers.c
echo FILE: analysis/sendmail/macro.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/macro.c
echo FILE: analysis/sendmail/main.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/main.c
echo FILE: analysis/sendmail/map.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/map.c
echo FILE: analysis/sendmail/map.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/map.h
echo FILE: analysis/sendmail/mci.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/mci.c
echo FILE: analysis/sendmail/milter.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/milter.c
echo FILE: analysis/sendmail/mime.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/mime.c
echo FILE: analysis/sendmail/parseaddr.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/parseaddr.c
echo FILE: analysis/sendmail/queue.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/queue.c
echo FILE: analysis/sendmail/ratectrl.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/ratectrl.c
echo FILE: analysis/sendmail/readcf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/readcf.c
echo FILE: analysis/sendmail/recipient.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/recipient.c
echo FILE: analysis/sendmail/sasl.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/sasl.c
echo FILE: analysis/sendmail/savemail.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/savemail.c
echo FILE: analysis/sendmail/sendmail.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/sendmail.h
echo FILE: analysis/sendmail/sfsasl.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/sfsasl.c
echo FILE: analysis/sendmail/sfsasl.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/sfsasl.h
echo FILE: analysis/sendmail/shmticklib.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/shmticklib.c
echo FILE: analysis/sendmail/sm_resolve.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/sm_resolve.c
echo FILE: analysis/sendmail/sm_resolve.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/sm_resolve.h
echo FILE: analysis/sendmail/srvrsmtp.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/srvrsmtp.c
echo FILE: analysis/sendmail/stab.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/stab.c
echo FILE: analysis/sendmail/stats.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/stats.c
echo FILE: analysis/sendmail/statusd_shm.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/statusd_shm.h
echo FILE: analysis/sendmail/sysexits.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/sysexits.c
echo FILE: analysis/sendmail/sysexits.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/sysexits.h
echo FILE: analysis/sendmail/timers.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/timers.c
echo FILE: analysis/sendmail/timers.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/timers.h
echo FILE: analysis/sendmail/tls.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/tls.c
echo FILE: analysis/sendmail/trace.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/trace.c
echo FILE: analysis/sendmail/udb.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/udb.c
echo FILE: analysis/sendmail/usersmtp.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/usersmtp.c
echo FILE: analysis/sendmail/util.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/util.c
echo FILE: analysis/sendmail/version.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/sendmail/version.c
echo FILE: analysis/smrsh/smrsh.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/smrsh/smrsh.c
echo FILE: analysis/test/t_dropgid.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/t_dropgid.c
echo FILE: analysis/test/t_exclopen.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/t_exclopen.c
echo FILE: analysis/test/t_pathconf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/t_pathconf.c
echo FILE: analysis/test/t_seteuid.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/t_seteuid.c
echo FILE: analysis/test/t_setgid.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/t_setgid.c
echo FILE: analysis/test/t_setreuid.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/t_setreuid.c
echo FILE: analysis/test/t_setuid.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/t_setuid.c
echo FILE: analysis/test/t_snprintf.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/test/t_snprintf.c
echo FILE: analysis/vacation/vacation.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/vacation/vacation.c
