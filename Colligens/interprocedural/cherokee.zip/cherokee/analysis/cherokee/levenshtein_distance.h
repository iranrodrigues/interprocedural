#include <stubs.h>
#ifndef __levenshtein_distance_h__
#define __levenshtein_distance_h__

//#include "common.h"

int distance (char *A, char *B);

#endif /* __levenshtein_distance_h__ */

