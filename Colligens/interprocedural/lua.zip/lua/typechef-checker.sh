echo FILE: analysis/src/lapi.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lapi.c
echo FILE: analysis/src/lapi.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lapi.h
echo FILE: analysis/src/lauxlib.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lauxlib.c
echo FILE: analysis/src/lauxlib.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lauxlib.h
echo FILE: analysis/src/lbaselib.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lbaselib.c
echo FILE: analysis/src/lbitlib.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lbitlib.c
echo FILE: analysis/src/lcode.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lcode.c
echo FILE: analysis/src/lcode.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lcode.h
echo FILE: analysis/src/lcorolib.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lcorolib.c
echo FILE: analysis/src/lctype.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lctype.c
echo FILE: analysis/src/lctype.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lctype.h
echo FILE: analysis/src/ldblib.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/ldblib.c
echo FILE: analysis/src/ldebug.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/ldebug.c
echo FILE: analysis/src/ldebug.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/ldebug.h
echo FILE: analysis/src/ldo.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/ldo.c
echo FILE: analysis/src/ldo.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/ldo.h
echo FILE: analysis/src/ldump.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/ldump.c
echo FILE: analysis/src/lfunc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lfunc.c
echo FILE: analysis/src/lfunc.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lfunc.h
echo FILE: analysis/src/lgc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lgc.c
echo FILE: analysis/src/lgc.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lgc.h
echo FILE: analysis/src/linit.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/linit.c
echo FILE: analysis/src/liolib.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/liolib.c
echo FILE: analysis/src/llex.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/llex.c
echo FILE: analysis/src/llex.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/llex.h
echo FILE: analysis/src/llimits.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/llimits.h
echo FILE: analysis/src/lmathlib.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lmathlib.c
echo FILE: analysis/src/lmem.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lmem.c
echo FILE: analysis/src/lmem.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lmem.h
echo FILE: analysis/src/loadlib.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/loadlib.c
echo FILE: analysis/src/lobject.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lobject.c
echo FILE: analysis/src/lobject.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lobject.h
echo FILE: analysis/src/lopcodes.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lopcodes.c
echo FILE: analysis/src/lopcodes.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lopcodes.h
echo FILE: analysis/src/loslib.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/loslib.c
echo FILE: analysis/src/lparser.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lparser.c
echo FILE: analysis/src/lparser.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lparser.h
echo FILE: analysis/src/lstate.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lstate.c
echo FILE: analysis/src/lstate.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lstate.h
echo FILE: analysis/src/lstring.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lstring.c
echo FILE: analysis/src/lstring.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lstring.h
echo FILE: analysis/src/lstrlib.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lstrlib.c
echo FILE: analysis/src/ltable.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/ltable.c
echo FILE: analysis/src/ltable.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/ltable.h
echo FILE: analysis/src/ltablib.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/ltablib.c
echo FILE: analysis/src/ltm.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/ltm.c
echo FILE: analysis/src/ltm.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/ltm.h
echo FILE: analysis/src/lua.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lua.c
echo FILE: analysis/src/lua.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lua.h
echo FILE: analysis/src/luac.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/luac.c
echo FILE: analysis/src/luaconf.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/luaconf.h
echo FILE: analysis/src/lualib.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lualib.h
echo FILE: analysis/src/lundump.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lundump.c
echo FILE: analysis/src/lundump.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lundump.h
echo FILE: analysis/src/lvm.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lvm.c
echo FILE: analysis/src/lvm.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lvm.h
echo FILE: analysis/src/lzio.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lzio.c
echo FILE: analysis/src/lzio.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lzio.h
