echo FILE: analysis/data/glr.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/data/glr.c
echo FILE: analysis/data/yacc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/data/yacc.c
echo FILE: analysis/lib/abitset.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/abitset.c
echo FILE: analysis/lib/abitset.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/abitset.h
echo FILE: analysis/lib/alloca.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/alloca.c
echo FILE: analysis/lib/alloca_.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/alloca_.h
echo FILE: analysis/lib/argmatch.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/argmatch.c
echo FILE: analysis/lib/argmatch.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/argmatch.h
echo FILE: analysis/lib/basename.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/basename.c
echo FILE: analysis/lib/bbitset.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/bbitset.h
echo FILE: analysis/lib/bitset.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/bitset.c
echo FILE: analysis/lib/bitset.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/bitset.h
echo FILE: analysis/lib/bitset_stats.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/bitset_stats.c
echo FILE: analysis/lib/bitset_stats.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/bitset_stats.h
echo FILE: analysis/lib/bitsetv-print.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/bitsetv-print.c
echo FILE: analysis/lib/bitsetv-print.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/bitsetv-print.h
echo FILE: analysis/lib/bitsetv.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/bitsetv.c
echo FILE: analysis/lib/bitsetv.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/bitsetv.h
echo FILE: analysis/lib/dirname.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/dirname.c
echo FILE: analysis/lib/dirname.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/dirname.h
echo FILE: analysis/lib/ebitset.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/ebitset.c
echo FILE: analysis/lib/ebitset.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/ebitset.h
echo FILE: analysis/lib/error.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/error.c
echo FILE: analysis/lib/error.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/error.h
echo FILE: analysis/lib/exit.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/exit.h
echo FILE: analysis/lib/exitfail.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/exitfail.c
echo FILE: analysis/lib/exitfail.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/exitfail.h
echo FILE: analysis/lib/get-errno.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/get-errno.c
echo FILE: analysis/lib/get-errno.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/get-errno.h
echo FILE: analysis/lib/getopt.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/getopt.c
echo FILE: analysis/lib/getopt1.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/getopt1.c
echo FILE: analysis/lib/getopt_.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/getopt_.h
echo FILE: analysis/lib/getopt_int.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/getopt_int.h
echo FILE: analysis/lib/gettext.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/gettext.h
echo FILE: analysis/lib/hard-locale.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/hard-locale.c
echo FILE: analysis/lib/hard-locale.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/hard-locale.h
echo FILE: analysis/lib/hash.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/hash.c
echo FILE: analysis/lib/hash.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/hash.h
echo FILE: analysis/lib/lbitset.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/lbitset.c
echo FILE: analysis/lib/lbitset.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/lbitset.h
echo FILE: analysis/lib/libiberty.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/libiberty.h
echo FILE: analysis/lib/main.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/main.c
echo FILE: analysis/lib/malloc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/malloc.c
echo FILE: analysis/lib/mbswidth.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/mbswidth.c
echo FILE: analysis/lib/mbswidth.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/mbswidth.h
echo FILE: analysis/lib/obstack.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/obstack.c
echo FILE: analysis/lib/obstack.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/obstack.h
echo FILE: analysis/lib/quote.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/quote.c
echo FILE: analysis/lib/quote.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/quote.h
echo FILE: analysis/lib/quotearg.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/quotearg.c
echo FILE: analysis/lib/quotearg.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/quotearg.h
echo FILE: analysis/lib/stdbool_.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/stdbool_.h
echo FILE: analysis/lib/stpcpy.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/stpcpy.c
echo FILE: analysis/lib/stpcpy.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/stpcpy.h
echo FILE: analysis/lib/strdup.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/strdup.c
echo FILE: analysis/lib/strdup.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/strdup.h
echo FILE: analysis/lib/stripslash.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/stripslash.c
echo FILE: analysis/lib/strndup.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/strndup.c
echo FILE: analysis/lib/strndup.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/strndup.h
echo FILE: analysis/lib/strnlen.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/strnlen.c
echo FILE: analysis/lib/subpipe.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/subpipe.c
echo FILE: analysis/lib/subpipe.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/subpipe.h
echo FILE: analysis/lib/timevar.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/timevar.c
echo FILE: analysis/lib/timevar.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/timevar.h
echo FILE: analysis/lib/vbitset.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/vbitset.c
echo FILE: analysis/lib/vbitset.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/vbitset.h
echo FILE: analysis/lib/xalloc-die.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/xalloc-die.c
echo FILE: analysis/lib/xalloc.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/xalloc.h
echo FILE: analysis/lib/xmalloc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/xmalloc.c
echo FILE: analysis/lib/xstrndup.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/xstrndup.c
echo FILE: analysis/lib/xstrndup.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/xstrndup.h
echo FILE: analysis/lib/yyerror.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/lib/yyerror.c
echo FILE: analysis/src/assoc.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/assoc.c
echo FILE: analysis/src/assoc.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/assoc.h
echo FILE: analysis/src/closure.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/closure.c
echo FILE: analysis/src/closure.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/closure.h
echo FILE: analysis/src/complain.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/complain.c
echo FILE: analysis/src/complain.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/complain.h
echo FILE: analysis/src/conflicts.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/conflicts.c
echo FILE: analysis/src/conflicts.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/conflicts.h
echo FILE: analysis/src/derives.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/derives.c
echo FILE: analysis/src/derives.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/derives.h
echo FILE: analysis/src/files.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/files.c
echo FILE: analysis/src/files.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/files.h
echo FILE: analysis/src/getargs.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/getargs.c
echo FILE: analysis/src/getargs.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/getargs.h
echo FILE: analysis/src/gram.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/gram.c
echo FILE: analysis/src/gram.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/gram.h
echo FILE: analysis/src/lalr.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lalr.c
echo FILE: analysis/src/lalr.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/lalr.h
echo FILE: analysis/src/location.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/location.c
echo FILE: analysis/src/location.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/location.h
echo FILE: analysis/src/LR0.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/LR0.c
echo FILE: analysis/src/LR0.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/LR0.h
echo FILE: analysis/src/main.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/main.c
echo FILE: analysis/src/muscle_tab.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/muscle_tab.c
echo FILE: analysis/src/muscle_tab.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/muscle_tab.h
echo FILE: analysis/src/nullable.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/nullable.c
echo FILE: analysis/src/nullable.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/nullable.h
echo FILE: analysis/src/output.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/output.c
echo FILE: analysis/src/output.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/output.h
echo FILE: analysis/src/parse-gram.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/parse-gram.c
echo FILE: analysis/src/parse-gram.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/parse-gram.h
echo FILE: analysis/src/print.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/print.c
echo FILE: analysis/src/print.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/print.h
echo FILE: analysis/src/print_graph.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/print_graph.c
echo FILE: analysis/src/print_graph.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/print_graph.h
echo FILE: analysis/src/reader.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/reader.c
echo FILE: analysis/src/reader.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/reader.h
echo FILE: analysis/src/reduce.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/reduce.c
echo FILE: analysis/src/reduce.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/reduce.h
echo FILE: analysis/src/relation.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/relation.c
echo FILE: analysis/src/relation.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/relation.h
echo FILE: analysis/src/scan-gram.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/scan-gram.c
echo FILE: analysis/src/scan-skel.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/scan-skel.c
echo FILE: analysis/src/state.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/state.c
echo FILE: analysis/src/state.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/state.h
echo FILE: analysis/src/symlist.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/symlist.c
echo FILE: analysis/src/symlist.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/symlist.h
echo FILE: analysis/src/symtab.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/symtab.c
echo FILE: analysis/src/symtab.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/symtab.h
echo FILE: analysis/src/system.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/system.h
echo FILE: analysis/src/tables.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/tables.c
echo FILE: analysis/src/tables.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/tables.h
echo FILE: analysis/src/uniqstr.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/uniqstr.c
echo FILE: analysis/src/uniqstr.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/uniqstr.h
echo FILE: analysis/src/vcg.c
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/vcg.c
echo FILE: analysis/src/vcg.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/vcg.h
echo FILE: analysis/src/vcg_defaults.h
java -Xmx1024m -jar lib/TypeChef-0.3.3.jar --systemRoot=. --systemIncludes=include -h platform.h --lexNoStdout --parse -w analysis/src/vcg_defaults.h
